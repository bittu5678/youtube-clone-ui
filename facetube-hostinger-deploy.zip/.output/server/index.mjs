globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"17458-RWGTPaJ776kKYXFzhhsqv7MDKWE\"",
		"mtime": "2026-10-09T09:02:58.186Z",
		"size": 95320,
		"path": "../public/favicon.png"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"17458-RWGTPaJ776kKYXFzhhsqv7MDKWE\"",
		"mtime": "2026-10-09T09:02:58.186Z",
		"size": 95320,
		"path": "../public/logo.png"
	},
	"/logo.svg": {
		"type": "image/svg+xml",
		"etag": "\"c51-TRdF+O8UOqW6WurFqCGzm3Tki0M\"",
		"mtime": "2026-10-09T09:02:58.186Z",
		"size": 3153,
		"path": "../public/logo.svg"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"c51-TRdF+O8UOqW6WurFqCGzm3Tki0M\"",
		"mtime": "2026-10-09T09:02:58.186Z",
		"size": 3153,
		"path": "../public/favicon.svg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-09T09:02:58.188Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/BottomNav-BejyQfP0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3367-+pecrNWGPPvrekYZqOmrs8lWhUI\"",
		"mtime": "2026-10-09T09:02:54.052Z",
		"size": 13159,
		"path": "../public/assets/BottomNav-BejyQfP0.js"
	},
	"/assets/DashboardSummaryCards-CtOsdCsZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1605-hB3wJr5ZU4USjqGEFjMga2JV1Z4\"",
		"mtime": "2026-10-09T09:02:54.052Z",
		"size": 5637,
		"path": "../public/assets/DashboardSummaryCards-CtOsdCsZ.js"
	},
	"/assets/ImageCard-beho31NK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9d-lI4HJgOsip7lDrHtplIAOokhlZ8\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 3229,
		"path": "../public/assets/ImageCard-beho31NK.js"
	},
	"/assets/Navbar-DrYS8Okk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4886-kmDoG1Cuwu3zhVn10U9lT9+rvKQ\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 18566,
		"path": "../public/assets/Navbar-DrYS8Okk.js"
	},
	"/assets/Sidebar-Bb5OPKDQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48a0-vjuL9WNK3ilgX9VJGe/bPwoqIMc\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 18592,
		"path": "../public/assets/Sidebar-Bb5OPKDQ.js"
	},
	"/assets/VideoCard-B9MlSwck.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2b-DpCfyZ9jy14TVfIQ4hXZEEGTVB8\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 2603,
		"path": "../public/assets/VideoCard-B9MlSwck.js"
	},
	"/assets/admin-BRyr2iwI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"354a-PzTIblt8U6JEQxDP5lU5awy9EF8\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 13642,
		"path": "../public/assets/admin-BRyr2iwI.js"
	},
	"/assets/ads-promotions-Ch7bKM8A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8471-ywUvojFH1ZC5OXkCXpHiqp9wo6Q\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 33905,
		"path": "../public/assets/ads-promotions-Ch7bKM8A.js"
	},
	"/assets/adsense-income-Cz953weK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1480-sOhy3JX56bZ51ywp8ZW5m4F1meg\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 5248,
		"path": "../public/assets/adsense-income-Cz953weK.js"
	},
	"/assets/advertisement-videos-Dgpg_caU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1573-BQv7gbfdb+nZtWDzlr+uw4kMsqI\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 5491,
		"path": "../public/assets/advertisement-videos-Dgpg_caU.js"
	},
	"/assets/arrow-up-right-DDfiDK2U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-z0T1KNeTkDA2QZiR8FGuntAh/YI\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 162,
		"path": "../public/assets/arrow-up-right-DDfiDK2U.js"
	},
	"/assets/auth-CUJ60aFI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c62-Ik50tymJ1M5dH1WEFAbqzWBEeQw\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 23650,
		"path": "../public/assets/auth-CUJ60aFI.js"
	},
	"/assets/arrow-left-BRNBpA61.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a0-G6xcWIIZaSdn38Gm0JM0+6NuD/o\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 160,
		"path": "../public/assets/arrow-left-BRNBpA61.js"
	},
	"/assets/award-CtQ-lb5W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-hiSsdpNXhimp3vgQqVfE8nQNhvI\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 269,
		"path": "../public/assets/award-CtQ-lb5W.js"
	},
	"/assets/browser-SVqs8N5c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5baf-Cj2NXYMC4KtkM7clGK9zAlWP0oo\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 23471,
		"path": "../public/assets/browser-SVqs8N5c.js"
	},
	"/assets/calendar-CgYtE5ME.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fc-vIFc3R7l6BKFZvjbL5Wsksmr0Qk\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 252,
		"path": "../public/assets/calendar-CgYtE5ME.js"
	},
	"/assets/Footer-Ch7Zu3sX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f8-9wshJyY7SQbiXQ531nVdVTsJBRY\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 760,
		"path": "../public/assets/Footer-Ch7Zu3sX.js"
	},
	"/assets/ThemeToggle-C3Ss94H-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4db1-YnapA8LUntXxPQEfsVY8RCnN1gw\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 19889,
		"path": "../public/assets/ThemeToggle-C3Ss94H-.js"
	},
	"/assets/affiliate-income-CgcfoUD0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1298-dUwloY2otShnR7iNUWpKGzgqr70\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 4760,
		"path": "../public/assets/affiliate-income-CgcfoUD0.js"
	},
	"/assets/api-nu0r5xYl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1238-ddEh7rvtOcjnCn5cJbL7PMMTTrY\"",
		"mtime": "2026-10-09T09:02:54.053Z",
		"size": 4664,
		"path": "../public/assets/api-nu0r5xYl.js"
	},
	"/assets/chevron-down-oIRjLQuH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b-4Ir+xjVLIjr7aPmuiElqL6KxGRY\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 123,
		"path": "../public/assets/chevron-down-oIRjLQuH.js"
	},
	"/assets/circle-alert-Bo0Sj0ym.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5-GG3T2wKD28EjfPESsHHCW6ZbDGE\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 245,
		"path": "../public/assets/circle-alert-Bo0Sj0ym.js"
	},
	"/assets/clock-CFT6mF-w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a4-Om+ArgOsW5YzUyNr6Gfmi+yZeTI\"",
		"mtime": "2026-10-09T09:02:54.055Z",
		"size": 164,
		"path": "../public/assets/clock-CFT6mF-w.js"
	},
	"/assets/clsx-DB0hHKMi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"171-ECuaYbqpb4owKgP3JEL6PnaLhH4\"",
		"mtime": "2026-10-09T09:02:54.055Z",
		"size": 369,
		"path": "../public/assets/clsx-DB0hHKMi.js"
	},
	"/assets/copy-BnNztSnU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e7-OiUu3lF47bTuODxEIAZ3SebQytI\"",
		"mtime": "2026-10-09T09:02:54.055Z",
		"size": 231,
		"path": "../public/assets/copy-BnNztSnU.js"
	},
	"/assets/direct-referral-income-D_Sj_Skh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2261-UAHRA2lfYmSwAnTtUfru4B0HRgo\"",
		"mtime": "2026-10-09T09:02:54.055Z",
		"size": 8801,
		"path": "../public/assets/direct-referral-income-D_Sj_Skh.js"
	},
	"/assets/earth-Ce4gmHPw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"184-UXJGzbkAte4Xx7nc+EYaLpROe5M\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 388,
		"path": "../public/assets/earth-Ce4gmHPw.js"
	},
	"/assets/explore-C6Be-TiS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1937-oXLpM+srUbM1+B6MtvQSc44+b2E\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 6455,
		"path": "../public/assets/explore-C6Be-TiS.js"
	},
	"/assets/eye-uXjc4oL_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-nALJobIq0XPwJDbipQYHbRxFLqU\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 251,
		"path": "../public/assets/eye-uXjc4oL_.js"
	},
	"/assets/flame-BPvkNT6X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c2-Ic1tknGHWhIYNcFJGLo9xfstYBo\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 194,
		"path": "../public/assets/flame-BPvkNT6X.js"
	},
	"/assets/dist-CQK3gpx1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"91d7-QeIYJQck0gJ9NDvHhDDBX/BCDmA\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 37335,
		"path": "../public/assets/dist-CQK3gpx1.js"
	},
	"/assets/download-BKZa_fsB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e3-/OzAHvCvZHKkx28aZkgmxm37KGQ\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 227,
		"path": "../public/assets/download-BKZa_fsB.js"
	},
	"/assets/dashboard-DtJSsrPR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60341-4zglhVfVbsaky48iPPuhmYjKRoE\"",
		"mtime": "2026-10-09T09:02:54.055Z",
		"size": 394049,
		"path": "../public/assets/dashboard-DtJSsrPR.js"
	},
	"/assets/free-videos-CbfLyyN5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1199-imSnd0Wg4TBlfa4BcDatyK1AQzc\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 4505,
		"path": "../public/assets/free-videos-CbfLyyN5.js"
	},
	"/assets/global-income-BSNEOX2G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cd6-h79o/OokxMYwndHpiPR/rIyEWdk\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 11478,
		"path": "../public/assets/global-income-BSNEOX2G.js"
	},
	"/assets/heart-CFN9uiyZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fd-zIQFsSIof/UPLHO3YdUHCBZumoU\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 253,
		"path": "../public/assets/heart-CFN9uiyZ.js"
	},
	"/assets/help-DMdeysZI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17f9-3Iiz+zNR0ZLDZeYydWfxRaLgZqA\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 6137,
		"path": "../public/assets/help-DMdeysZI.js"
	},
	"/assets/hero-B-w4XirO.jpg": {
		"type": "image/jpeg",
		"etag": "\"ee84-USjx2QMy2ANKUsmbtxXgBHCU+ew\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 61060,
		"path": "../public/assets/hero-B-w4XirO.jpg"
	},
	"/assets/history-DrrDvrwi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-8pwUK9yri7Gez5uTp2NQ1FPI6AI\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 232,
		"path": "../public/assets/history-DrrDvrwi.js"
	},
	"/assets/income-B5-3xj2H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10eb-Dx1+fENUmQvfgJRsrmwBVyG72q4\"",
		"mtime": "2026-10-09T09:02:54.056Z",
		"size": 4331,
		"path": "../public/assets/income-B5-3xj2H.js"
	},
	"/assets/index.es-DF3Y7OI7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24f8b-Ge9P5xpsn4AE3hRwbgc+UOCM5B0\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 151435,
		"path": "../public/assets/index.es-DF3Y7OI7.js"
	},
	"/assets/kyc-service-DBKKkx1w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13ff-vi0hnVVS2oy5s0LbkS/Ysc6Juso\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 5119,
		"path": "../public/assets/kyc-service-DBKKkx1w.js"
	},
	"/assets/layers-DdWClDFM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a0-DStIhRp3Fx0vtWKf8KyZnSol8Is\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 416,
		"path": "../public/assets/layers-DdWClDFM.js"
	},
	"/assets/certificate-service-Bc0aCfS_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"979bf-QFgfi4nq33Z0td4HDRY+5xce3nk\"",
		"mtime": "2026-10-09T09:02:54.054Z",
		"size": 620991,
		"path": "../public/assets/certificate-service-Bc0aCfS_.js"
	},
	"/assets/index-HJuxo1Ue.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6068b-2k1BQptv5lbd5gsUHGNxps8lKkE\"",
		"mtime": "2026-10-09T09:02:54.052Z",
		"size": 394891,
		"path": "../public/assets/index-HJuxo1Ue.js"
	},
	"/assets/lazyRouteComponent-BTZ3IgwT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f60-BtNQSGQV4th4DIKQfi3zhYdpPkM\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 3936,
		"path": "../public/assets/lazyRouteComponent-BTZ3IgwT.js"
	},
	"/assets/liked-videos-DZ20sYFX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b9-/QEzfBL2xJwy5P4cB9G2CKXIBtk\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 5049,
		"path": "../public/assets/liked-videos-DZ20sYFX.js"
	},
	"/assets/link-Dtzj4f82.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4bfc-tZ2WK+X4O2+hIsYbenLmqE9qBmA\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 19452,
		"path": "../public/assets/link-Dtzj4f82.js"
	},
	"/assets/live-D0IhoSi2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c16-iC+Kt3xXUnsJxdZK2EoJsSs9EXY\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 11286,
		"path": "../public/assets/live-D0IhoSi2.js"
	},
	"/assets/live-videos-D96V_pkh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1654-prrRp9zxWddnOGcrl8CsrBywMZ0\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 5716,
		"path": "../public/assets/live-videos-D96V_pkh.js"
	},
	"/assets/lock-BICLJ8o6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9-FjRGk5Z1VMJoterw7ZjQAXWOb2s\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 201,
		"path": "../public/assets/lock-BICLJ8o6.js"
	},
	"/assets/login-DJ7LAi8J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26-SoFMfAHVJ5oqB5t+mpFRoQvFIoc\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 38,
		"path": "../public/assets/login-DJ7LAi8J.js"
	},
	"/assets/mail-QDtnehGZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d0-c2rJ3/QhyCVcT82WHL3dejYJWAw\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 208,
		"path": "../public/assets/mail-QDtnehGZ.js"
	},
	"/assets/message-circle-LEE4x-EZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec-fPHKqtV1V30DzHk5+Qr01s9yrV8\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 236,
		"path": "../public/assets/message-circle-LEE4x-EZ.js"
	},
	"/assets/network-Dea2j8Tk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17b-DNeQ9yv6r5Y8IhPdIjlDAm/erbA\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 379,
		"path": "../public/assets/network-Dea2j8Tk.js"
	},
	"/assets/phone-DWKwrGLh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d-1V1vJpVy2ujEnLCr02oSgMnAzio\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 317,
		"path": "../public/assets/phone-DWKwrGLh.js"
	},
	"/assets/preload-helper-BLdHbfdN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ef-Il+yCunPAyR+2RrWvue0GrVQy8k\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 1519,
		"path": "../public/assets/preload-helper-BLdHbfdN.js"
	},
	"/assets/my-certificate-Rz5wy1-G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54f6-L3U26AXSITR4e+YYpR6kufrqYHA\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 21750,
		"path": "../public/assets/my-certificate-Rz5wy1-G.js"
	},
	"/assets/premium-videos-DPFqXpIl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1204-WV/rvAE7d5c1tfvlyXQ49AvaitQ\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 4612,
		"path": "../public/assets/premium-videos-DPFqXpIl.js"
	},
	"/assets/purify.es-Dn3VvdGh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6d6c-/KNayXClThDsb0/S6BrMS7tIGrs\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 28012,
		"path": "../public/assets/purify.es-Dn3VvdGh.js"
	},
	"/assets/razorpay-service-3hoD_fVg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"123b-EEKq5AZM2y1siiISuy4dGMbA01g\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 4667,
		"path": "../public/assets/razorpay-service-3hoD_fVg.js"
	},
	"/assets/profile-C6r0zGEx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1067b-hbtTsbVWX8vv+gUXB8pHEcrKYJc\"",
		"mtime": "2026-10-09T09:02:54.057Z",
		"size": 67195,
		"path": "../public/assets/profile-C6r0zGEx.js"
	},
	"/assets/referral-income-DsaZPZ4Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17a3-zsoToOuiYBc1XvzYGhCtjNs94bE\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 6051,
		"path": "../public/assets/referral-income-DsaZPZ4Y.js"
	},
	"/assets/referral-service-38f26B13.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc8-2R+1Trhu7n9RcgPYntg37dOGaYc\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 3272,
		"path": "../public/assets/referral-service-38f26B13.js"
	},
	"/assets/referral-members-CEoUJ1V6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3275-hMO0HpI4gubxcA72mVrRA5foE40\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 12917,
		"path": "../public/assets/referral-members-CEoUJ1V6.js"
	},
	"/assets/rolldown-runtime-hePW80VL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cc-fA8td6k29UVF6JoPfhOPkceTK1M\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 716,
		"path": "../public/assets/rolldown-runtime-hePW80VL.js"
	},
	"/assets/routes-B2BCV9Cz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3e6d-IZD2aK51RYsDhtlbCmG1vLIjJGo\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 15981,
		"path": "../public/assets/routes-B2BCV9Cz.js"
	},
	"/assets/send-mZpVWW_U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11d-OhZN2/v4bBcjU3c4RiwS2hFqdgE\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 285,
		"path": "../public/assets/send-mZpVWW_U.js"
	},
	"/assets/search-BYVJGZ6R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15d-UWeQ2RUkfURpHO6G5G+Esy4xtyI\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 349,
		"path": "../public/assets/search-BYVJGZ6R.js"
	},
	"/assets/settings-kZD_sxZM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e97-4C56KsSRGXIr41dorjydmksg2og\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 7831,
		"path": "../public/assets/settings-kZD_sxZM.js"
	},
	"/assets/shorts-CrMnvfay.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30c1-WjCalPx8YzMTZXUcQWF/VObOeH0\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 12481,
		"path": "../public/assets/shorts-CrMnvfay.js"
	},
	"/assets/share-2-DwL0TZBC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"160-9q+3qnGzw4qmBbD/kGZaQQ+JY4o\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 352,
		"path": "../public/assets/share-2-DwL0TZBC.js"
	},
	"/assets/shorts-p7vpaA35.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7b-LpaK/fipPhSAJl7QbJJ6W0tgOp0\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 3963,
		"path": "../public/assets/shorts-p7vpaA35.js"
	},
	"/assets/shuffle-PMMqnsr7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17a-dXuhNVnbjH2bDXq4sBrEjCSwszc\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 378,
		"path": "../public/assets/shuffle-PMMqnsr7.js"
	},
	"/assets/styles-Bowq5jfQ.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2f5d9-H8cgPwEEgaJ2x2tdGAAsCK7Rrf4\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 194009,
		"path": "../public/assets/styles-Bowq5jfQ.css"
	},
	"/assets/subscriptions-GRV7-Df5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1193-9JHmhMpvOOGShYCiy/NnTf8R7kg\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 4499,
		"path": "../public/assets/subscriptions-GRV7-Df5.js"
	},
	"/assets/team-income-Ds7yp5wR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bac-vnCAtOSfR3yyVGXjZP0jxpKzNQs\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 7084,
		"path": "../public/assets/team-income-Ds7yp5wR.js"
	},
	"/assets/shield-check-DKX99nnY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-2Nd4Opwe/zYRSopPi624+3HCrPs\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 315,
		"path": "../public/assets/shield-check-DKX99nnY.js"
	},
	"/assets/team-members-D8gRYKUm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c197-9rDZwdrMO71ul3gpVmv6ONGqEQw\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 49559,
		"path": "../public/assets/team-members-D8gRYKUm.js"
	},
	"/assets/thumb-1-BLDUMvA-.jpg": {
		"type": "image/jpeg",
		"etag": "\"e330-hQkuWNtzS5zTZBjRkX1onMfnims\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 58160,
		"path": "../public/assets/thumb-1-BLDUMvA-.jpg"
	},
	"/assets/thumb-2-D9wgIhan.jpg": {
		"type": "image/jpeg",
		"etag": "\"117c4-jEhHE5BVyrW+apBCohqndZ36EdA\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 71620,
		"path": "../public/assets/thumb-2-D9wgIhan.jpg"
	},
	"/assets/thumb-3-CjusrIMk.jpg": {
		"type": "image/jpeg",
		"etag": "\"1097f-Yu8BjeXjHZoTYhs0o3EDCJ8q+EU\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 67967,
		"path": "../public/assets/thumb-3-CjusrIMk.jpg"
	},
	"/assets/short-videos-DbLR1r2l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1077-PksacvNaR+budWa6ku7p8mbuhQs\"",
		"mtime": "2026-10-09T09:02:54.058Z",
		"size": 4215,
		"path": "../public/assets/short-videos-DbLR1r2l.js"
	},
	"/assets/thumb-4-u_EQIgoI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"179-N8m7mD4M9UXCFkEtF8YcrIp7R5Y\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 377,
		"path": "../public/assets/thumb-4-u_EQIgoI.js"
	},
	"/assets/thumb-6-C43Zhxnm.jpg": {
		"type": "image/jpeg",
		"etag": "\"fc0b-2cp1PSPfN+LYLOjpyDdAHtJ54Bo\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 64523,
		"path": "../public/assets/thumb-6-C43Zhxnm.jpg"
	},
	"/assets/thumb-6-DTeVZOwX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-nEAdu8jti9UHs0kbYwn/SCr9SOQ\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 167,
		"path": "../public/assets/thumb-6-DTeVZOwX.js"
	},
	"/assets/tv-ZZFeLHF9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-Y7y9gE/EmDjHrnO+WxrNJPASXTc\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 180,
		"path": "../public/assets/tv-ZZFeLHF9.js"
	},
	"/assets/thumb-5-C5dA8AC_.jpg": {
		"type": "image/jpeg",
		"etag": "\"1274d-X/n0RlFC5FY2B/DhgaFPc777gOw\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 75597,
		"path": "../public/assets/thumb-5-C5dA8AC_.jpg"
	},
	"/assets/useNavigate-Dk-2UMSn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e4-P+HA60Qbn8VYadvXkmzo9Qn60Z0\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 228,
		"path": "../public/assets/useNavigate-Dk-2UMSn.js"
	},
	"/assets/upload-BtCoygks.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af93-FF7GHNEfvxujzHU+xZ6+9FBWZFQ\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 44947,
		"path": "../public/assets/upload-BtCoygks.js"
	},
	"/assets/thumb-4-DoWflXCY.jpg": {
		"type": "image/jpeg",
		"etag": "\"11f04-HOPCW/enmY8eef3QVNMQfzqK7iA\"",
		"mtime": "2026-10-09T09:02:54.060Z",
		"size": 73476,
		"path": "../public/assets/thumb-4-DoWflXCY.jpg"
	},
	"/assets/useSearch-5iZSv4kl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db-rWWmwQDz8Gq66FAHjytzasYLmVs\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 219,
		"path": "../public/assets/useSearch-5iZSv4kl.js"
	},
	"/assets/users-CxvnNEaN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12d-8+1b6Fy5C/YhMV/hxeahyrgDdtQ\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 301,
		"path": "../public/assets/users-CxvnNEaN.js"
	},
	"/assets/video-service-D-3gDcgd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f25-coZ08MsPe9cMawwYvyzhAq6TBHw\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 7973,
		"path": "../public/assets/video-service-D-3gDcgd.js"
	},
	"/assets/videos-Bza8Ni1g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11df-ypw/TRXyGIgLQreyraKdVMrGgc0\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 4575,
		"path": "../public/assets/videos-Bza8Ni1g.js"
	},
	"/assets/volume-2-B_Qxpwht.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27b-y1x51aE5QXz5sv61Zf1PcZhcHVg\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 635,
		"path": "../public/assets/volume-2-B_Qxpwht.js"
	},
	"/assets/wallet-balance-D1cOMvpA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34b9-k09KEwSlBAppfJ764d4PsZ1sdjs\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 13497,
		"path": "../public/assets/wallet-balance-D1cOMvpA.js"
	},
	"/assets/watch-later-Dq3ogpA9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1368-tvhxIJSPAUpavkES/hIEltJN4Ko\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 4968,
		"path": "../public/assets/watch-later-Dq3ogpA9.js"
	},
	"/assets/watch._videoId-BhxrZORB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"250b-vL6BhCN6rM2YKdf5xzOVe6PGVoU\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 9483,
		"path": "../public/assets/watch._videoId-BhxrZORB.js"
	},
	"/assets/watch._videoId-CvWX1M8w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26f-G1hZZYRH+A7/a0/j6fW7eu4Q/TA\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 623,
		"path": "../public/assets/watch._videoId-CvWX1M8w.js"
	},
	"/assets/your-videos-DcWpbXO0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27e2-Pkre4GZ/zxqsXtEUtqqogvDa2Mg\"",
		"mtime": "2026-10-09T09:02:54.059Z",
		"size": 10210,
		"path": "../public/assets/your-videos-DcWpbXO0.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_0jRgqU = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_0jRgqU
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
