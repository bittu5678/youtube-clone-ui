//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dsj3RFpE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/applet/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/ads-promotions",
			"/adsense-income",
			"/advertisement-videos",
			"/affiliate-income",
			"/auth",
			"/dashboard",
			"/direct-referral-income",
			"/explore",
			"/free-videos",
			"/global-income",
			"/help",
			"/history",
			"/images-uploaded",
			"/income",
			"/liked-videos",
			"/live",
			"/live-videos",
			"/login",
			"/my-certificate",
			"/premium-videos",
			"/profile",
			"/referral-income",
			"/referral-members",
			"/settings",
			"/short-videos",
			"/shorts",
			"/subscriptions",
			"/team-income",
			"/team-members",
			"/upload",
			"/wallet-balance",
			"/watch-later",
			"/withdrawal-balance",
			"/your-videos",
			"/watch/$videoId"
		],
		preloads: [
			"/assets/index-HJuxo1Ue.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/link-Dtzj4f82.js",
			"/assets/dist-CQK3gpx1.js",
			"/assets/lazyRouteComponent-BTZ3IgwT.js",
			"/assets/BottomNav-BejyQfP0.js",
			"/assets/api-nu0r5xYl.js",
			"/assets/ThemeToggle-C3Ss94H-.js",
			"/assets/preload-helper-BLdHbfdN.js",
			"/assets/Sidebar-Bb5OPKDQ.js",
			"/assets/Navbar-DrYS8Okk.js",
			"/assets/videos-Bza8Ni1g.js",
			"/assets/history-DrrDvrwi.js",
			"/assets/search-BYVJGZ6R.js",
			"/assets/video-service-D-3gDcgd.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-HJuxo1Ue.js"
		} }]
	},
	"/": {
		filePath: "/app/applet/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B2BCV9Cz.js",
			"/assets/useNavigate-Dk-2UMSn.js",
			"/assets/ImageCard-beho31NK.js",
			"/assets/Footer-Ch7Zu3sX.js",
			"/assets/VideoCard-B9MlSwck.js",
			"/assets/flame-BPvkNT6X.js",
			"/assets/shorts-p7vpaA35.js"
		]
	},
	"/admin": {
		filePath: "/app/applet/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BRyr2iwI.js",
			"/assets/useNavigate-Dk-2UMSn.js",
			"/assets/arrow-left-BRNBpA61.js",
			"/assets/copy-BnNztSnU.js",
			"/assets/lock-BICLJ8o6.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/ads-promotions": {
		filePath: "/app/applet/src/routes/ads-promotions.tsx",
		children: void 0,
		preloads: [
			"/assets/ads-promotions-Ch7bKM8A.js",
			"/assets/award-CtQ-lb5W.js",
			"/assets/calendar-CgYtE5ME.js",
			"/assets/clock-CFT6mF-w.js",
			"/assets/eye-uXjc4oL_.js",
			"/assets/flame-BPvkNT6X.js",
			"/assets/layers-DdWClDFM.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/adsense-income": {
		filePath: "/app/applet/src/routes/adsense-income.tsx",
		children: void 0,
		preloads: ["/assets/adsense-income-Cz953weK.js", "/assets/tv-ZZFeLHF9.js"]
	},
	"/advertisement-videos": {
		filePath: "/app/applet/src/routes/advertisement-videos.tsx",
		children: void 0,
		preloads: ["/assets/advertisement-videos-Dgpg_caU.js", "/assets/tv-ZZFeLHF9.js"]
	},
	"/affiliate-income": {
		filePath: "/app/applet/src/routes/affiliate-income.tsx",
		children: void 0,
		preloads: ["/assets/affiliate-income-CgcfoUD0.js", "/assets/share-2-DwL0TZBC.js"]
	},
	"/auth": {
		filePath: "/app/applet/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CUJ60aFI.js",
			"/assets/useNavigate-Dk-2UMSn.js",
			"/assets/arrow-left-BRNBpA61.js",
			"/assets/circle-alert-Bo0Sj0ym.js",
			"/assets/copy-BnNztSnU.js",
			"/assets/eye-uXjc4oL_.js",
			"/assets/lock-BICLJ8o6.js",
			"/assets/mail-QDtnehGZ.js",
			"/assets/phone-DWKwrGLh.js",
			"/assets/shield-check-DKX99nnY.js"
		]
	},
	"/dashboard": {
		filePath: "/app/applet/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DtJSsrPR.js",
			"/assets/clock-CFT6mF-w.js",
			"/assets/certificate-service-Bc0aCfS_.js",
			"/assets/clsx-DB0hHKMi.js",
			"/assets/DashboardSummaryCards-CtOsdCsZ.js",
			"/assets/referral-service-38f26B13.js"
		]
	},
	"/direct-referral-income": {
		filePath: "/app/applet/src/routes/direct-referral-income.tsx",
		children: void 0,
		preloads: [
			"/assets/direct-referral-income-D_Sj_Skh.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/users-CxvnNEaN.js",
			"/assets/referral-service-38f26B13.js"
		]
	},
	"/explore": {
		filePath: "/app/applet/src/routes/explore.tsx",
		children: void 0,
		preloads: [
			"/assets/explore-C6Be-TiS.js",
			"/assets/VideoCard-B9MlSwck.js",
			"/assets/flame-BPvkNT6X.js"
		]
	},
	"/free-videos": {
		filePath: "/app/applet/src/routes/free-videos.tsx",
		children: void 0,
		preloads: ["/assets/free-videos-CbfLyyN5.js"]
	},
	"/global-income": {
		filePath: "/app/applet/src/routes/global-income.tsx",
		children: void 0,
		preloads: [
			"/assets/global-income-BSNEOX2G.js",
			"/assets/earth-Ce4gmHPw.js",
			"/assets/shield-check-DKX99nnY.js"
		]
	},
	"/help": {
		filePath: "/app/applet/src/routes/help.tsx",
		children: void 0,
		preloads: [
			"/assets/help-DMdeysZI.js",
			"/assets/chevron-down-oIRjLQuH.js",
			"/assets/shield-check-DKX99nnY.js"
		]
	},
	"/income": {
		filePath: "/app/applet/src/routes/income.tsx",
		children: void 0,
		preloads: [
			"/assets/income-B5-3xj2H.js",
			"/assets/earth-Ce4gmHPw.js",
			"/assets/share-2-DwL0TZBC.js",
			"/assets/tv-ZZFeLHF9.js",
			"/assets/DashboardSummaryCards-CtOsdCsZ.js"
		]
	},
	"/liked-videos": {
		filePath: "/app/applet/src/routes/liked-videos.tsx",
		children: void 0,
		preloads: [
			"/assets/liked-videos-DZ20sYFX.js",
			"/assets/heart-CFN9uiyZ.js",
			"/assets/lock-BICLJ8o6.js",
			"/assets/shuffle-PMMqnsr7.js",
			"/assets/thumb-4-u_EQIgoI.js"
		]
	},
	"/live": {
		filePath: "/app/applet/src/routes/live.tsx",
		children: void 0,
		preloads: [
			"/assets/live-D0IhoSi2.js",
			"/assets/heart-CFN9uiyZ.js",
			"/assets/send-mZpVWW_U.js",
			"/assets/share-2-DwL0TZBC.js",
			"/assets/users-CxvnNEaN.js",
			"/assets/thumb-6-DTeVZOwX.js"
		]
	},
	"/live-videos": {
		filePath: "/app/applet/src/routes/live-videos.tsx",
		children: void 0,
		preloads: ["/assets/live-videos-D96V_pkh.js", "/assets/tv-ZZFeLHF9.js"]
	},
	"/login": {
		filePath: "/app/applet/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DJ7LAi8J.js"]
	},
	"/my-certificate": {
		filePath: "/app/applet/src/routes/my-certificate.tsx",
		children: void 0,
		preloads: [
			"/assets/my-certificate-Rz5wy1-G.js",
			"/assets/award-CtQ-lb5W.js",
			"/assets/copy-BnNztSnU.js",
			"/assets/download-BKZa_fsB.js",
			"/assets/lock-BICLJ8o6.js",
			"/assets/mail-QDtnehGZ.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/certificate-service-Bc0aCfS_.js",
			"/assets/browser-SVqs8N5c.js"
		]
	},
	"/premium-videos": {
		filePath: "/app/applet/src/routes/premium-videos.tsx",
		children: void 0,
		preloads: ["/assets/premium-videos-DPFqXpIl.js", "/assets/lock-BICLJ8o6.js"]
	},
	"/profile": {
		filePath: "/app/applet/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-C6r0zGEx.js",
			"/assets/award-CtQ-lb5W.js",
			"/assets/calendar-CgYtE5ME.js",
			"/assets/clock-CFT6mF-w.js",
			"/assets/copy-BnNztSnU.js",
			"/assets/kyc-service-DBKKkx1w.js",
			"/assets/download-BKZa_fsB.js",
			"/assets/eye-uXjc4oL_.js",
			"/assets/layers-DdWClDFM.js",
			"/assets/mail-QDtnehGZ.js",
			"/assets/message-circle-LEE4x-EZ.js",
			"/assets/phone-DWKwrGLh.js",
			"/assets/send-mZpVWW_U.js",
			"/assets/share-2-DwL0TZBC.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/thumb-4-u_EQIgoI.js",
			"/assets/users-CxvnNEaN.js",
			"/assets/shorts-p7vpaA35.js",
			"/assets/browser-SVqs8N5c.js"
		]
	},
	"/referral-income": {
		filePath: "/app/applet/src/routes/referral-income.tsx",
		children: void 0,
		preloads: [
			"/assets/referral-income-DsaZPZ4Y.js",
			"/assets/download-BKZa_fsB.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/referral-members": {
		filePath: "/app/applet/src/routes/referral-members.tsx",
		children: void 0,
		preloads: [
			"/assets/referral-members-CEoUJ1V6.js",
			"/assets/arrow-up-right-DDfiDK2U.js",
			"/assets/copy-BnNztSnU.js",
			"/assets/message-circle-LEE4x-EZ.js",
			"/assets/network-Dea2j8Tk.js",
			"/assets/phone-DWKwrGLh.js",
			"/assets/referral-service-38f26B13.js"
		]
	},
	"/settings": {
		filePath: "/app/applet/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-kZD_sxZM.js"]
	},
	"/short-videos": {
		filePath: "/app/applet/src/routes/short-videos.tsx",
		children: void 0,
		preloads: ["/assets/short-videos-DbLR1r2l.js", "/assets/shorts-p7vpaA35.js"]
	},
	"/shorts": {
		filePath: "/app/applet/src/routes/shorts.tsx",
		children: void 0,
		preloads: [
			"/assets/shorts-CrMnvfay.js",
			"/assets/chevron-down-oIRjLQuH.js",
			"/assets/send-mZpVWW_U.js",
			"/assets/share-2-DwL0TZBC.js",
			"/assets/volume-2-B_Qxpwht.js",
			"/assets/thumb-4-u_EQIgoI.js",
			"/assets/shorts-p7vpaA35.js"
		]
	},
	"/subscriptions": {
		filePath: "/app/applet/src/routes/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-GRV7-Df5.js",
			"/assets/VideoCard-B9MlSwck.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/team-income": {
		filePath: "/app/applet/src/routes/team-income.tsx",
		children: void 0,
		preloads: [
			"/assets/team-income-Ds7yp5wR.js",
			"/assets/arrow-up-right-DDfiDK2U.js",
			"/assets/award-CtQ-lb5W.js",
			"/assets/layers-DdWClDFM.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/team-members": {
		filePath: "/app/applet/src/routes/team-members.tsx",
		children: void 0,
		preloads: [
			"/assets/team-members-D8gRYKUm.js",
			"/assets/arrow-up-right-DDfiDK2U.js",
			"/assets/award-CtQ-lb5W.js",
			"/assets/layers-DdWClDFM.js",
			"/assets/network-Dea2j8Tk.js",
			"/assets/shield-check-DKX99nnY.js",
			"/assets/users-CxvnNEaN.js",
			"/assets/clsx-DB0hHKMi.js"
		]
	},
	"/upload": {
		filePath: "/app/applet/src/routes/upload.tsx",
		children: void 0,
		preloads: [
			"/assets/upload-BtCoygks.js",
			"/assets/useSearch-5iZSv4kl.js",
			"/assets/useNavigate-Dk-2UMSn.js",
			"/assets/arrow-left-BRNBpA61.js",
			"/assets/Footer-Ch7Zu3sX.js",
			"/assets/clock-CFT6mF-w.js",
			"/assets/layers-DdWClDFM.js",
			"/assets/razorpay-service-3hoD_fVg.js"
		]
	},
	"/wallet-balance": {
		filePath: "/app/applet/src/routes/wallet-balance.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-balance-D1cOMvpA.js",
			"/assets/circle-alert-Bo0Sj0ym.js",
			"/assets/kyc-service-DBKKkx1w.js",
			"/assets/earth-Ce4gmHPw.js",
			"/assets/users-CxvnNEaN.js"
		]
	},
	"/watch-later": {
		filePath: "/app/applet/src/routes/watch-later.tsx",
		children: void 0,
		preloads: [
			"/assets/watch-later-Dq3ogpA9.js",
			"/assets/clock-CFT6mF-w.js",
			"/assets/lock-BICLJ8o6.js",
			"/assets/shuffle-PMMqnsr7.js"
		]
	},
	"/your-videos": {
		filePath: "/app/applet/src/routes/your-videos.tsx",
		children: void 0,
		preloads: ["/assets/your-videos-DcWpbXO0.js"]
	},
	"/watch/$videoId": {
		filePath: "/app/applet/src/routes/watch.$videoId.tsx",
		children: void 0,
		preloads: [
			"/assets/watch._videoId-BhxrZORB.js",
			"/assets/ImageCard-beho31NK.js",
			"/assets/download-BKZa_fsB.js",
			"/assets/VideoCard-B9MlSwck.js",
			"/assets/send-mZpVWW_U.js",
			"/assets/share-2-DwL0TZBC.js",
			"/assets/volume-2-B_Qxpwht.js",
			"/assets/thumb-4-u_EQIgoI.js",
			"/assets/watch._videoId-CvWX1M8w.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
