import { u as api } from "./ThemeToggle-Ca8kwojN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-service-oYEql6hM.js
var LOCAL_STORAGE_PERSONAL_KYC_PREFIX = "facetube_kyc_personal_";
var LOCAL_STORAGE_BANK_KYC_PREFIX = "facetube_kyc_bank_";
var DEFAULT_PERSONAL_KYC = {
	FT102857: {
		fullName: "FaceTube Administrator",
		mobile: "+1 555-019-2834",
		dob: "1990-05-12",
		address: "742 Evergreen Terrace, Tech Park",
		city: "San Jose",
		state: "California",
		pincode: "95110",
		nomineeName: "Sarah Administrator",
		nomineeRelation: "Spouse",
		nomineeMobile: "+1 555-019-8821",
		status: "Verified"
	},
	FT483921: {
		fullName: "Alex Rivera",
		mobile: "+1 555-014-8392",
		dob: "1994-08-15",
		address: "402 Skyline Boulevard, Suite 120",
		city: "San Francisco",
		state: "California",
		pincode: "94107",
		nomineeName: "Elena Rivera",
		nomineeRelation: "Spouse",
		nomineeMobile: "+1 555-014-9921",
		status: "Verified"
	},
	FT900431: {
		fullName: "Maya Lin",
		mobile: "+1 555-019-0043",
		dob: "1996-11-20",
		address: "18 Orchard St, Creator Row",
		city: "New York",
		state: "New York",
		pincode: "10002",
		nomineeName: "David Lin",
		nomineeRelation: "Father",
		nomineeMobile: "+1 555-019-4411",
		status: "Submitted"
	}
};
var DEFAULT_BANK_KYC = {
	FT102857: {
		accountHolderName: "FaceTube Administrator",
		bankName: "Silicon Valley Bank (First Citizens)",
		accountNumber: "918239019201",
		ifscCode: "SVBL0001048",
		branchName: "Santa Clara Tech Hub",
		accountType: "Current",
		upiId: "facetube.admin@okaxis",
		status: "Verified"
	},
	FT483921: {
		accountHolderName: "Alex Rivera",
		bankName: "Chase Bank (JPMorgan Chase)",
		accountNumber: "849201948201",
		ifscCode: "CHAS0002914",
		branchName: "Market St Financial Center",
		accountType: "Saving",
		upiId: "alexrivera@okhdfcbank",
		status: "Verified"
	},
	FT900431: {
		accountHolderName: "Maya Lin",
		bankName: "Bank of America",
		accountNumber: "482019482910",
		ifscCode: "BOFA0008412",
		branchName: "Midtown Manhattan",
		accountType: "Saving",
		upiId: "mayalin@okicici",
		status: "Submitted"
	}
};
/**
* Load Personal KYC for a specific user ID
*/
async function getPersonalKyc(userId, userDefaults) {
	const normId = userId.trim().toUpperCase();
	try {
		const res = await api.kyc.getPersonal(normId);
		if (res && res.kyc) {
			const data = res.kyc;
			const kyc = {
				id: data.id,
				userId: data.user_id || data.userId,
				fullName: data.full_name || data.fullName,
				mobile: data.mobile,
				dob: data.dob || "",
				address: data.address || "",
				city: data.city || "",
				state: data.state || "",
				pincode: data.pincode || "",
				nomineeName: data.nominee_name || data.nomineeName || "",
				nomineeRelation: data.nominee_relation || data.nomineeRelation || "",
				nomineeMobile: data.nominee_mobile || data.nomineeMobile || "",
				status: data.status || "Submitted",
				updatedAt: data.updated_at || data.updatedAt
			};
			saveLocalPersonalKyc(kyc);
			return kyc;
		}
	} catch (e) {}
	const cached = getLocalPersonalKyc(normId);
	if (cached) return cached;
	const seed = DEFAULT_PERSONAL_KYC[normId] || {};
	const initial = {
		userId: normId,
		fullName: seed.fullName || userDefaults?.fullName || "",
		mobile: seed.mobile || userDefaults?.mobile || "",
		dob: seed.dob || "",
		address: seed.address || "",
		city: seed.city || "",
		state: seed.state || "",
		pincode: seed.pincode || "",
		nomineeName: seed.nomineeName || "",
		nomineeRelation: seed.nomineeRelation || "",
		nomineeMobile: seed.nomineeMobile || "",
		status: seed.status || "Pending",
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	saveLocalPersonalKyc(initial);
	return initial;
}
/**
* Save Personal KYC to database & local storage
*/
async function savePersonalKyc(userId, formData) {
	const normId = userId.trim().toUpperCase();
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const record = {
		userId: normId,
		...formData,
		status: "Verified",
		updatedAt: now
	};
	try {
		await api.kyc.savePersonal({
			user_id: normId,
			full_name: record.fullName,
			mobile: record.mobile,
			dob: record.dob,
			address: record.address,
			city: record.city,
			state: record.state,
			pincode: record.pincode,
			nominee_name: record.nomineeName,
			nominee_relation: record.nomineeRelation,
			nominee_mobile: record.nomineeMobile,
			status: record.status
		});
	} catch (e) {
		console.warn("API savePersonal fallback:", e);
	}
	saveLocalPersonalKyc(record);
	return {
		success: true,
		data: record
	};
}
/**
* Load Bank KYC for a specific user ID
*/
async function getBankKyc(userId, userDefaults) {
	const normId = userId.trim().toUpperCase();
	try {
		const res = await api.kyc.getBank(normId);
		if (res && res.kyc) {
			const data = res.kyc;
			const kyc = {
				id: data.id,
				userId: data.user_id || data.userId,
				accountHolderName: data.account_holder_name || data.accountHolderName,
				bankName: data.bank_name || data.bankName,
				accountNumber: data.account_number || data.accountNumber,
				ifscCode: data.ifsc_code || data.ifscCode,
				branchName: data.branch_name || data.branchName || "",
				accountType: (data.account_type || data.accountType) === "Current" ? "Current" : "Saving",
				upiId: data.upi_id || data.upiId || "",
				upiQrCodeUrl: data.upi_qr_code || data.upiQrCodeUrl || void 0,
				status: data.status || "Submitted",
				updatedAt: data.updated_at || data.updatedAt
			};
			saveLocalBankKyc(kyc);
			return kyc;
		}
	} catch (e) {}
	const cached = getLocalBankKyc(normId);
	if (cached) return cached;
	const seed = DEFAULT_BANK_KYC[normId] || {};
	const initial = {
		userId: normId,
		accountHolderName: seed.accountHolderName || userDefaults?.fullName || "",
		bankName: seed.bankName || "",
		accountNumber: seed.accountNumber || "",
		ifscCode: seed.ifscCode || "",
		branchName: seed.branchName || "",
		accountType: seed.accountType || "Saving",
		upiId: seed.upiId || "",
		upiQrCodeUrl: seed.upiQrCodeUrl,
		status: seed.status || "Pending",
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	saveLocalBankKyc(initial);
	return initial;
}
/**
* Save Bank KYC to database & local storage
*/
async function saveBankKyc(userId, formData) {
	const normId = userId.trim().toUpperCase();
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const record = {
		userId: normId,
		...formData,
		status: "Verified",
		updatedAt: now
	};
	try {
		await api.kyc.saveBank({
			user_id: normId,
			account_holder_name: record.accountHolderName,
			bank_name: record.bankName,
			account_number: record.accountNumber,
			ifsc_code: record.ifscCode.toUpperCase(),
			branch_name: record.branchName,
			account_type: record.accountType,
			upi_id: record.upiId,
			upi_qr_code: record.upiQrCodeUrl || null,
			status: record.status
		});
	} catch (e) {
		console.warn("API saveBank fallback:", e);
	}
	saveLocalBankKyc(record);
	return {
		success: true,
		data: record
	};
}
function getLocalPersonalKyc(userId) {
	try {
		const raw = localStorage.getItem(`${LOCAL_STORAGE_PERSONAL_KYC_PREFIX}${userId}`);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function saveLocalPersonalKyc(kyc) {
	try {
		localStorage.setItem(`${LOCAL_STORAGE_PERSONAL_KYC_PREFIX}${kyc.userId}`, JSON.stringify(kyc));
	} catch {}
}
function getLocalBankKyc(userId) {
	try {
		const raw = localStorage.getItem(`${LOCAL_STORAGE_BANK_KYC_PREFIX}${userId}`);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function saveLocalBankKyc(kyc) {
	try {
		localStorage.setItem(`${LOCAL_STORAGE_BANK_KYC_PREFIX}${kyc.userId}`, JSON.stringify(kyc));
	} catch {}
}
//#endregion
export { savePersonalKyc as i, getPersonalKyc as n, saveBankKyc as r, getBankKyc as t };
