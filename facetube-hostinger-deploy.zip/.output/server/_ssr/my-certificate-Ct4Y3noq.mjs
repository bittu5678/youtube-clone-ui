import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth, n as FacetubeLogoIcon } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as ScrollText, C as ShieldCheck, F as Printer, Kt as CircleCheck, Pt as Download, at as Lock, m as TrendingUp, rt as Mail, sn as Award, y as Sparkles, zt as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
import { a as getRankDetails, i as generateAutoCertificateId, n as calculateRankFromSubscribers, o as printCertificateElement, r as captureCertificatePdf, s as sendCertificateEmailApi, t as CREATOR_RANKS } from "./certificate-service-C_JpbKzf.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/my-certificate-Ct4Y3noq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var DigitalCertificateCard = import_react.forwardRef(({ userName, userId, rank, subscriberCount, certificateId, issueDate, verificationUrl }, ref) => {
	const [qrCodeUrl, setQrCodeUrl] = (0, import_react.useState)("");
	const verifyLink = verificationUrl || (typeof window !== "undefined" ? `${window.location.origin}/my-certificate?verify=${encodeURIComponent(certificateId)}` : `https://facetube.app/my-certificate?verify=${encodeURIComponent(certificateId)}`);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		async function generateQr() {
			try {
				const dataUrl = await import_lib.toDataURL(verifyLink, {
					width: 320,
					margin: 1,
					color: {
						dark: "#0f172a",
						light: "#ffffff"
					},
					errorCorrectionLevel: "H"
				});
				if (isMounted) setQrCodeUrl(dataUrl);
			} catch (err) {
				console.error("Failed to generate QR code for certificate:", err);
			}
		}
		generateQr();
		return () => {
			isMounted = false;
		};
	}, [verifyLink]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		id: "facetube-digital-certificate",
		className: "relative mx-auto w-full max-w-[940px] min-w-[680px] overflow-hidden rounded-2xl bg-[#ffffff] text-slate-900 shadow-xl border-[4px] border-[#c59b27] selection:bg-[#c59b27]/20 [page-break-inside:avoid] [break-inside:avoid]",
		style: {
			boxShadow: "0 15px 40px -10px rgba(0, 0, 0, 0.12), 0 0 30px rgba(197, 155, 39, 0.15)",
			pageBreakInside: "avoid",
			breakInside: "avoid"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "m-3 rounded-xl border-2 border-[#c59b27]/60 p-6 sm:p-8 relative bg-gradient-to-b from-[#fdfbf7] via-[#ffffff] to-[#fbf9f4] [page-break-inside:avoid] [break-inside:avoid]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-2 left-2 w-10 h-10 border-t-2 border-l-2 border-[#c59b27] rounded-tl pointer-events-none opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-2 right-2 w-10 h-10 border-t-2 border-r-2 border-[#c59b27] rounded-tr pointer-events-none opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-2 left-2 w-10 h-10 border-b-2 border-l-2 border-[#c59b27] rounded-bl pointer-events-none opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-2 right-2 w-10 h-10 border-b-2 border-r-2 border-[#c59b27] rounded-br pointer-events-none opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacetubeLogoIcon, { size: 460 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col items-center text-center space-y-2 pb-4 border-b border-[#c59b27]/30",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacetubeLogoIcon, { size: 40 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-2xl sm:text-3xl font-black tracking-tight text-slate-900",
								children: ["Face", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#ff3b2e]",
									children: "Tube"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#fbf5e6] border border-[#c59b27]/40 text-[11px] sm:text-xs font-bold tracking-[0.2em] text-[#996f12] uppercase shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-[#b38515]" }),
								"Official Creator Accreditation",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-[#b38515]" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-4xl font-extrabold tracking-wider text-[#996f12] pt-1 uppercase font-serif drop-shadow-xs",
							children: "FaceTube Digital Certificate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm text-slate-600 font-medium tracking-wide max-w-xl",
							children: "This credential accreditation is proudly conferred upon the creator below for outstanding community excellence, ethical video publishing, and verified subscriber milestones."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 py-5 sm:py-6 text-center space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs sm:text-sm font-bold uppercase tracking-[0.25em] text-[#996f12]",
							children: "This is to certify that"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl sm:text-5xl font-black tracking-tight text-slate-900 font-serif",
								children: userName || "Alex Rivera"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-2 h-0.5 w-52 bg-gradient-to-r from-transparent via-[#c59b27] to-transparent" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed px-2",
							children: [
								"has met all governance standards and achieved creator excellence, verified under FaceTube creator identity",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-[#ff3b2e] bg-red-50 px-2.5 py-0.5 rounded border border-[#ff3b2e]/30",
									children: userId || "FT483921"
								}),
								". Conferred in recognition of stellar channel growth, creator integrity, and audience empowerment."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cert-metric-grid relative z-10 grid grid-cols-3 gap-3 sm:gap-4 my-2 [page-break-inside:avoid] [break-inside:avoid]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-[#c59b27]/40 bg-white p-3 sm:p-4 text-center shadow-xs relative overflow-hidden [page-break-inside:avoid] [break-inside:avoid]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#c59b27] to-[#e6b839]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-[#996f12]",
									children: "Creator Award / Rank"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-center justify-center gap-1.5 text-sm sm:text-lg font-black text-slate-900",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#b38515] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: rank || "Gold Creator Award"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] text-slate-500 mt-0.5 font-medium truncate",
									children: "Official Tier Milestone"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-[#c59b27]/40 bg-white p-3 sm:p-4 text-center shadow-xs relative overflow-hidden [page-break-inside:avoid] [break-inside:avoid]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#ff3b2e] to-[#ff6b5e]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-[#996f12]",
									children: "Subscriber Milestone"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-center justify-center gap-1.5 text-sm sm:text-lg font-black text-slate-900",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 sm:w-5 sm:h-5 text-[#ff3b2e] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "truncate",
										children: [subscriberCount || "100,000", "+ Subs"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[9px] sm:text-[10px] text-emerald-700 mt-0.5 font-semibold flex items-center justify-center gap-1 truncate",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3 h-3 text-emerald-600 shrink-0" }), " Verified Channel"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-[#c59b27]/40 bg-white p-3 sm:p-4 text-center shadow-xs relative overflow-hidden [page-break-inside:avoid] [break-inside:avoid]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-600" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-[#996f12]",
									children: "Certificate Reference"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-xs sm:text-sm font-extrabold text-slate-800 tracking-wide truncate",
									children: certificateId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[9px] sm:text-[10px] text-slate-500 mt-0.5 font-medium truncate",
									children: ["Issued: ", issueDate]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cert-footer-row relative z-10 mt-5 pt-4 border-t border-[#c59b27]/30 flex flex-row items-center justify-between gap-4 sm:gap-6 [page-break-inside:avoid] [break-inside:avoid]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 sm:gap-3 bg-[#faf8f5] p-2 sm:p-2.5 rounded-xl border border-[#c59b27]/30 shrink-0 [page-break-inside:avoid] [break-inside:avoid]",
							children: [qrCodeUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: qrCodeUrl,
								alt: "Certificate Verification QR Code",
								className: "w-13 h-13 sm:w-15 sm:h-15 rounded-md bg-white p-0.5 border border-slate-200 shrink-0"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-13 h-13 sm:w-15 sm:h-15 rounded-md bg-slate-200 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left space-y-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] sm:text-[11px] font-black text-[#996f12] uppercase tracking-wider",
										children: "Scan to Verify"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] sm:text-[10px] text-slate-600 max-w-[130px] leading-tight",
										children: "Cryptographically verified on FaceTube Registry"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[8px] sm:text-[9px] font-mono text-slate-500",
										children: certificateId.slice(-12)
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center text-center shrink-0 [page-break-inside:avoid] [break-inside:avoid]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-13 h-13 sm:w-15 sm:h-15 rounded-full border-2 border-[#c59b27] bg-gradient-to-br from-[#ffd54f] via-[#ffb300] to-[#e68a00] p-1 flex items-center justify-center shadow-md relative",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full h-full rounded-full border border-dashed border-amber-900/40 flex flex-col items-center justify-center text-amber-950 font-black",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[7px] sm:text-[8px] tracking-tighter uppercase font-bold leading-none",
											children: "FaceTube"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-950 my-0.5" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[6px] sm:text-[7px] tracking-tighter uppercase font-bold leading-none",
											children: "Official"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[8px] sm:text-[9px] font-bold text-[#996f12] uppercase tracking-widest mt-1",
								children: "Verified Seal"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-end text-right space-y-0.5 sm:space-y-1 shrink-0 [page-break-inside:avoid] [break-inside:avoid]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif italic text-lg sm:text-2xl text-slate-800 font-normal tracking-wide select-none",
									children: "Marcus Sterling & Board"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-0.5 w-32 sm:w-36 bg-[#c59b27]/80" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] sm:text-xs font-bold text-slate-900 tracking-wide",
									children: "Authorized Signature"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] text-slate-600 font-medium",
									children: "FaceTube Global Creator Governance Board"
								})
							]
						})
					]
				})
			]
		})
	});
});
DigitalCertificateCard.displayName = "DigitalCertificateCard";
function MyCertificatePage() {
	const { user, profile, dbUser } = useAuth();
	const userName = profile?.full_name || profile?.name || dbUser?.name || user?.user_metadata?.name || user?.user_metadata?.full_name || "Alex Rivera";
	const userId = profile?.user_id || dbUser?.user_id || user?.user_metadata?.user_id || "FT483921";
	const userEmail = user?.email || profile?.email || dbUser?.email || "alex.rivera@facetube.app";
	const actualSubscribers = 128400;
	const earnedRank = calculateRankFromSubscribers(actualSubscribers);
	const [selectedRank, setSelectedRank] = (0, import_react.useState)(() => {
		const saved = localStorage.getItem(`facetube_current_rank_${userId}`);
		return saved ? getRankDetails(saved) : earnedRank;
	});
	const [subscriberDisplay, setSubscriberDisplay] = (0, import_react.useState)("128,400");
	const certificateId = import_react.useMemo(() => {
		return generateAutoCertificateId(userId, selectedRank.name);
	}, [userId, selectedRank.name]);
	const issueDate = import_react.useMemo(() => {
		return (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
			month: "long",
			day: "numeric",
			year: "numeric"
		});
	}, []);
	const certificateRef = (0, import_react.useRef)(null);
	const [downloadingPdf, setDownloadingPdf] = (0, import_react.useState)(false);
	const [sendingEmail, setSendingEmail] = (0, import_react.useState)(false);
	const [emailSentSuccess, setEmailSentSuccess] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (localStorage.getItem(`facetube_last_cert_rank_${userId}`) !== selectedRank.name && userEmail) {
			const timer = setTimeout(async () => {
				try {
					let base64Pdf;
					if (certificateRef.current) try {
						const formattedUserId = userId.startsWith("FT") ? userId : `FT${userId}`;
						base64Pdf = (await captureCertificatePdf(certificateRef.current, {
							filename: `Facetube_Certificate_${formattedUserId}.pdf`,
							userId: formattedUserId
						})).base64;
					} catch (err) {
						console.warn("Could not capture PDF for auto-email attachment:", err);
					}
					if ((await sendCertificateEmailApi({
						userName,
						userId,
						email: userEmail,
						rank: selectedRank.name,
						subscribers: `${subscriberDisplay}+`,
						certificateId,
						issueDate,
						pdfBase64: base64Pdf,
						reason: `New Creator Rank Milestone: ${selectedRank.name}`
					})).success) {
						localStorage.setItem(`facetube_last_cert_rank_${userId}`, selectedRank.name);
						localStorage.setItem(`facetube_current_rank_${userId}`, selectedRank.name);
						setEmailSentSuccess(true);
						toast.success(`🎉 Rank Milestone Achieved! Your official ${selectedRank.name} Certificate has been automatically emailed to ${userEmail}.`, {
							duration: 6e3,
							description: `Certificate ID: ${certificateId}`
						});
					}
				} catch (err) {
					console.error("Auto-send certificate email error:", err);
				}
			}, 1200);
			return () => clearTimeout(timer);
		}
	}, [
		selectedRank,
		userId,
		userName,
		userEmail,
		subscriberDisplay,
		certificateId,
		issueDate
	]);
	const handleDownloadPdf = async () => {
		if (!certificateRef.current) return;
		try {
			setDownloadingPdf(true);
			toast.info("Generating high-resolution Certificate PDF (Single A4)...", { duration: 2500 });
			const formattedUserId = userId.startsWith("FT") ? userId : `FT${userId}`;
			const filename = `Facetube_Certificate_${formattedUserId}.pdf`;
			(await captureCertificatePdf(certificateRef.current, {
				filename,
				userId: formattedUserId
			})).download();
			toast.success("Certificate PDF downloaded successfully (Single A4 Page)!");
		} catch (err) {
			console.error("Failed to download PDF:", err);
			toast.error("Failed to generate PDF. Please try again.");
		} finally {
			setDownloadingPdf(false);
		}
	};
	const handlePrintCertificate = () => {
		if (!certificateRef.current) return;
		toast.info("Opening single-page print preview...", { duration: 1500 });
		printCertificateElement(certificateRef.current);
	};
	const handleEmailCertificate = async () => {
		try {
			setSendingEmail(true);
			toast.info(`Preparing Certificate for ${userEmail}...`, { duration: 2e3 });
			let base64Pdf;
			if (certificateRef.current) try {
				const formattedUserId = userId.startsWith("FT") ? userId : `FT${userId}`;
				base64Pdf = (await captureCertificatePdf(certificateRef.current, {
					filename: `Facetube_Certificate_${formattedUserId}.pdf`,
					userId: formattedUserId
				})).base64;
			} catch (_e) {}
			const result = await sendCertificateEmailApi({
				userName,
				userId,
				email: userEmail,
				rank: selectedRank.name,
				subscribers: `${subscriberDisplay}+`,
				certificateId,
				issueDate,
				pdfBase64: base64Pdf,
				reason: "User requested Certificate copy"
			});
			if (result.success) {
				setEmailSentSuccess(true);
				toast.success(`Digital Certificate sent to ${userEmail}!`, { description: `Delivered to your inbox with Certificate ID: ${certificateId}` });
			} else toast.error("Could not send email", { description: result.error || "Please verify SMTP credentials in Settings." });
		} catch (err) {
			toast.error("Failed to dispatch certificate email", { description: err.message || "Network error" });
		} finally {
			setSendingEmail(false);
		}
	};
	const handleSelectRank = (rankInfo) => {
		setSelectedRank(rankInfo);
		setSubscriberDisplay(rankInfo.formattedSubscribers);
		toast.info(`Certificate updated for ${rankInfo.levelLabel}: ${rankInfo.awardName}`, { description: `Requirement: ${rankInfo.formattedSubscribers} verified subscribers.` });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6 max-w-7xl mx-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
							children: "📜 My Certificate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-500",
							children: "Verified Active"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-0.5",
						children: "Official FaceTube Digital Certificate of Creator Excellence across all 10 Creator Rank Milestones"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							id: "btn-download-pdf",
							onClick: handleDownloadPdf,
							disabled: downloadingPdf,
							className: "inline-flex items-center justify-center gap-2 rounded-xl bg-brand px-4 py-2.5 text-xs sm:text-sm font-bold text-white shadow-lg shadow-brand/20 transition hover:bg-brand-dark active:scale-95 disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: `h-4 w-4 ${downloadingPdf ? "animate-bounce" : ""}` }), downloadingPdf ? "Generating PDF..." : "Download PDF"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							id: "btn-print-certificate",
							onClick: handlePrintCertificate,
							className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-secondary/80 px-4 py-2.5 text-xs sm:text-sm font-bold text-foreground transition hover:bg-secondary active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4 text-muted-foreground" }), "Print Certificate"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							id: "btn-email-certificate",
							onClick: handleEmailCertificate,
							disabled: sendingEmail,
							className: "inline-flex items-center justify-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-xs sm:text-sm font-bold text-amber-500 transition hover:bg-amber-500/20 active:scale-95 disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: `h-4 w-4 ${sendingEmail ? "animate-spin" : ""}` }), sendingEmail ? "Sending..." : "Email Certificate"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-transparent p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-5 h-5 text-amber-500" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-black text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Automatic Rank Achievement Certificate Delivery" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase font-bold tracking-wider bg-brand/20 text-brand px-2 py-0.5 rounded-full",
							children: "Automated"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: [
							"Calculated dynamically from your verified subscriber count (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "text-foreground",
								children: [actualSubscribers.toLocaleString(), " subscribers"]
							}),
							"). Achieved rank:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-amber-500 font-bold",
								children: earnedRank.awardName
							}),
							"."
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							navigator.clipboard.writeText(`${window.location.origin}/my-certificate?verify=${encodeURIComponent(certificateId)}`);
							toast.success("Verification link copied to clipboard!");
						},
						className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-xs font-semibold text-muted-foreground hover:text-foreground transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-3.5 h-3.5" }), "Copy Verification Link"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-bold text-foreground uppercase tracking-wider",
							children: "Live Official Accreditation Document"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground font-mono",
						children: ["ID: ", certificateId]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto pb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-[680px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigitalCertificateCard, {
							ref: certificateRef,
							userName,
							userId,
							rank: selectedRank.awardName,
							subscriberCount: subscriberDisplay,
							certificateId,
							issueDate
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 sm:p-6 space-y-4 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-base font-extrabold text-foreground flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-brand" }), "Creator Rank & Rewards (All 10 Levels)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-0.5",
							children: "Exact 10-level creator structure calculated from your channel subscribers. Click any level to inspect its accredited certificate."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20",
							children: [
								"Active Tier: ",
								selectedRank.levelLabel,
								" (",
								selectedRank.awardName,
								")"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3",
						children: CREATOR_RANKS.map((r) => {
							const isSelected = r.id === selectedRank.id;
							const isAchieved = actualSubscribers >= r.minSubscribers;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => handleSelectRank(r),
								className: `flex flex-col items-center text-center p-4 rounded-xl border transition-all relative ${isSelected ? "border-amber-400 bg-amber-500/10 shadow-md ring-2 ring-amber-400/30" : isAchieved ? "border-emerald-500/30 bg-emerald-500/5 hover:border-emerald-500/60" : "border-border bg-secondary/30 hover:bg-secondary opacity-75 hover:opacity-100"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between w-full mb-1 text-[10px] font-black uppercase tracking-wider",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-amber-500",
											children: r.levelLabel
										}), isAchieved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-0.5 text-emerald-500 font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3 h-3" }), " Achieved"]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-0.5 text-muted-foreground font-medium",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2.5 h-2.5" }), " Locked"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl my-1",
										children: r.badge
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-black text-foreground leading-snug",
										children: r.awardName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-muted-foreground mt-1 font-semibold",
										children: [r.formattedSubscribers, " Subscribers"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `mt-3 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full w-full ${isSelected ? "bg-amber-400 text-black shadow-xs" : isAchieved ? "bg-emerald-500/20 text-emerald-500" : "bg-secondary text-muted-foreground"}`,
										children: isSelected ? "Viewing Certificate" : isAchieved ? "Unlocked" : "Progressing"
									})
								]
							}, r.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-secondary/40 p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-5 w-5 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-foreground",
									children: "Registered Creator: "
								}),
								userName,
								" (",
								userId,
								") · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: userEmail
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Official single-page printable document verified" })]
						})]
					})
				]
			})
		]
	}) });
}
//#endregion
export { MyCertificatePage as component };
