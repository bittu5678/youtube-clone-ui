import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, i as ThemeProvider, l as useAuth, r as Logo, t as AuthProvider, u as api } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useRouter, X as notFound, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, q as redirect, v as createFileRoute, x as useNavigate, y as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { $ as Menu, $t as CheckCheck, A as ScrollText, Bt as Compass, C as ShieldCheck, E as Settings, Ft as DollarSign, Gt as CircleQuestionMark, Ht as Clock, Kt as CircleCheck, L as Plus, M as RefreshCw, O as Search, R as Play, Rt as CornerDownRight, V as Pause, Wt as Clapperboard, X as MessageSquare, Y as Mic, Zt as ChevronDown, an as Bell, c as User, ct as LayoutDashboard, dn as ArrowDownToLine, et as Megaphone, ft as Info, g as ThumbsUp, gt as History, h as Trash2, ht as House, it as LogOut, l as UserPlus, m as TrendingUp, mt as Image, n as X, o as Video, r as Wallet, s as Users, un as ArrowLeft, w as ShieldAlert, y as Sparkles } from "../_libs/lucide-react.mjs";
import { a as thumb_5_default, i as thumb_3_default, o as thumb_6_default, r as thumb_1_default, t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thumb-4-Bisppr30.js
var thumb_2_default = "/assets/thumb-2-D9wgIhan.jpg";
var thumb_4_default = "/assets/thumb-4-DoWflXCY.jpg";
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/videos-DnsVAqOc.js
var categories = ["All", ...[
	"Motivational",
	"Comedy",
	"Blog",
	"Movie",
	"Entertainment",
	"Cooking",
	"Finance",
	"Share Market",
	"Business",
	"Crypto",
	"Coding"
]];
var recommended = [
	{
		id: "v1",
		category: "Coding",
		description: "A full walkthrough of building a production-grade React dashboard: routing, data fetching, charts, and a design system that scales.",
		title: "Build a Production-Ready React Dashboard in One Sitting",
		channel: "CodeCanvas",
		initials: "CC",
		views: "842K views",
		age: "2 days ago",
		duration: "24:18",
		thumb: thumb_1_default,
		tint: "oklch(0.45 0.15 27)"
	},
	{
		id: "v2",
		category: "Motivational",
		description: "The mindset shift and discipline needed to reach elite performance and master complex skills in 2026.",
		title: "How to Build Relentless Focus & Mental Stamina",
		channel: "Deep Signal",
		initials: "DS",
		views: "1.4M views",
		age: "5 days ago",
		duration: "18:02",
		thumb: thumb_2_default,
		tint: "oklch(0.4 0.18 340)"
	},
	{
		id: "v3",
		category: "Entertainment",
		description: "Watch a complete cinematic soundtrack come together from a single melody loop — sampling, drums, mixing and mastering.",
		title: "Cinematic Sound Studio Session: Making a Score from Scratch",
		channel: "Redroom Audio",
		initials: "RA",
		views: "306K views",
		age: "1 week ago",
		duration: "42:55",
		thumb: thumb_3_default,
		tint: "oklch(0.42 0.17 20)"
	},
	{
		id: "v4",
		category: "Comedy",
		description: "Hilarious sketches and real-world reactions to modern developer problems and startup culture.",
		title: "Tech Startup Standup: Hilarious Realities of Modern Work",
		channel: "NovaPlays",
		initials: "NP",
		views: "2.1M views",
		age: "3 hours ago",
		duration: "11:37",
		thumb: thumb_4_default,
		tint: "oklch(0.4 0.16 300)"
	},
	{
		id: "v5",
		category: "Business",
		description: "How to scale an enterprise brand, optimize creator economics, and build enduring distribution moats.",
		title: "Creator Economy 2026: Scaling from Zero to Enterprise",
		channel: "Studio Grid",
		initials: "SG",
		views: "97K views",
		age: "4 days ago",
		duration: "32:09",
		thumb: thumb_5_default,
		tint: "oklch(0.7 0.02 260)"
	},
	{
		id: "v6",
		category: "Finance",
		description: "Comprehensive breakdown of wealth compounding, index funds, cash flow management and early retirement planning.",
		title: "Smart Financial Freedom Blueprint: Compounding & Cash Flow",
		channel: "Signal & Noise",
		initials: "SN",
		views: "512K views",
		age: "6 days ago",
		duration: "1:04:22",
		thumb: thumb_6_default,
		tint: "oklch(0.45 0.19 15)"
	},
	{
		id: "v7",
		category: "Share Market",
		description: "Intraday price action, swing trading strategies, order book liquidity and risk mitigation rules.",
		title: "Mastering the Share Market: Technical Analysis & Risk Management",
		channel: "CodeCanvas",
		initials: "CC",
		views: "428K views",
		age: "12 days ago",
		duration: "27:44",
		thumb: thumb_1_default,
		tint: "oklch(0.45 0.15 27)"
	},
	{
		id: "v8",
		category: "Crypto",
		description: "DeFi primitives, liquidity pools, cross-chain bridges and decentralized infrastructure explained.",
		title: "Web3 & Crypto Architecture: What Every Builder Needs to Know",
		channel: "Deep Signal",
		initials: "DS",
		views: "1.1M views",
		age: "1 day ago",
		duration: "15:31",
		thumb: thumb_2_default,
		tint: "oklch(0.4 0.18 340)"
	}
];
var pick = (indexes) => indexes.map((i) => recommended[i]);
var trending = pick([
	3,
	1,
	5,
	0
]).map((v, i) => ({
	...v,
	id: `t${i}`
}));
var recent = pick([
	4,
	2,
	6,
	7
]).map((v, i) => ({
	...v,
	id: `r${i}`,
	age: `${i + 1} hours ago`
}));
var creators = [
	{
		name: "CodeCanvas",
		initials: "CC",
		subs: "1.2M subscribers",
		tag: "Coding"
	},
	{
		name: "Deep Signal",
		initials: "DS",
		subs: "890K subscribers",
		tag: "AI"
	},
	{
		name: "Redroom Audio",
		initials: "RA",
		subs: "460K subscribers",
		tag: "Music"
	},
	{
		name: "NovaPlays",
		initials: "NP",
		subs: "3.4M subscribers",
		tag: "Gaming"
	},
	{
		name: "Studio Grid",
		initials: "SG",
		subs: "212K subscribers",
		tag: "Design"
	},
	{
		name: "Signal & Noise",
		initials: "SN",
		subs: "775K subscribers",
		tag: "Podcasts"
	}
];
var allVideos = [
	...recommended,
	...trending,
	...recent
];
var findVideo = (id) => allVideos.find((v) => v.id === id);
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/Navbar-Codi0K3o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INITIAL_NOTIFICATIONS = [
	{
		id: "notif-1",
		type: "subscriber",
		title: "New Subscriber",
		description: "Alex Rivera subscribed to your channel",
		time: "2 min ago",
		unread: true
	},
	{
		id: "notif-2",
		type: "comment",
		title: "New Comment",
		description: "Marcus Bell commented: 'Brilliant explanation on state management!'",
		time: "15 min ago",
		unread: true
	},
	{
		id: "notif-3",
		type: "like",
		title: "New Like",
		description: "Elena Rostova and 28 others liked your video",
		time: "1 hour ago",
		unread: true
	},
	{
		id: "notif-4",
		type: "earnings",
		title: "Premium Earnings",
		description: "$142.50 earned from ad placements and creator revenue",
		time: "3 hours ago",
		unread: true
	},
	{
		id: "notif-5",
		type: "update",
		title: "System Update",
		description: "FaceTube 2.4 update: 4K 60fps streaming & creator tools are now live",
		time: "1 day ago",
		unread: true
	}
];
function Navbar({ onToggleSidebar, query, onQueryChange }) {
	const { user, profile, role, isAdmin, signOut } = useAuth();
	const [profileOpen, setProfileOpen] = (0, import_react.useState)(false);
	const [notificationsOpen, setNotificationsOpen] = (0, import_react.useState)(false);
	const [notifications, setNotifications] = (0, import_react.useState)(INITIAL_NOTIFICATIONS);
	const [suggestionsOpen, setSuggestionsOpen] = (0, import_react.useState)(false);
	const [searchInput, setSearchInput] = (0, import_react.useState)(query ?? "");
	const [isListening, setIsListening] = (0, import_react.useState)(false);
	const [mobileSearchOpen, setMobileSearchOpen] = (0, import_react.useState)(false);
	const dropdownRef = (0, import_react.useRef)(null);
	const notifDropdownRef = (0, import_react.useRef)(null);
	const searchContainerRef = (0, import_react.useRef)(null);
	const mobileSearchContainerRef = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	const mobileInputRef = (0, import_react.useRef)(null);
	const recognitionRef = (0, import_react.useRef)(null);
	const navigate = useNavigate();
	const unreadCount = notifications.filter((n) => n.unread).length;
	const popularSuggestions = (0, import_react.useMemo)(() => [
		"React Dashboard",
		"Neural Networks Explainer",
		"TypeScript 5.5",
		"CSS Grid & Flexbox",
		"System Design Interview",
		"Vite Performance",
		"Next.js vs Remix",
		"AI Agents Full Course"
	], []);
	const filteredSuggestions = (0, import_react.useMemo)(() => {
		const q = searchInput.trim().toLowerCase();
		if (!q) return popularSuggestions.slice(0, 6);
		const set = /* @__PURE__ */ new Set();
		for (const v of allVideos) {
			if (v.title.toLowerCase().includes(q)) set.add(v.title);
			if (v.category.toLowerCase().includes(q)) set.add(v.category);
			if (v.channel.toLowerCase().includes(q)) set.add(v.channel);
		}
		for (const p of popularSuggestions) if (p.toLowerCase().includes(q)) set.add(p);
		const list = Array.from(set);
		return list.length > 0 ? list.slice(0, 7) : popularSuggestions.slice(0, 5);
	}, [searchInput, popularSuggestions]);
	(0, import_react.useEffect)(() => {
		if (query !== void 0) setSearchInput(query);
	}, [query]);
	(0, import_react.useEffect)(() => {
		function handleClickOutside(e) {
			if (dropdownRef.current && !dropdownRef.current.contains(e.target)) setProfileOpen(false);
			if (notifDropdownRef.current && !notifDropdownRef.current.contains(e.target)) setNotificationsOpen(false);
			if (searchContainerRef.current && !searchContainerRef.current.contains(e.target)) setSuggestionsOpen(false);
			if (mobileSearchContainerRef.current && !mobileSearchContainerRef.current.contains(e.target)) {}
		}
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (recognitionRef.current) try {
				recognitionRef.current.abort();
			} catch {}
		};
	}, []);
	const handleSearchSubmit = (0, import_react.useCallback)((term) => {
		const trimmed = term.trim();
		onQueryChange?.(trimmed);
		navigate({
			to: "/",
			search: { q: trimmed || void 0 }
		});
		setMobileSearchOpen(false);
	}, [navigate, onQueryChange]);
	const startListening = async () => {
		const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
		if (!SpeechRecognition) {
			toast.error("Voice search is not supported in this browser. Please try Google Chrome, Microsoft Edge, or Apple Safari.");
			return;
		}
		if (navigator.mediaDevices?.getUserMedia) try {
			(await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((track) => track.stop());
		} catch (err) {
			const error = err;
			if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
				toast.error("Microphone permission denied");
				return;
			}
		}
		try {
			if (recognitionRef.current) try {
				recognitionRef.current.abort();
			} catch {}
			const recognition = new SpeechRecognition();
			recognition.continuous = false;
			recognition.interimResults = true;
			recognition.lang = navigator.language || "en-US";
			recognition.maxAlternatives = 1;
			let recognizedText = "";
			recognition.onstart = () => {
				setIsListening(true);
			};
			recognition.onresult = (event) => {
				let finalTranscript = "";
				let interimTranscript = "";
				for (let i = event.resultIndex; i < event.results.length; ++i) {
					const result = event.results[i];
					if (result.isFinal) finalTranscript += result[0].transcript;
					else interimTranscript += result[0].transcript;
				}
				const currentText = (finalTranscript || interimTranscript).trim();
				if (currentText) {
					recognizedText = currentText;
					setSearchInput(currentText);
					onQueryChange?.(currentText);
				}
			};
			recognition.onerror = (event) => {
				setIsListening(false);
				if (event.error === "not-allowed" || event.error === "service-not-allowed") toast.error("Microphone permission denied");
			};
			recognition.onend = () => {
				setIsListening(false);
				if (recognizedText.trim()) {
					const finalQuery = recognizedText.trim();
					setSearchInput(finalQuery);
					const activeInput = inputRef.current || mobileInputRef.current;
					if (activeInput) {
						activeInput.value = finalQuery;
						activeInput.dispatchEvent(new Event("input", { bubbles: true }));
						activeInput.dispatchEvent(new KeyboardEvent("keydown", {
							key: "Enter",
							code: "Enter",
							keyCode: 13,
							which: 13,
							bubbles: true,
							cancelable: true
						}));
					}
					handleSearchSubmit(finalQuery);
				}
			};
			recognitionRef.current = recognition;
			recognition.start();
		} catch {
			setIsListening(false);
		}
	};
	const handleToggleVoiceSearch = () => {
		if (isListening) {
			if (recognitionRef.current) try {
				recognitionRef.current.stop();
			} catch {}
			setIsListening(false);
		} else startListening();
	};
	const initials = profile?.username ? profile.username.substring(0, 2).toUpperCase() : user?.email ? user.email.substring(0, 2).toUpperCase() : "AK";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md",
		children: mobileSearchOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: mobileSearchContainerRef,
			className: "relative flex h-16 w-full items-center gap-2 px-2 md:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close search",
					onClick: () => {
						setMobileSearchOpen(false);
						setSuggestionsOpen(false);
					},
					className: "rounded-full p-2 text-foreground/80 transition hover:bg-secondary active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-5 w-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (e) => {
							e.preventDefault();
							setSuggestionsOpen(false);
							handleSearchSubmit(searchInput);
						},
						className: "group flex h-10 w-full items-center rounded-full border border-border bg-secondary/60 pl-4 pr-1 transition focus-within:border-brand/50 focus-within:bg-background focus-within:shadow-lift",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: mobileInputRef,
								type: "search",
								placeholder: isListening ? "Listening…" : "Search videos, creators, topics…",
								value: searchInput,
								onFocus: () => setSuggestionsOpen(true),
								onChange: (e) => {
									setSearchInput(e.target.value);
									setSuggestionsOpen(true);
									onQueryChange?.(e.target.value);
								},
								onKeyDown: (e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										setSuggestionsOpen(false);
										handleSearchSubmit(searchInput);
									}
								},
								autoFocus: true,
								className: "h-full w-full min-w-0 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								"aria-label": "Search",
								className: "grid h-8 w-9 shrink-0 place-items-center rounded-full bg-brand text-brand-foreground transition hover:bg-brand-dark",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
							})
						]
					}), suggestionsOpen && filteredSuggestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute left-0 right-0 top-12 z-50 overflow-hidden rounded-2xl border border-border bg-card shadow-2xl animate-in fade-in",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
							children: "Search suggestions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "py-1",
							children: filteredSuggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onMouseDown: (e) => {
									e.preventDefault();
									setSearchInput(item);
									setSuggestionsOpen(false);
									handleSearchSubmit(item);
								},
								className: "flex w-full items-center gap-3 px-4 py-2.5 text-left text-xs font-medium text-foreground transition hover:bg-secondary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: item
								})]
							}, item))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Search with voice",
					onClick: handleToggleVoiceSearch,
					className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary text-foreground/80 transition hover:bg-brand/10 hover:text-brand",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-4 w-4" })
				}),
				isListening && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					"aria-live": "polite",
					className: "pointer-events-none absolute -bottom-2.5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-border bg-card/95 px-3 py-0.5 text-xs font-semibold text-red-500 shadow-md backdrop-blur-sm animate-in fade-in",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "relative flex h-2 w-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex h-2 w-2 rounded-full bg-red-500" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Listening..." })]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-16 items-center gap-2 px-3 sm:gap-4 sm:px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Toggle menu",
					onClick: onToggleSidebar,
					className: "rounded-full p-2 text-foreground/80 transition hover:bg-secondary active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: searchContainerRef,
					className: "relative mx-auto hidden w-full max-w-xl items-center gap-2 md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: (e) => {
									e.preventDefault();
									setSuggestionsOpen(false);
									handleSearchSubmit(searchInput);
								},
								className: "group flex h-10 w-full items-center rounded-full border border-border bg-secondary/60 pl-4 pr-1 transition focus-within:border-brand/50 focus-within:bg-background focus-within:shadow-lift",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: inputRef,
										type: "search",
										placeholder: isListening ? "Listening…" : "Search videos, creators, topics…",
										value: searchInput,
										onFocus: () => setSuggestionsOpen(true),
										onChange: (e) => {
											setSearchInput(e.target.value);
											setSuggestionsOpen(true);
											onQueryChange?.(e.target.value);
										},
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												e.preventDefault();
												setSuggestionsOpen(false);
												handleSearchSubmit(searchInput);
											}
										},
										className: "h-full w-full min-w-0 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										"aria-label": "Search",
										className: "grid h-8 w-9 shrink-0 place-items-center rounded-full bg-brand text-brand-foreground transition hover:bg-brand-dark",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
									})
								]
							}), suggestionsOpen && filteredSuggestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute left-0 right-0 top-12 z-50 overflow-hidden rounded-2xl border border-border bg-card shadow-2xl animate-in fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-border/50 px-4 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3 text-brand" }), "Search Suggestions"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Press Enter to search" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "py-1",
									children: filteredSuggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onMouseDown: (e) => {
											e.preventDefault();
											setSearchInput(item);
											setSuggestionsOpen(false);
											handleSearchSubmit(item);
										},
										className: "flex w-full items-center gap-3 px-4 py-2.5 text-left text-xs font-medium text-foreground transition hover:bg-secondary group",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground group-hover:text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: item
										})]
									}, item))
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Search with voice",
							onClick: handleToggleVoiceSearch,
							className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary text-foreground/80 transition hover:bg-brand/10 hover:text-brand",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-4 w-4" })
						}),
						isListening && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							role: "status",
							"aria-live": "polite",
							className: "pointer-events-none absolute -bottom-7 left-1/2 z-50 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-border bg-card/95 px-3 py-0.5 text-xs font-semibold text-red-500 shadow-md backdrop-blur-sm animate-in fade-in",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative flex h-2 w-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex h-2 w-2 rounded-full bg-red-500" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Listening..." })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-1.5 sm:gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Search",
							onClick: () => setMobileSearchOpen(true),
							className: "grid h-10 w-10 place-items-center rounded-full text-foreground/80 transition hover:bg-secondary md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-5 w-5" })
						}),
						isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/admin",
							className: "hidden items-center gap-1.5 rounded-full border border-brand/40 bg-brand/10 px-3.5 py-1.5 text-xs font-bold text-brand transition hover:bg-brand hover:text-brand-foreground sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" }), "Admin"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/upload",
							className: "hidden items-center gap-1.5 rounded-full bg-brand px-4 py-2 text-sm font-semibold text-brand-foreground shadow-lift transition hover:bg-brand-dark active:scale-95 sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Create"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							ref: notifDropdownRef,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-label": "Notifications",
								onClick: () => {
									setNotificationsOpen((prev) => !prev);
									setProfileOpen(false);
								},
								className: "relative grid h-10 w-10 place-items-center rounded-full text-foreground/80 transition hover:bg-secondary active:scale-95",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-5 w-5" }), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-white ring-2 ring-background",
									children: unreadCount
								})]
							}), notificationsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 top-12 z-50 w-80 sm:w-96 rounded-2xl border border-border bg-card p-2 shadow-2xl animate-in fade-in zoom-in-95",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-border/70 px-3 py-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-bold text-foreground",
											children: "Notifications"
										}), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-full bg-brand/15 px-2 py-0.5 text-[10px] font-bold text-brand",
											children: [unreadCount, " new"]
										})]
									}), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setNotifications((prev) => prev.map((n) => ({
											...n,
											unread: false
										}))),
										className: "flex items-center gap-1 text-[11px] font-semibold text-muted-foreground transition hover:text-brand",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3.5 w-3.5" }), "Mark all as read"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-h-[360px] overflow-y-auto divide-y divide-border/40 py-1",
									children: notifications.map((n) => {
										const Icon = n.type === "subscriber" ? UserPlus : n.type === "comment" ? MessageSquare : n.type === "like" ? ThumbsUp : n.type === "earnings" ? DollarSign : Sparkles;
										const iconColor = n.type === "subscriber" ? "bg-brand/15 text-brand" : n.type === "comment" ? "bg-blue-500/15 text-blue-500" : n.type === "like" ? "bg-amber-500/15 text-amber-500" : n.type === "earnings" ? "bg-emerald-500/15 text-emerald-500" : "bg-purple-500/15 text-purple-500";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setNotifications((prev) => prev.map((item) => item.id === n.id ? {
												...item,
												unread: false
											} : item)),
											className: `flex w-full items-start gap-3 rounded-xl p-2.5 text-left transition hover:bg-secondary ${n.unread ? "bg-secondary/40 font-medium" : "opacity-80"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `grid h-9 w-9 shrink-0 place-items-center rounded-full ${iconColor}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs font-bold text-foreground",
															children: n.title
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] leading-relaxed text-muted-foreground line-clamp-2",
															children: n.description
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "mt-1 text-[10px] text-muted-foreground/75",
															children: n.time
														})
													]
												}),
												n.unread && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand ring-2 ring-background" })
											]
										}, n.id);
									})
								})]
							})]
						}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							ref: dropdownRef,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Your profile",
								onClick: () => {
									setProfileOpen((v) => !v);
									setNotificationsOpen(false);
								},
								className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-xs font-bold text-brand-foreground ring-2 ring-transparent transition hover:ring-brand/30",
								children: initials
							}), profileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 top-12 z-50 w-60 rounded-2xl border border-border bg-card p-2 shadow-2xl animate-in fade-in zoom-in-95",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-b border-border/70 px-3 py-2.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs font-bold text-foreground",
												children: profile?.full_name || `@${profile?.username || user.email?.split("@")[0]}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-[11px] text-muted-foreground",
												children: user.email
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5 flex items-center gap-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${isAdmin ? "bg-brand/15 text-brand" : "bg-secondary text-muted-foreground"}`,
													children: ["Role: ", role]
												})
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "py-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/dashboard",
												onClick: () => setProfileOpen(false),
												className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-foreground transition hover:bg-secondary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4 text-brand" }), "Dashboard"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/profile",
												onClick: () => setProfileOpen(false),
												className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-foreground transition hover:bg-secondary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 text-muted-foreground" }), "My Profile"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/your-videos",
												onClick: () => setProfileOpen(false),
												className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-foreground transition hover:bg-secondary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-4 w-4 text-muted-foreground" }), "Your Videos"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/settings",
												onClick: () => setProfileOpen(false),
												className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-foreground transition hover:bg-secondary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4 text-muted-foreground" }), "Settings"]
											}),
											isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/admin",
												onClick: () => setProfileOpen(false),
												className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-foreground transition hover:bg-secondary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-brand" }), "Admin Dashboard"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-t border-border/70 pt-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: async () => {
												setProfileOpen(false);
												await signOut();
											},
											className: "flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-destructive transition hover:bg-destructive/10",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), "Logout"]
										})
									})
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth",
							className: "rounded-full border border-border px-4 py-2 text-sm font-semibold text-foreground transition hover:border-brand/40 hover:text-brand",
							children: "Sign in"
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/Sidebar-y-WCEXcp.js
function NavList({ onNavigate }) {
	const { isAdmin, signOut } = useAuth();
	const navigate = useNavigate();
	const currentPath = useRouterState().location.pathname;
	const isIncomeRoute = currentPath === "/income" || currentPath === "/referral-income" || currentPath === "/global-income" || currentPath === "/adsense-income" || currentPath === "/affiliate-income" || currentPath === "/direct-referral-income" || currentPath === "/team-income";
	const isYourVideosRoute = currentPath === "/your-videos" || currentPath === "/free-videos" || currentPath === "/premium-videos" || currentPath === "/short-videos" || currentPath === "/live-videos" || currentPath === "/advertisement-videos" || currentPath === "/images-uploaded";
	const [incomeExpanded, setIncomeExpanded] = (0, import_react.useState)(false);
	const [yourVideosExpanded, setYourVideosExpanded] = (0, import_react.useState)(false);
	const isHomeActive = currentPath === "/";
	const handleLogout = async () => {
		onNavigate?.();
		await signOut();
		navigate({ to: "/login" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "flex flex-col gap-1 p-3",
		children: [
			isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all ${currentPath === "/admin" ? "bg-brand text-white shadow-lift font-bold" : "bg-brand/10 text-brand hover:bg-brand/20"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-[18px] w-[18px] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Admin Portal"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${isHomeActive ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: `h-[18px] w-[18px] shrink-0 ${isHomeActive ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Home"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/referral-members",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/referral-members" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/referral-members" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Referral Members"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/team-members",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/team-members" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/team-members" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Team Members"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-expanded": incomeExpanded,
					onClick: () => setIncomeExpanded((prev) => !prev),
					className: `flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm transition-all ${isIncomeRoute && !incomeExpanded ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 truncate",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: `h-[18px] w-[18px] shrink-0 ${isIncomeRoute && !incomeExpanded ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: "Income Section"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-300 ease-in-out ${incomeExpanded ? "rotate-180 text-foreground" : ""} ${isIncomeRoute && !incomeExpanded ? "text-white" : ""}` })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `grid transition-all duration-300 ease-in-out ${incomeExpanded ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0 pointer-events-none"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-4 flex flex-col gap-1 border-l-2 border-border/60 py-1 pl-3 my-0.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/referral-income",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/referral-income" || currentPath === "/direct-referral-income" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/referral-income" || currentPath === "/direct-referral-income" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Referral Income"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/global-income",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/global-income" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/global-income" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Global Income"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/adsense-income",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/adsense-income" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/adsense-income" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "AdSense Income"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/affiliate-income",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/affiliate-income" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/affiliate-income" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Affiliate Income"
									})]
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/explore",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/explore" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/explore" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Explore"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/subscriptions",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/subscriptions" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/subscriptions" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Subscriptions"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/history",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/history" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/history" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "History"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/watch-later",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/watch-later" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/watch-later" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Watch Later"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/liked-videos",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/liked-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/liked-videos" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Liked Videos"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-expanded": yourVideosExpanded,
					onClick: () => setYourVideosExpanded((prev) => !prev),
					className: `flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm transition-all ${isYourVideosRoute && !yourVideosExpanded ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 truncate",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: `h-[18px] w-[18px] shrink-0 ${isYourVideosRoute && !yourVideosExpanded ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: "Your Videos"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-300 ease-in-out ${yourVideosExpanded ? "rotate-180 text-foreground" : ""} ${isYourVideosRoute && !yourVideosExpanded ? "text-white" : ""}` })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `grid transition-all duration-300 ease-in-out ${yourVideosExpanded ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0 pointer-events-none"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-4 flex flex-col gap-1 border-l-2 border-border/60 py-1 pl-3 my-0.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/free-videos",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/free-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/free-videos" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Free Videos"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/premium-videos",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/premium-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/premium-videos" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Premium Videos"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/short-videos",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/short-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/short-videos" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Short Videos"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/live-videos",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/live-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/live-videos" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Live Videos"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/advertisement-videos",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/advertisement-videos" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/advertisement-videos" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Advertisement Videos"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/images-uploaded",
									onClick: onNavigate,
									className: `flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs transition-all ${currentPath === "/images-uploaded" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/75 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownRight, { className: `h-3.5 w-3.5 shrink-0 ${currentPath === "/images-uploaded" ? "text-white stroke-[2.4]" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: "Images Uploaded"
									})]
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/wallet-balance",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/wallet-balance" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/wallet-balance" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Wallet Balance"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/withdrawal-balance",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/withdrawal-balance" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/withdrawal-balance" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Withdrawal Balance"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ads-promotions",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/ads-promotions" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/ads-promotions" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "📢 Ads Promotions"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/my-certificate",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/my-certificate" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/my-certificate" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "📜 My Certificate"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/settings",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/settings" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/settings" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Settings"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/help",
				onClick: onNavigate,
				className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${currentPath === "/help" ? "bg-brand text-white shadow-sm font-bold" : "text-foreground/80 hover:translate-x-0.5 hover:bg-secondary hover:text-foreground font-medium"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: `h-[18px] w-[18px] shrink-0 ${currentPath === "/help" ? "text-white stroke-[2.4]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Help"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: handleLogout,
				className: "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-foreground/80 transition-all hover:translate-x-0.5 hover:bg-destructive/10 hover:text-red-500",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-[18px] w-[18px] shrink-0 text-red-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Logout"
				})]
			})
		]
	});
}
function Sidebar({ open, drawerOpen, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: `sticky top-16 hidden h-[calc(100vh-4rem)] shrink-0 overflow-y-auto border-r border-border bg-background transition-[width] duration-300 lg:block ${open ? "w-60" : "w-0 overflow-hidden border-r-0"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 pb-8 text-xs leading-relaxed text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "About · Terms · Privacy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "© 2026 FaceTube"
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `fixed inset-0 z-50 lg:hidden ${drawerOpen ? "" : "pointer-events-none"}`,
		"aria-hidden": !drawerOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: `absolute inset-0 bg-black/50 transition-opacity duration-300 ${drawerOpen ? "opacity-100" : "opacity-0"}`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `absolute inset-y-0 left-0 w-64 bg-background shadow-2xl transition-transform duration-300 ${drawerOpen ? "translate-x-0" : "-translate-x-full"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					onClick: onClose,
					className: "rounded-full p-2 text-muted-foreground transition hover:bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, { onNavigate: onClose })]
		})]
	})] });
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/video-service-BBuIeT2Y.js
var VIDEO_CATEGORIES = [
	"Motivational",
	"Comedy",
	"Blog",
	"Movie",
	"Entertainment",
	"Cooking",
	"Finance",
	"Share Market",
	"Business",
	"Crypto",
	"Coding"
];
var LOCAL_STORAGE_VIDEOS_KEY = "facetube_uploaded_videos_v3";
var INITIAL_SEED_VIDEOS = [
	{
		id: "vid-seed-001",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "10 Coding Shortcuts Every React Dev Must Know #Shorts",
		description: "Lightning-fast developer workflow hacks in under 45 seconds.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=60",
		videoType: "free",
		contentType: "short",
		category: "Technology",
		duration: "0:42",
		views: 45200,
		likes: 3120,
		paymentStatus: "not_required",
		paymentAmount: 0,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 10368e5)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 10368e5)).toISOString()
	},
	{
		id: "vid-seed-002",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "Full Stack App Architecture from Scratch: Zero to Production",
		description: "Deep-dive 45-minute comprehensive architectural masterclass covering scalable backend and modern UI.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=60",
		videoType: "free",
		contentType: "long",
		category: "Education",
		duration: "42:15",
		views: 98400,
		likes: 8400,
		paymentStatus: "not_required",
		paymentAmount: 0,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 864e6)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 864e6)).toISOString()
	},
	{
		id: "vid-seed-003",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "Pro Monetization Hack: Unlocking High-CPM Niches #Shorts",
		description: "Exclusive creator strategy breakdown for maximum algorithmic engagement and monetization yield.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&auto=format&fit=crop&q=60",
		videoType: "premium",
		contentType: "short",
		category: "Business",
		duration: "0:58",
		views: 62100,
		likes: 5490,
		paymentStatus: "paid",
		paymentId: "pay_rzp_seed_001",
		paymentAmount: 6,
		isPromoted: true,
		promotionPlan: "plan-15-days",
		promotionExpiresAt: new Date(Date.now() + 864e6).toISOString(),
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 432e6)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 432e6)).toISOString()
	},
	{
		id: "vid-seed-004",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "Executive Masterclass: Building $10K/Month Video Funnels",
		description: "Full 1-hour verified premium course with step-by-step case studies and downloadable resources.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=800&auto=format&fit=crop&q=60",
		videoType: "premium",
		contentType: "long",
		category: "Masterclass",
		duration: "58:30",
		views: 31400,
		likes: 2980,
		paymentStatus: "paid",
		paymentId: "pay_rzp_seed_002",
		paymentAmount: 6,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 1728e5)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 1728e5)).toISOString()
	},
	{
		id: "vid-seed-005",
		userId: "FT900431",
		creatorName: "Maya Lin",
		title: "Cinematic Color Grading in 30 Seconds #Shorts",
		description: "LUT color correction tricks for mobile videographers.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=60",
		videoType: "free",
		contentType: "short",
		category: "Film",
		duration: "0:30",
		views: 18200,
		likes: 1200,
		paymentStatus: "not_required",
		paymentAmount: 0,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 5184e5)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 5184e5)).toISOString()
	},
	{
		id: "vid-seed-006",
		userId: "FT900431",
		creatorName: "Maya Lin",
		title: "Secret Lighting Setup for 4K Vertical Video #Shorts",
		description: "Lighting angles and diffusers used by professional film studios.",
		videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
		thumbnailUrl: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&auto=format&fit=crop&q=60",
		videoType: "premium",
		contentType: "short",
		category: "Film",
		duration: "0:45",
		views: 29500,
		likes: 2100,
		paymentStatus: "paid",
		paymentId: "pay_rzp_seed_003",
		paymentAmount: 6,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 2592e5)).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date(Date.now() - 2592e5)).toISOString()
	}
];
/**
* Loads uploaded videos from database or local store
*/
function getStoredVideos() {
	if (typeof window === "undefined") return INITIAL_SEED_VIDEOS;
	try {
		const raw = localStorage.getItem(LOCAL_STORAGE_VIDEOS_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed;
		}
		localStorage.setItem(LOCAL_STORAGE_VIDEOS_KEY, JSON.stringify(INITIAL_SEED_VIDEOS));
		return INITIAL_SEED_VIDEOS;
	} catch (_e) {
		return INITIAL_SEED_VIDEOS;
	}
}
function saveStoredVideos(videos) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(LOCAL_STORAGE_VIDEOS_KEY, JSON.stringify(videos));
	} catch (_e) {}
}
/**
* Fetches all videos or user-specific uploaded videos
*/
async function fetchUploadedVideos(userId) {
	try {
		const res = await api.videos.list({ userId });
		if (res && res.videos && res.videos.length > 0) return res.videos.map((d) => ({
			id: d.id,
			userId: d.user_id || d.userId,
			creatorName: d.creator_name || d.creatorName || "Creator",
			title: d.title,
			description: d.description || "",
			videoUrl: d.video_url || d.videoUrl || "",
			thumbnailUrl: d.thumbnail_url || d.thumbnailUrl || "",
			videoType: d.video_type || d.videoType || "free",
			contentType: d.content_type || d.contentType || "long",
			category: d.category || "General",
			duration: d.duration || "0:00",
			views: Number(d.views) || 0,
			likes: Number(d.likes) || 0,
			paymentStatus: d.payment_status || d.paymentStatus || "not_required",
			paymentId: d.payment_id || d.paymentId,
			paymentAmount: Number(d.payment_amount || d.paymentAmount) || 0,
			isPromoted: Boolean(d.is_promoted ?? d.isPromoted),
			promotionPlan: d.promotion_plan || d.promotionPlan,
			promotionExpiresAt: d.promotion_expires_at || d.promotionExpiresAt,
			createdAt: d.created_at || d.createdAt,
			updatedAt: d.updated_at || d.updatedAt || d.created_at || d.createdAt
		}));
	} catch (_e) {}
	const all = getStoredVideos();
	if (userId) {
		const norm = userId.trim().toUpperCase();
		return all.filter((v) => v.userId.trim().toUpperCase() === norm);
	}
	return all;
}
/**
* Calculates dynamically the FOUR separate video counts:
* 1. Free Short Video
* 2. Free Long Video
* 3. Premium Short Video
* 4. Premium Long Video
*/
async function calculateUserVideoCounts(userId) {
	const videos = await fetchUploadedVideos(userId);
	let freeShort = 0;
	let freeLong = 0;
	let premiumShort = 0;
	let premiumLong = 0;
	for (const v of videos) if (v.videoType === "free") {
		if (v.contentType === "short") freeShort++;
		else freeLong++;
	} else if (v.videoType === "premium") {
		if (v.paymentStatus === "paid" || v.paymentStatus === "not_required") {
			if (v.contentType === "short") premiumShort++;
			else premiumLong++;
		}
	}
	const totalFree = freeShort + freeLong;
	const totalPremium = premiumShort + premiumLong;
	const totalUploaded = totalFree + totalPremium;
	return {
		freeShort,
		freeLong,
		premiumShort,
		premiumLong,
		totalFree,
		totalPremium,
		totalUploaded
	};
}
/**
* Creates and records a newly uploaded video with strict payment verification
*/
async function recordNewVideoUpload(params) {
	const isPremium = params.videoType === "premium";
	const newVideo = {
		id: `vid-${Date.now()}-${Math.floor(Math.random() * 1e4)}`,
		userId: params.userId,
		creatorName: params.creatorName,
		title: params.title.trim(),
		description: params.description.trim(),
		videoUrl: params.videoUrl || (params.contentType === "short" ? "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" : "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
		thumbnailUrl: params.thumbnailUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=60",
		videoType: params.videoType,
		contentType: params.contentType,
		category: params.category || "Entertainment",
		duration: params.contentType === "short" ? "0:45" : "12:30",
		views: 0,
		likes: 0,
		paymentStatus: isPremium ? params.paymentStatus || "pending" : "not_required",
		paymentId: params.paymentId,
		paymentAmount: isPremium ? params.paymentAmount ?? 6 : 0,
		isPromoted: false,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	try {
		await api.videos.create({
			id: newVideo.id,
			user_id: newVideo.userId,
			creator_name: newVideo.creatorName,
			title: newVideo.title,
			description: newVideo.description,
			video_url: newVideo.videoUrl,
			thumbnail_url: newVideo.thumbnailUrl,
			video_type: newVideo.videoType,
			content_type: newVideo.contentType,
			category: newVideo.category,
			duration: newVideo.duration,
			payment_status: newVideo.paymentStatus,
			payment_id: newVideo.paymentId,
			payment_amount: newVideo.paymentAmount,
			is_promoted: false
		});
	} catch (_e) {}
	const all = getStoredVideos();
	if (!all.some((v) => v.id === newVideo.id || newVideo.paymentId && v.paymentId === newVideo.paymentId)) saveStoredVideos([newVideo, ...all]);
	return newVideo;
}
/**
* Activates promotion on an existing or new video upon verified payment
*/
async function markVideoPromoted(params) {
	const all = getStoredVideos();
	const index = all.findIndex((v) => v.id === params.videoId);
	const expiresAt = new Date(Date.now() + params.durationDays * 24 * 60 * 60 * 1e3).toISOString();
	if (index !== -1) {
		all[index].isPromoted = true;
		all[index].promotionPlan = params.planId;
		all[index].promotionExpiresAt = expiresAt;
		all[index].updatedAt = (/* @__PURE__ */ new Date()).toISOString();
		saveStoredVideos(all);
	}
	try {
		await api.videos.promote({
			videoId: params.videoId,
			planId: params.planId,
			durationDays: params.durationDays,
			paymentId: params.paymentId
		});
	} catch (_e) {}
	return true;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-vsnEDfJA.js
var LOCAL_STORAGE_LEDGER_KEY = "facetube_income_ledger_v3";
var LOCAL_STORAGE_WALLETS_KEY = "facetube_user_wallets_v3";
var INITIAL_SEED_LEDGER = [
	{
		id: "tx-init-001",
		transactionId: "TX_REF_91028341",
		userId: "FT483921",
		sourceUserId: "FT900431",
		sourceUserName: "Maya Lin",
		incomeType: "referral_income",
		amount: 1,
		status: "settled",
		description: "Direct Commission (₹1) for Premium Video upload by Maya Lin (FT900431)",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 2592e5)).toISOString()
	},
	{
		id: "tx-init-002",
		transactionId: "TX_GLB_84729103",
		userId: "FT483921",
		incomeType: "global_income",
		amount: 1.5,
		status: "settled",
		description: "Global Income Pool distribution share (1 of 2 eligible creators)",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 2592e5)).toISOString()
	},
	{
		id: "tx-init-003",
		transactionId: "TX_GLB_84729104",
		userId: "FT900431",
		incomeType: "global_income",
		amount: 1.5,
		status: "settled",
		description: "Global Income Pool distribution share (1 of 2 eligible creators)",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 2592e5)).toISOString()
	}
];
var INITIAL_SEED_WALLETS = {
	FT483921: {
		userId: "FT483921",
		balance: 4280.5,
		totalEarned: 7430.5,
		totalWithdrawn: 3150,
		referralIncome: 1079.5,
		globalIncome: 2450,
		adsenseIncome: 1890.2,
		affiliateIncome: 940.8,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	},
	FT102857: {
		userId: "FT102857",
		balance: 15400,
		totalEarned: 22e3,
		totalWithdrawn: 6600,
		referralIncome: 3400,
		globalIncome: 8200,
		adsenseIncome: 4500,
		affiliateIncome: 1300,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	},
	FT900431: {
		userId: "FT900431",
		balance: 850,
		totalEarned: 850,
		totalWithdrawn: 0,
		referralIncome: 120,
		globalIncome: 450,
		adsenseIncome: 280,
		affiliateIncome: 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	}
};
function getStoredLedger() {
	if (typeof window === "undefined") return INITIAL_SEED_LEDGER;
	try {
		const raw = localStorage.getItem(LOCAL_STORAGE_LEDGER_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed;
		}
		localStorage.setItem(LOCAL_STORAGE_LEDGER_KEY, JSON.stringify(INITIAL_SEED_LEDGER));
		return INITIAL_SEED_LEDGER;
	} catch {
		return INITIAL_SEED_LEDGER;
	}
}
function saveStoredLedger(transactions) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(LOCAL_STORAGE_LEDGER_KEY, JSON.stringify(transactions));
	} catch {}
}
function getStoredWallets() {
	if (typeof window === "undefined") return INITIAL_SEED_WALLETS;
	try {
		const raw = localStorage.getItem(LOCAL_STORAGE_WALLETS_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (typeof parsed === "object" && parsed !== null) return parsed;
		}
		localStorage.setItem(LOCAL_STORAGE_WALLETS_KEY, JSON.stringify(INITIAL_SEED_WALLETS));
		return INITIAL_SEED_WALLETS;
	} catch {
		return INITIAL_SEED_WALLETS;
	}
}
function saveStoredWallets(wallets) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(LOCAL_STORAGE_WALLETS_KEY, JSON.stringify(wallets));
	} catch {}
}
/**
* Retrieves the wallet for a user
*/
async function getUserWallet(userId) {
	const norm = userId.trim().toUpperCase();
	try {
		const res = await api.wallet.getBalance(norm);
		if (res && res.wallet) {
			const data = res.wallet;
			return {
				userId: data.user_id || data.userId || norm,
				balance: Number(data.balance) || 0,
				totalEarned: Number(data.total_earned || data.totalEarned) || 0,
				totalWithdrawn: Number(data.total_withdrawn || data.totalWithdrawn) || 0,
				referralIncome: Number(data.referral_income || data.referralIncome) || 0,
				globalIncome: Number(data.global_income || data.globalIncome) || 0,
				adsenseIncome: Number(data.adsense_income || data.adsenseIncome) || 0,
				affiliateIncome: Number(data.affiliate_income || data.affiliateIncome) || 0,
				updatedAt: data.updated_at || data.updatedAt || (/* @__PURE__ */ new Date()).toISOString()
			};
		}
	} catch (_e) {}
	const wallets = getStoredWallets();
	if (wallets[norm]) return wallets[norm];
	const newWallet = {
		userId: norm,
		balance: 0,
		totalEarned: 0,
		totalWithdrawn: 0,
		referralIncome: 0,
		globalIncome: 0,
		adsenseIncome: 0,
		affiliateIncome: 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	wallets[norm] = newWallet;
	saveStoredWallets(wallets);
	return newWallet;
}
/**
* Gets ledger transactions for a user
*/
async function getUserLedger(userId) {
	try {
		const res = await api.wallet.getTransactions(userId);
		if (res && res.transactions && res.transactions.length > 0) return res.transactions.map((d) => ({
			id: d.id,
			transactionId: d.transaction_id || d.transactionId,
			userId: d.user_id || d.userId,
			sourceUserId: d.source_user_id || d.sourceUserId,
			sourceUserName: d.source_user_name || d.sourceUserName,
			videoId: d.video_id || d.videoId,
			incomeType: d.income_type || d.incomeType,
			amount: Number(d.amount) || 0,
			status: d.status || "settled",
			specialTag: d.special_tag || d.specialTag,
			description: d.description || "",
			createdAt: d.created_at || d.createdAt
		}));
	} catch (_e) {}
	const all = getStoredLedger();
	if (userId) {
		const norm = userId.trim().toUpperCase();
		return all.filter((tx) => tx.userId.trim().toUpperCase() === norm);
	}
	return all;
}
/**
* Requirement 8: Finds eligible users for Global Income distribution.
* Only users who have uploaded at least one PREMIUM video are eligible.
* Users who have uploaded only Free Videos are NOT eligible.
*/
async function getEligibleGlobalIncomeUsers() {
	const videos = getStoredVideos();
	const eligibleSet = /* @__PURE__ */ new Set();
	for (const v of videos) if (v.videoType === "premium" && (v.paymentStatus === "paid" || v.paymentStatus === "not_required")) eligibleSet.add(v.userId.trim().toUpperCase());
	return Array.from(eligibleSet);
}
/**
* Checks if a premium transaction sequence number is a Special Transaction:
* 11th, 21st, 31st, 41st, 51st... and every 10th transaction after 11th.
* Formula: transactionNumber >= 11 AND (transactionNumber - 11) % 10 === 0
*/
function isSpecialGlobalTransaction(txNumber) {
	if (txNumber < 11) return false;
	return (txNumber - 11) % 10 === 0;
}
/**
* Processes premium video payment distribution (Referral + Admin + Global Pool)
* - Normal: ₹1 Direct Referral, ₹1 Admin, ₹3 Global Income Pool, ₹1 GST/PG
* - Special (11th, 21st, 31st...): ₹1 Direct Referral (if valid referrer), ₹4 Admin, ₹0 Global Pool
*/
async function distributePremiumVideoIncome(params) {
	const ledger = getStoredLedger();
	const wallets = getStoredWallets();
	if (ledger.some((t) => t.videoId === params.videoId && t.transactionId.includes(params.paymentId) || t.transactionId.endsWith(params.paymentId) || t.transactionId === `TX_SPEC_${params.paymentId}` || t.transactionId === `TX_REF_${params.paymentId}` || t.transactionId === `TX_ADM_${params.paymentId}`)) return {
		globalTransactions: [],
		isSpecial: Boolean(params.isSpecialTransaction),
		txNumber: params.txNumber
	};
	const isSpecial = typeof params.isSpecialTransaction === "boolean" ? params.isSpecialTransaction : params.txNumber ? isSpecialGlobalTransaction(params.txNumber) : false;
	const txSeqLabel = params.txNumber ? `#${params.txNumber}` : "";
	let referralTransaction;
	let specialAuditTransaction;
	const globalTransactions = [];
	const normalizedReferrerId = params.directReferrerId?.trim().toUpperCase() || null;
	if (normalizedReferrerId && normalizedReferrerId.length > 0) {
		const txId = `TX_REF_${params.paymentId}`;
		referralTransaction = {
			id: `ref-tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
			transactionId: txId,
			userId: normalizedReferrerId,
			sourceUserId: params.uploaderUserId,
			sourceUserName: params.uploaderName,
			videoId: params.videoId,
			incomeType: "referral_income",
			amount: 1,
			status: "settled",
			description: `Direct Referral Commission (₹1) for Premium Video ${txSeqLabel} upload by ${params.uploaderName} (${params.uploaderUserId})`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		ledger.unshift(referralTransaction);
		if (!wallets[normalizedReferrerId]) wallets[normalizedReferrerId] = {
			userId: normalizedReferrerId,
			balance: 1,
			totalEarned: 1,
			totalWithdrawn: 0,
			referralIncome: 1,
			globalIncome: 0,
			adsenseIncome: 0,
			affiliateIncome: 0,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		else {
			wallets[normalizedReferrerId].balance += 1;
			wallets[normalizedReferrerId].totalEarned += 1;
			wallets[normalizedReferrerId].referralIncome += 1;
			wallets[normalizedReferrerId].updatedAt = (/* @__PURE__ */ new Date()).toISOString();
		}
	}
	const adminAmount = isSpecial ? 4 : params.adminAmount ?? 1;
	const adminTransaction = {
		id: `adm-tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
		transactionId: `TX_ADM_${params.paymentId}`,
		userId: "ADMIN",
		sourceUserId: params.uploaderUserId,
		sourceUserName: params.uploaderName,
		videoId: params.videoId,
		incomeType: "admin_allocation",
		amount: adminAmount,
		status: "settled",
		specialTag: isSpecial ? "SPECIAL_GLOBAL_RULE" : void 0,
		description: isSpecial ? `Special Premium Transaction ${txSeqLabel}: Admin Allocation (₹4) under rule SPECIAL_GLOBAL_RULE` : `Admin / Platform Share (₹1) for Premium Video ${txSeqLabel}`,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	ledger.unshift(adminTransaction);
	if (isSpecial) {
		specialAuditTransaction = {
			id: `spec-tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
			transactionId: `TX_SPEC_${params.paymentId}`,
			userId: params.uploaderUserId,
			sourceUserId: params.uploaderUserId,
			sourceUserName: params.uploaderName,
			videoId: params.videoId,
			incomeType: "global_income",
			amount: 0,
			status: "settled",
			specialTag: "SPECIAL_GLOBAL_RULE",
			description: `Special Premium Transaction ${txSeqLabel}: Rule SPECIAL_GLOBAL_RULE applied (₹4 Admin, ₹0 Global Pool, standard pool distribution bypassed)`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		ledger.unshift(specialAuditTransaction);
	} else {
		const eligibleUsers = await getEligibleGlobalIncomeUsers();
		const normUploader = params.uploaderUserId.trim().toUpperCase();
		if (!eligibleUsers.includes(normUploader)) eligibleUsers.push(normUploader);
		const poolTotal = 3;
		const count = Math.max(1, eligibleUsers.length);
		const perUserShare = Number((poolTotal / count).toFixed(4));
		for (const uid of eligibleUsers) {
			const gTx = {
				id: `glb-tx-${Date.now()}-${uid}`,
				transactionId: `TX_GLB_${params.paymentId}_${uid}`,
				userId: uid,
				sourceUserId: params.uploaderUserId,
				sourceUserName: params.uploaderName,
				videoId: params.videoId,
				incomeType: "global_income",
				amount: perUserShare,
				status: "settled",
				description: `Global Income Pool distribution (₹${perUserShare} share of ₹3 pool across ${count} eligible creators for Premium Video ${txSeqLabel})`,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			ledger.unshift(gTx);
			globalTransactions.push(gTx);
			if (!wallets[uid]) wallets[uid] = {
				userId: uid,
				balance: perUserShare,
				totalEarned: perUserShare,
				totalWithdrawn: 0,
				referralIncome: 0,
				globalIncome: perUserShare,
				adsenseIncome: 0,
				affiliateIncome: 0,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			else {
				wallets[uid].balance += perUserShare;
				wallets[uid].totalEarned += perUserShare;
				wallets[uid].globalIncome += perUserShare;
				wallets[uid].updatedAt = (/* @__PURE__ */ new Date()).toISOString();
			}
		}
	}
	saveStoredLedger(ledger);
	saveStoredWallets(wallets);
	return {
		referralTransaction,
		adminTransaction,
		specialAuditTransaction,
		globalTransactions,
		isSpecial,
		txNumber: params.txNumber
	};
}
/**
* WITHDRAWAL LIMITS & RULES
* - Minimum withdrawal amount: ₹1,000
* - Maximum withdrawal amount: ₹10,000 per day
* - If daily withdrawal total reaches ₹10,000, further withdrawals are blocked until next day
*/
var WITHDRAWAL_RULES = {
	MIN_AMOUNT: 1e3,
	MAX_DAILY_LIMIT: 1e4
};
async function getDailyWithdrawnAmount(userId, dateStr) {
	const norm = userId.trim().toUpperCase();
	const targetDate = dateStr || (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	return (await getUserLedger(norm)).filter((tx) => {
		if (tx.incomeType !== "withdrawal") return false;
		return tx.createdAt.split("T")[0] === targetDate && tx.status !== "failed";
	}).reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
}
async function validateWithdrawalRequest(userId, amount) {
	const norm = userId.trim().toUpperCase();
	const wallet = await getUserWallet(norm);
	const alreadyWithdrawnToday = await getDailyWithdrawnAmount(norm);
	const remainingDailyLimit = Math.max(0, WITHDRAWAL_RULES.MAX_DAILY_LIMIT - alreadyWithdrawnToday);
	if (isNaN(amount) || amount <= 0) return {
		valid: false,
		error: "Please enter a valid withdrawal amount.",
		alreadyWithdrawnToday,
		remainingDailyLimit,
		currentBalance: wallet.balance
	};
	if (amount < WITHDRAWAL_RULES.MIN_AMOUNT) return {
		valid: false,
		error: `Minimum withdrawal amount is ₹${WITHDRAWAL_RULES.MIN_AMOUNT.toLocaleString("en-IN")}. You cannot withdraw less than ₹1,000.`,
		alreadyWithdrawnToday,
		remainingDailyLimit,
		currentBalance: wallet.balance
	};
	if (alreadyWithdrawnToday >= WITHDRAWAL_RULES.MAX_DAILY_LIMIT) return {
		valid: false,
		error: `Daily withdrawal limit of ₹${WITHDRAWAL_RULES.MAX_DAILY_LIMIT.toLocaleString("en-IN")} reached. Further withdrawals are blocked until tomorrow.`,
		alreadyWithdrawnToday,
		remainingDailyLimit: 0,
		currentBalance: wallet.balance
	};
	if (alreadyWithdrawnToday + amount > WITHDRAWAL_RULES.MAX_DAILY_LIMIT) return {
		valid: false,
		error: `Daily limit exceeded. You have already withdrawn ₹${alreadyWithdrawnToday.toLocaleString("en-IN")} today. You can withdraw at most ₹${remainingDailyLimit.toLocaleString("en-IN")} more today.`,
		alreadyWithdrawnToday,
		remainingDailyLimit,
		currentBalance: wallet.balance
	};
	if (wallet.balance < amount) return {
		valid: false,
		error: `Insufficient wallet balance. Your available balance is ₹${wallet.balance.toFixed(2)}, which is less than requested ₹${amount.toLocaleString("en-IN")}.`,
		alreadyWithdrawnToday,
		remainingDailyLimit,
		currentBalance: wallet.balance
	};
	return {
		valid: true,
		alreadyWithdrawnToday,
		remainingDailyLimit: remainingDailyLimit - amount,
		currentBalance: wallet.balance
	};
}
async function processWithdrawal(userId, amount, bankDetails) {
	const norm = userId.trim().toUpperCase();
	const validation = await validateWithdrawalRequest(norm, amount);
	if (!validation.valid) return {
		success: false,
		error: validation.error
	};
	const ledger = getStoredLedger();
	const wallets = getStoredWallets();
	let wallet = wallets[norm] || await getUserWallet(norm);
	const txId = `TX_WD_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
	const destinationDesc = bankDetails?.upiId ? `UPI: ${bankDetails.upiId}` : bankDetails?.accountNumber ? `Bank: ${bankDetails.bankName || "Account"} (****${bankDetails.accountNumber.slice(-4)})` : "Direct Bank Settlement";
	const tx = {
		id: `wd-tx-${Date.now()}`,
		transactionId: txId,
		userId: norm,
		incomeType: "withdrawal",
		amount: -amount,
		status: "settled",
		description: `Withdrawal payout to ${destinationDesc} - ₹${amount.toLocaleString("en-IN")}`,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	ledger.unshift(tx);
	wallet.balance = Math.max(0, wallet.balance - amount);
	wallet.totalWithdrawn += amount;
	wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
	wallets[norm] = wallet;
	saveStoredLedger(ledger);
	saveStoredWallets(wallets);
	try {
		const res = await api.wallet.withdraw({
			userId: norm,
			amount,
			bankDetails: bankDetails ? {
				accountHolder: bankDetails.accountHolderName,
				accountNumber: bankDetails.accountNumber,
				ifscCode: bankDetails.ifscCode,
				upiId: bankDetails.upiId,
				bankName: bankDetails.bankName
			} : void 0
		});
		if (res && res.updatedWallet) {
			wallet = {
				userId: norm,
				balance: Number(res.updatedWallet.balance) || 0,
				totalEarned: Number(res.updatedWallet.total_earned || res.updatedWallet.totalEarned) || wallet.totalEarned,
				totalWithdrawn: Number(res.updatedWallet.total_withdrawn || res.updatedWallet.totalWithdrawn) || wallet.totalWithdrawn,
				referralIncome: Number(res.updatedWallet.referral_income || res.updatedWallet.referralIncome) || wallet.referralIncome,
				globalIncome: Number(res.updatedWallet.global_income || res.updatedWallet.globalIncome) || wallet.globalIncome,
				adsenseIncome: Number(res.updatedWallet.adsense_income || res.updatedWallet.adsenseIncome) || wallet.adsenseIncome,
				affiliateIncome: Number(res.updatedWallet.affiliate_income || res.updatedWallet.affiliateIncome) || wallet.affiliateIncome,
				updatedAt: res.updatedWallet.updated_at || res.updatedWallet.updatedAt || (/* @__PURE__ */ new Date()).toISOString()
			};
			wallets[norm] = wallet;
			saveStoredWallets(wallets);
		}
	} catch (e) {
		console.warn("API withdraw note:", e);
	}
	return {
		success: true,
		transaction: tx,
		updatedWallet: wallet
	};
}
var styles_default = "/assets/styles-Bowq5jfQ.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$37 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "FaceTube — Stream. Create. Discover." },
			{
				name: "description",
				content: "FaceTube is a modern video streaming experience for creators and viewers — trending videos, popular creators, role management and fresh uploads."
			},
			{
				property: "og:title",
				content: "FaceTube — Stream. Create. Discover."
			},
			{
				property: "og:description",
				content: "A premium video streaming interface for creators and viewers."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `(function(){try{var t=localStorage.getItem('facetube-theme')||'system';var d=t==='dark'||(t==='system'&&window.matchMedia('(prefers-color-scheme: dark)').matches);if(d){document.documentElement.classList.add('dark');document.documentElement.style.colorScheme='dark';}else{document.documentElement.classList.remove('dark');document.documentElement.style.colorScheme='light';}}catch(e){}})();` } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$37.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			position: "top-center",
			richColors: true,
			closeButton: true
		})] }) })
	});
}
var $$splitComponentImporter$33 = () => import("./routes-WpDyeI1k.mjs");
var Route$36 = createFileRoute("/")({
	validateSearch: (search) => ({ q: typeof search.q === "string" ? search.q : void 0 }),
	head: () => ({ meta: [
		{ title: "FaceTube — Stream, Discover and Create Video" },
		{
			name: "description",
			content: "Browse trending videos, follow popular creators and discover fresh uploads on FaceTube, a modern video streaming experience."
		},
		{
			property: "og:title",
			content: "FaceTube — Stream, Discover and Create Video"
		},
		{
			property: "og:description",
			content: "Trending videos, popular creators and fresh uploads in one polished feed."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$33, "component")
});
var $$splitComponentImporter$32 = () => import("./admin-CYPGzprC.mjs");
var Route$35 = createFileRoute("/admin")({
	head: () => ({ meta: [
		{ title: "Admin Portal — FaceTube" },
		{
			name: "robots",
			content: "noindex, nofollow"
		},
		{
			name: "description",
			content: "FaceTube Admin Dashboard and Role-Based Access Control."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$32, "component")
});
var $$splitComponentImporter$31 = () => import("./ads-promotions-BTvyIL7Q.mjs");
var Route$34 = createFileRoute("/ads-promotions")({
	head: () => ({ meta: [{ title: "Ads Promotions — FaceTube Video Hub" }, {
		name: "description",
		content: "Launch and manage targeted advertisement video campaigns on FaceTube with instant 10% direct referrer commission."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$31, "component")
});
var $$splitComponentImporter$30 = () => import("./adsense-income-HJnJYf6s.mjs");
var Route$33 = createFileRoute("/adsense-income")({
	head: () => ({ meta: [{ title: "AdSense Income — FaceTube" }, {
		name: "description",
		content: "Track your video advertising revenue share, playback CPM, and monetized impressions on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$30, "component")
});
var $$splitComponentImporter$29 = () => import("./advertisement-videos-DdhkZZnZ.mjs");
var Route$32 = createFileRoute("/advertisement-videos")({
	head: () => ({ meta: [{ title: "Advertisement Videos — Your Videos — FaceTube" }, {
		name: "description",
		content: "Manage sponsor spots, promotional ad video campaigns, and brand deal deliverables on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./affiliate-income-E1T0ycRB.mjs");
var Route$31 = createFileRoute("/affiliate-income")({
	head: () => ({ meta: [{ title: "Affiliate Income — FaceTube" }, {
		name: "description",
		content: "Track affiliate sales commissions, sponsored product clicks, and conversion earnings on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./auth-BXPjchhj.mjs");
var Route$30 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Sign in or Create Account — FaceTube" },
		{
			name: "description",
			content: "Sign in to FaceTube with your FT User ID or Email, or create an account with instant FT ID generation."
		},
		{
			property: "og:title",
			content: "Sign in or Create Account — FaceTube"
		},
		{
			property: "og:description",
			content: "Access your FaceTube feed, subscriptions and watch history."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./dashboard-DnH_4gxt.mjs");
var Route$29 = createFileRoute("/dashboard")({
	head: () => ({ meta: [{ title: "Dashboard Summary — FaceTube" }, {
		name: "description",
		content: "Unified creator dashboard with database-driven video counts, real subscriber analytics, watch time, and revenue streams on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./direct-referral-income-OfEaxlxp.mjs");
var Route$28 = createFileRoute("/direct-referral-income")({
	head: () => ({ meta: [{ title: "Direct Referral Income — FaceTube" }, {
		name: "description",
		content: "Track your Referral Income and Direct Commission (₹1 per Premium Video upload by directly referred members) on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./explore-4MOKAyNc.mjs");
var Route$27 = createFileRoute("/explore")({
	head: () => ({ meta: [{ title: "Explore — FaceTube" }, {
		name: "description",
		content: "Discover trending videos, rising creators, music, gaming, and news on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./free-videos-ylU9mzYm.mjs");
var Route$26 = createFileRoute("/free-videos")({
	head: () => ({ meta: [{ title: "Free Videos — Your Videos — FaceTube" }, {
		name: "description",
		content: "Manage public, free-to-watch video uploads and standard channel content on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./global-income-Bqd2S-4T.mjs");
var Route$25 = createFileRoute("/global-income")({
	head: () => ({ meta: [{ title: "Global Income Pool — FaceTube" }, {
		name: "description",
		content: "Worldwide revenue share pool, database-driven ₹3 Premium Video distributions, and Special Transaction rules on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./help-BoFqJkl_.mjs");
var Route$24 = createFileRoute("/help")({
	head: () => ({ meta: [{ title: "Help & Support — FaceTube" }, {
		name: "description",
		content: "Get help with video uploads, monetization earnings, live streaming, and account settings on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
function VideoHubLayout({ children, query, onQueryChange }) {
	const [railOpen, setRailOpen] = (0, import_react.useState)(true);
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background font-sans text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {
				onToggleSidebar: () => {
					setRailOpen((v) => !v);
					setDrawerOpen((v) => !v);
				},
				query,
				onQueryChange
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
					open: railOpen,
					drawerOpen,
					onClose: () => setDrawerOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 flex-1 pb-24 lg:pb-12",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
var Route$23 = createFileRoute("/history")({
	head: () => ({ meta: [{ title: "Watch History — FaceTube" }, {
		name: "description",
		content: "Review your watched videos, resume playback, and manage FaceTube watch history."
	}] }),
	component: HistoryPage
});
function HistoryPage() {
	const [historyList, setHistoryList] = (0, import_react.useState)(allVideos.slice(0, 8));
	const [isPaused, setIsPaused] = (0, import_react.useState)(false);
	const [filterQuery, setFilterQuery] = (0, import_react.useState)("");
	const handleRemove = (id) => {
		setHistoryList((prev) => prev.filter((v) => v.id !== id));
	};
	const handleClear = () => {
		if (confirm("Clear your entire FaceTube watch history?")) setHistoryList([]);
	};
	const filtered = historyList.filter((v) => v.title.toLowerCase().includes(filterQuery.toLowerCase()) || v.channel.toLowerCase().includes(filterQuery.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_320px] gap-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-6 w-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
							children: "Watch History"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Videos you’ve recently watched on FaceTube"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-semibold text-muted-foreground",
						children: [filtered.length, " videos"]
					})]
				}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center justify-center py-16 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-16 w-16 place-items-center rounded-full bg-secondary text-muted-foreground mb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-8 w-8" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-bold text-foreground",
							children: "No watch history found"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1 max-w-sm",
							children: "Videos you watch will appear here so you can easily pick up where you left off."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "mt-4 rounded-full bg-brand px-5 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-brand-dark",
							children: "Browse Home Feed"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: filtered.map((video, idx) => {
						const progressPct = [
							85,
							45,
							100,
							20,
							60,
							90,
							30,
							75
						][idx % 8];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group flex flex-col sm:flex-row gap-4 p-3 rounded-2xl border border-border bg-card transition hover:border-brand/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/watch/$videoId",
								params: { videoId: video.id },
								className: "relative shrink-0 w-full sm:w-60 aspect-video rounded-xl overflow-hidden bg-black",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: video.thumb,
										alt: video.title,
										className: "h-full w-full object-cover transition duration-300 group-hover:scale-105"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute bottom-1.5 right-1.5 rounded bg-black/80 px-1.5 py-0.5 text-[10px] font-bold text-white",
										children: video.duration
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-0 inset-x-0 h-1 bg-black/60",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-brand",
											style: { width: `${progressPct}%` }
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/watch/$videoId",
											params: { videoId: video.id },
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-bold text-foreground line-clamp-2 group-hover:text-brand transition-colors",
												children: video.title
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleRemove(video.id),
											title: "Remove from history",
											className: "p-1 rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground transition",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-1",
										children: [
											video.channel,
											" · ",
											video.views
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground/80 line-clamp-2 mt-2",
										children: video.description
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-3 text-[11px] text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-full bg-secondary px-2 py-0.5 font-semibold text-foreground",
											children: [progressPct, "% watched"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Watched recently" })
									]
								})]
							})]
						}, `hist-${video.id}`);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-border bg-card p-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-bold uppercase tracking-wider text-muted-foreground",
							children: "History Controls"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "Search watch history…",
								value: filterQuery,
								onChange: (e) => setFilterQuery(e.target.value),
								className: "w-full rounded-xl border border-border bg-secondary/50 py-2 pl-9 pr-3 text-xs outline-none focus:border-brand"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 space-y-2 border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: handleClear,
								className: "w-full flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-semibold text-red-500 transition hover:bg-red-500/10 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 shrink-0" }), "Clear all watch history"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setIsPaused((p) => !p),
								className: "w-full flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-semibold text-foreground transition hover:bg-secondary text-left",
								children: isPaused ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 shrink-0 text-brand" }), "Resume watch history"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4 shrink-0" }), "Pause watch history"] })
							})]
						}),
						isPaused && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-amber-500/10 p-3 text-[11px] text-amber-500 font-medium border border-amber-500/20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "h-4 w-4 shrink-0" }), "Watch history is paused. New views won't be saved."]
						})
					]
				})
			})]
		})
	}) });
}
var LOCAL_STORAGE_IMAGES_KEY = "facetube_uploaded_images_v2";
var INITIAL_SEED_IMAGES = [
	{
		id: "img-seed-001",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "Mastering React 19 & Next-Gen Streaming UI",
		description: "Official cover artwork and key takeaways for our latest masterclass.",
		imageUrl: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80",
		format: "png",
		fileSize: "1.4 MB",
		category: "Coding",
		views: 14200,
		likes: 1890,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 1728e5)).toISOString()
	},
	{
		id: "img-seed-002",
		userId: "FT900431",
		creatorName: "Maya Lin",
		title: "Daily Motivation & Mindset Roadmap",
		description: "Visual roadmap for consistent creators scaling their audience in 2026.",
		imageUrl: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80",
		format: "jpg",
		fileSize: "980 KB",
		category: "Motivational",
		views: 28400,
		likes: 3410,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 3456e5)).toISOString()
	},
	{
		id: "img-seed-003",
		userId: "FT102857",
		creatorName: "FaceTube Admin",
		title: "Share Market & Crypto Macro Analysis",
		description: "Infographic breakdown of high-frequency liquidity and fintech market trends.",
		imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop&q=80",
		format: "webp",
		fileSize: "840 KB",
		category: "Share Market",
		views: 19500,
		likes: 2130,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 5184e5)).toISOString()
	},
	{
		id: "img-seed-004",
		userId: "FT483921",
		creatorName: "Alex Rivera",
		title: "Creative Studio Lighting & Setup Showcase",
		description: "Behind the scenes look at the multi-camera podcast and video rig.",
		imageUrl: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&auto=format&fit=crop&q=80",
		format: "jpeg",
		fileSize: "2.1 MB",
		category: "Entertainment",
		views: 9300,
		likes: 1240,
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 6912e5)).toISOString()
	}
];
function getStoredImages() {
	if (typeof window === "undefined") return INITIAL_SEED_IMAGES;
	try {
		const raw = localStorage.getItem(LOCAL_STORAGE_IMAGES_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed;
		}
		localStorage.setItem(LOCAL_STORAGE_IMAGES_KEY, JSON.stringify(INITIAL_SEED_IMAGES));
		return INITIAL_SEED_IMAGES;
	} catch {
		return INITIAL_SEED_IMAGES;
	}
}
function saveStoredImages(images) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(LOCAL_STORAGE_IMAGES_KEY, JSON.stringify(images));
	} catch {}
}
async function fetchUploadedImages(userId) {
	try {
		const res = await api.images.list({ userId });
		if (res && res.images && res.images.length > 0) return res.images.map((item) => ({
			id: item.id,
			userId: item.user_id || item.userId,
			creatorName: item.creator_name || item.creatorName,
			title: item.title,
			description: item.description || "",
			imageUrl: item.image_url || item.imageUrl,
			format: item.format || "jpg",
			fileSize: item.file_size || item.fileSize || "1.0 MB",
			category: item.category || "Entertainment",
			views: Number(item.views) || 0,
			likes: Number(item.likes) || 0,
			createdAt: item.created_at || item.createdAt
		}));
	} catch (_e) {}
	const all = getStoredImages();
	if (userId) {
		const norm = userId.trim().toUpperCase();
		return all.filter((img) => img.userId.trim().toUpperCase() === norm);
	}
	return all;
}
async function recordNewImageUpload(data) {
	const normUserId = data.userId.trim().toUpperCase();
	const id = `img-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const newImage = {
		id,
		userId: normUserId,
		creatorName: data.creatorName || "FaceTube Creator",
		title: data.title,
		description: data.description || "",
		imageUrl: data.imageUrl,
		format: data.format,
		fileSize: data.fileSize || "1.2 MB",
		category: data.category || "Entertainment",
		views: 0,
		likes: 0,
		createdAt: now
	};
	try {
		await api.images.create({
			id,
			user_id: normUserId,
			creator_name: newImage.creatorName,
			title: newImage.title,
			description: newImage.description,
			image_url: newImage.imageUrl,
			format: newImage.format,
			file_size: newImage.fileSize,
			category: newImage.category
		});
	} catch (e) {
		console.warn("API recordNewImageUpload fallback:", e);
	}
	const images = getStoredImages();
	images.unshift(newImage);
	saveStoredImages(images);
	return newImage;
}
/**
* Interleaves a video feed sequence with uploaded images.
* Requirement 2: After approximately 5 video items, 1 uploaded image appears as an additional item.
* - Configurable interval (default: IMAGE_FEED_INTERVAL = 5)
* - Does NOT replace or remove videos
* - If images are not available, continues displaying videos normally
*/
function interleaveFeedWithImages(videos, images, interval = 5) {
	if (!images || images.length === 0 || interval <= 0) return videos.map((v) => ({
		type: "video",
		data: v
	}));
	const combined = [];
	let imageIndex = 0;
	for (let i = 0; i < videos.length; i++) {
		combined.push({
			type: "video",
			data: videos[i]
		});
		if ((i + 1) % interval === 0) {
			const img = images[imageIndex % images.length];
			combined.push({
				type: "image",
				data: img
			});
			imageIndex++;
		}
	}
	return combined;
}
var Route$22 = createFileRoute("/images-uploaded")({
	head: () => ({ meta: [{ title: "Images Uploaded — FaceTube Media Library" }, {
		name: "description",
		content: "Manage your uploaded image assets, custom video thumbnails, channel banners, and community photo posts on FaceTube."
	}] }),
	component: ImagesUploadedPage
});
function ImagesUploadedPage() {
	const { user, profile, dbUser } = useAuth();
	profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0];
	const [images, setImages] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const loadImages = async () => {
		setLoading(true);
		try {
			const data = await fetchUploadedImages();
			setImages(data);
		} catch (e) {
			console.error("Failed to load images:", e);
		} finally {
			setLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		loadImages();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-teal-500/10 text-teal-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Images Uploaded"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Media library for custom video thumbnails, channel graphics, and photo posts. Displays every 5 videos in feed."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: loadImages,
						className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/80 px-3 py-1.5 text-xs font-bold text-foreground transition hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${loading ? "animate-spin text-brand" : ""}` }), "Refresh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/upload",
						search: { mode: "image" },
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-teal-600 px-4 py-2 text-xs font-bold text-white shadow-lift transition hover:bg-teal-500 active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Upload Image"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Total Images Uploaded"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-teal-400",
								children: images.length
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "JPG, PNG, WEBP formats"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Feed Insertion"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground",
								children: "1 per 5 Videos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-teal-400 font-semibold",
								children: "Configurable threshold active"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Supported Formats"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground",
								children: "3 Types"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "JPG / JPEG, PNG, WEBP"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Asset Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-emerald-400",
								children: "Live & Synced"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Available across stream feeds"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4",
				children: images.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group overflow-hidden rounded-2xl border border-border bg-card shadow-card transition duration-200 hover:-translate-y-1 hover:shadow-lift flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-video w-full overflow-hidden bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img.imageUrl,
								alt: img.title,
								className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105",
								referrerPolicy: "no-referrer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute bottom-1.5 right-1.5 rounded bg-black/80 px-1.5 py-0.5 text-[9px] font-mono text-white",
								children: img.fileSize
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute top-1.5 left-1.5 rounded bg-teal-600/90 px-1.5 py-0.5 text-[9px] font-bold text-white uppercase",
								children: img.format
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3.5 space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "truncate text-xs font-bold text-foreground leading-snug group-hover:text-teal-400 transition-colors",
								children: img.title
							}),
							img.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground line-clamp-1",
								children: img.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[10px] text-muted-foreground pt-1 border-t border-border/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-teal-400",
									children: img.category || "Community"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(img.createdAt).toLocaleDateString() })]
							})
						]
					})]
				}, img.id))
			})
		]
	}) });
}
var $$splitComponentImporter$20 = () => import("./income-iZMLiKz1.mjs");
var Route$21 = createFileRoute("/income")({
	head: () => ({ meta: [{ title: "Income Section — FaceTube" }, {
		name: "description",
		content: "Unified creator income hub on FaceTube: Referral Income, Global Pool, AdSense, Affiliate Sales, Wallet and Withdrawals."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./liked-videos-B_49uBR9.mjs");
var Route$20 = createFileRoute("/liked-videos")({
	head: () => ({ meta: [{ title: "Liked Videos — FaceTube" }, {
		name: "description",
		content: "All the videos you’ve liked on FaceTube in one playlist."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./live-Bi1mNrFV.mjs");
var Route$19 = createFileRoute("/live")({
	head: () => ({ meta: [{ title: "Live Streams — FaceTube" }, {
		name: "description",
		content: "Watch live streams, gaming tournaments, coding sessions, and global events on FaceTube Live."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./live-videos-B3EqlA-v.mjs");
var Route$18 = createFileRoute("/live-videos")({
	head: () => ({ meta: [{ title: "Live Videos — Your Videos — FaceTube" }, {
		name: "description",
		content: "Manage FaceTube live broadcasts, scheduled streams, RTMP stream keys, and live chat donations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./login-BH6-GzYA.mjs");
var Route$17 = createFileRoute("/login")({
	beforeLoad: () => {
		throw redirect({ to: "/auth" });
	},
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./my-certificate-Ct4Y3noq.mjs");
var Route$16 = createFileRoute("/my-certificate")({
	head: () => ({ meta: [
		{ title: "My Certificate — FaceTube Creator Network" },
		{
			name: "description",
			content: "View, download, print, and email your official FaceTube Digital Certificate of Creator Excellence across all 10 creator milestone tiers."
		},
		{
			property: "og:title",
			content: "My Certificate — FaceTube Creator Network"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./premium-videos-BAjJL_aB.mjs");
var Route$15 = createFileRoute("/premium-videos")({
	head: () => ({ meta: [{ title: "Premium Videos — Your Videos — FaceTube" }, {
		name: "description",
		content: "Manage members-only, gated, and paywalled premium videos on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./profile-neAE0xEm.mjs");
var Route$14 = createFileRoute("/profile")({
	head: () => ({ meta: [{ title: "You — FaceTube" }, {
		name: "description",
		content: "Your FaceTube channel profile, watch history, saved playlists, and account settings."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./referral-income--5LpV_Ly.mjs");
var Route$13 = createFileRoute("/referral-income")({
	head: () => ({ meta: [{ title: "Referral Income — FaceTube" }, {
		name: "description",
		content: "Track your 10% direct sponsor referral earnings and payout records on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./referral-members-Bjp2joBo.mjs");
var Route$12 = createFileRoute("/referral-members")({
	head: () => ({ meta: [{ title: "Referral & Team Members — FaceTube" }, {
		name: "description",
		content: "Track Direct Referrals, Team Members, and ₹1 Direct Commission per Premium Video uploaded on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./settings-BKw5nPQU.mjs");
var Route$11 = createFileRoute("/settings")({
	head: () => ({ meta: [{ title: "Settings — FaceTube" }, {
		name: "description",
		content: "Manage your FaceTube account, appearance theme, playback settings, and privacy preferences."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./short-videos-BsNEUy-u.mjs");
var Route$10 = createFileRoute("/short-videos")({
	head: () => ({ meta: [{ title: "Short Videos — Your Videos — FaceTube" }, {
		name: "description",
		content: "Manage vertical short videos, track viral view spikes, and monitor short-form monetization on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./shorts-CVvk6U2B.mjs");
var Route$9 = createFileRoute("/shorts")({
	validateSearch: (search) => ({ id: typeof search.id === "string" ? search.id : void 0 }),
	head: () => ({ meta: [{ title: "Shorts — FaceTube" }, {
		name: "description",
		content: "Watch trending short-form vertical videos, tutorials, and moments on FaceTube Shorts."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./subscriptions-ovj6tUwz.mjs");
var Route$8 = createFileRoute("/subscriptions")({
	head: () => ({ meta: [{ title: "Subscriptions — FaceTube" }, {
		name: "description",
		content: "Catch the latest uploads and live streams from channels you subscribe to on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./team-income-DbFPD5FA.mjs");
var Route$7 = createFileRoute("/team-income")({
	head: () => ({ meta: [{ title: "Team Income — FaceTube" }, {
		name: "description",
		content: "Track your multi-tier creator team overrides, downline volume bonuses, and team earnings on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./team-members-DvNO683D.mjs");
var Route$6 = createFileRoute("/team-members")({
	head: () => ({ meta: [{ title: "Team Members — FaceTube" }, {
		name: "description",
		content: "Manage your FaceTube creator network, team hierarchy, and multi-tier team members."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./upload-BsJYdBDx.mjs");
var Route$5 = createFileRoute("/upload")({
	validateSearch: (search) => {
		const validModes = [
			"free",
			"premium",
			"ad_promotion",
			"image"
		];
		const validFormats = ["short", "long"];
		const mode = search.mode;
		const format = search.format;
		return {
			mode: validModes.includes(mode) ? mode : null,
			format: validFormats.includes(format) ? format : void 0
		};
	},
	head: () => ({ meta: [
		{ title: "Upload Studio — FaceTube" },
		{
			name: "description",
			content: "Upload Free Videos, Premium Videos, Ad Promotion campaigns, and high-resolution Images on FaceTube."
		},
		{
			property: "og:title",
			content: "Upload Studio — FaceTube"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./wallet-balance-BYObJeH4.mjs");
var Route$4 = createFileRoute("/wallet-balance")({
	head: () => ({ meta: [
		{ title: "Wallet Balance & Ledger — FaceTube" },
		{
			name: "description",
			content: "View your available FaceTube creator wallet balance, transaction ledger, referral income, and global pool dividends."
		},
		{
			property: "og:title",
			content: "Wallet Balance & Ledger — FaceTube"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./watch-later-BbnQPfs3.mjs");
var Route$3 = createFileRoute("/watch-later")({
	head: () => ({ meta: [{ title: "Watch Later — FaceTube" }, {
		name: "description",
		content: "Your saved videos to watch later on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var Route$2 = createFileRoute("/withdrawal-balance")({
	head: () => ({ meta: [{ title: "Withdrawal Balance — FaceTube" }, {
		name: "description",
		content: "Track your FaceTube payout history, completed bank transfers, and withdrawal receipts with ₹1,000 min and ₹10,000 daily limit verification."
	}] }),
	component: WithdrawalBalancePage
});
function WithdrawalBalancePage() {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const [withdrawalTxs, setWithdrawalTxs] = (0, import_react.useState)([]);
	const [dailyWithdrawn, setDailyWithdrawn] = (0, import_react.useState)(0);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const loadData = (0, import_react.useCallback)(async () => {
		setLoading(true);
		try {
			const [w, allTxs, daily] = await Promise.all([
				getUserWallet(userId),
				getUserLedger(userId),
				getDailyWithdrawnAmount(userId)
			]);
			setWallet(w);
			setDailyWithdrawn(daily);
			const filtered = allTxs.filter((tx) => tx.incomeType === "withdrawal");
			setWithdrawalTxs(filtered);
		} catch (e) {
			console.error("Failed to load withdrawal data:", e);
		} finally {
			setLoading(false);
		}
	}, [userId]);
	(0, import_react.useEffect)(() => {
		loadData();
	}, [loadData]);
	const totalWithdrawn = wallet ? wallet.totalWithdrawn : 3150;
	const remainingDaily = Math.max(0, WITHDRAWAL_RULES.MAX_DAILY_LIMIT - dailyWithdrawn);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-orange-500/10 text-orange-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Withdrawal Balance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["History of completed payouts, settlement receipts, and daily withdrawal quota tracking for User ", userId]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: loadData,
						className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/80 px-3 py-1.5 text-xs font-bold text-foreground transition hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${loading ? "animate-spin text-brand" : ""}` }), "Refresh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/wallet-balance",
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand px-4 py-2 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3.5 w-3.5" }), "Request New Withdrawal"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-orange-500/30 bg-gradient-to-r from-orange-500/10 via-card to-card p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-0.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-foreground text-sm",
							children: "Enforced Withdrawal Limits: ₹1,000 Minimum · ₹10,000 Daily Maximum"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"Minimum per transaction: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "₹1,000" }),
								". Daily cumulative withdrawal cap:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "₹10,000 per day" }),
								". If daily limit is reached, further payouts are blocked until next day."
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right shrink-0 font-mono text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground",
						children: "Remaining Today:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-base font-black text-emerald-400",
						children: [
							"₹",
							remainingDaily.toLocaleString("en-IN"),
							" / ₹10,000"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Total Withdrawn"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xl font-black text-orange-400",
								children: ["₹", totalWithdrawn.toLocaleString("en-IN", {
									minimumFractionDigits: 2,
									maximumFractionDigits: 2
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Lifetime settled payouts"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Withdrawn Today"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xl font-black text-foreground",
								children: ["₹", dailyWithdrawn.toLocaleString("en-IN", { minimumFractionDigits: 2 })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-emerald-400 font-semibold",
								children: "Of ₹10,000 daily limit"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Minimum Allowed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground",
								children: "₹1,000.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Per request floor"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Average Processing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-emerald-400",
								children: "< 2 Hours"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Instant automated settlement"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card overflow-hidden shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 py-4 border-b border-border flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-bold text-foreground",
						children: "Withdrawal History & Receipts"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [withdrawalTxs.length, " Transfers Recorded"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-secondary/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Reference ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Description"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Settled Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Amount"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: withdrawalTxs.length > 0 ? withdrawalTxs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "transition hover:bg-secondary/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 font-mono font-bold text-foreground",
										children: item.transactionId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 font-medium text-foreground max-w-sm truncate",
										children: item.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-muted-foreground",
										children: new Date(item.createdAt).toLocaleDateString()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }), " Settled"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5 text-right font-black text-orange-400 text-sm",
										children: ["₹", Math.abs(item.amount).toLocaleString("en-IN", { minimumFractionDigits: 2 })]
									})
								]
							}, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								colSpan: 5,
								className: "px-4 py-8 text-center text-muted-foreground",
								children: [
									"No withdrawal records yet for User ",
									userId,
									". Request a withdrawal above."
								]
							}) })
						})]
					})
				})]
			})
		]
	}) });
}
var $$splitComponentImporter$1 = () => import("./your-videos-CdG4l1hj.mjs");
var Route$1 = createFileRoute("/your-videos")({
	head: () => ({ meta: [{ title: "Your Videos — Channel Studio — FaceTube" }, {
		name: "description",
		content: "Manage Free Short Videos, Free Long Videos, Premium Short Videos, and Premium Long Videos on FaceTube."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./watch._videoId-BL6pJ045.mjs");
var $$splitNotFoundComponentImporter = () => import("./watch._videoId-C5CGijin.mjs");
var Route = createFileRoute("/watch/$videoId")({
	loader: ({ params }) => {
		const video = findVideo(params.videoId);
		if (!video) throw notFound();
		return { video };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Video unavailable — FaceTube" }, {
			name: "robots",
			content: "noindex"
		}] };
		const { video } = loaderData;
		const title = `${video.title} — FaceTube`;
		return { meta: [
			{ title },
			{
				name: "description",
				content: video.description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: video.description
			},
			{
				property: "og:type",
				content: "video.other"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$36.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$37
	}),
	AdminRoute: Route$35.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$37
	}),
	AdsPromotionsRoute: Route$34.update({
		id: "/ads-promotions",
		path: "/ads-promotions",
		getParentRoute: () => Route$37
	}),
	AdsenseIncomeRoute: Route$33.update({
		id: "/adsense-income",
		path: "/adsense-income",
		getParentRoute: () => Route$37
	}),
	AdvertisementVideosRoute: Route$32.update({
		id: "/advertisement-videos",
		path: "/advertisement-videos",
		getParentRoute: () => Route$37
	}),
	AffiliateIncomeRoute: Route$31.update({
		id: "/affiliate-income",
		path: "/affiliate-income",
		getParentRoute: () => Route$37
	}),
	AuthRoute: Route$30.update({
		id: "/auth",
		path: "/auth",
		getParentRoute: () => Route$37
	}),
	DashboardRoute: Route$29.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => Route$37
	}),
	DirectReferralIncomeRoute: Route$28.update({
		id: "/direct-referral-income",
		path: "/direct-referral-income",
		getParentRoute: () => Route$37
	}),
	ExploreRoute: Route$27.update({
		id: "/explore",
		path: "/explore",
		getParentRoute: () => Route$37
	}),
	FreeVideosRoute: Route$26.update({
		id: "/free-videos",
		path: "/free-videos",
		getParentRoute: () => Route$37
	}),
	GlobalIncomeRoute: Route$25.update({
		id: "/global-income",
		path: "/global-income",
		getParentRoute: () => Route$37
	}),
	HelpRoute: Route$24.update({
		id: "/help",
		path: "/help",
		getParentRoute: () => Route$37
	}),
	HistoryRoute: Route$23.update({
		id: "/history",
		path: "/history",
		getParentRoute: () => Route$37
	}),
	ImagesUploadedRoute: Route$22.update({
		id: "/images-uploaded",
		path: "/images-uploaded",
		getParentRoute: () => Route$37
	}),
	IncomeRoute: Route$21.update({
		id: "/income",
		path: "/income",
		getParentRoute: () => Route$37
	}),
	LikedVideosRoute: Route$20.update({
		id: "/liked-videos",
		path: "/liked-videos",
		getParentRoute: () => Route$37
	}),
	LiveRoute: Route$19.update({
		id: "/live",
		path: "/live",
		getParentRoute: () => Route$37
	}),
	LiveVideosRoute: Route$18.update({
		id: "/live-videos",
		path: "/live-videos",
		getParentRoute: () => Route$37
	}),
	LoginRoute: Route$17.update({
		id: "/login",
		path: "/login",
		getParentRoute: () => Route$37
	}),
	MyCertificateRoute: Route$16.update({
		id: "/my-certificate",
		path: "/my-certificate",
		getParentRoute: () => Route$37
	}),
	PremiumVideosRoute: Route$15.update({
		id: "/premium-videos",
		path: "/premium-videos",
		getParentRoute: () => Route$37
	}),
	ProfileRoute: Route$14.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => Route$37
	}),
	ReferralIncomeRoute: Route$13.update({
		id: "/referral-income",
		path: "/referral-income",
		getParentRoute: () => Route$37
	}),
	ReferralMembersRoute: Route$12.update({
		id: "/referral-members",
		path: "/referral-members",
		getParentRoute: () => Route$37
	}),
	SettingsRoute: Route$11.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$37
	}),
	ShortVideosRoute: Route$10.update({
		id: "/short-videos",
		path: "/short-videos",
		getParentRoute: () => Route$37
	}),
	ShortsRoute: Route$9.update({
		id: "/shorts",
		path: "/shorts",
		getParentRoute: () => Route$37
	}),
	SubscriptionsRoute: Route$8.update({
		id: "/subscriptions",
		path: "/subscriptions",
		getParentRoute: () => Route$37
	}),
	TeamIncomeRoute: Route$7.update({
		id: "/team-income",
		path: "/team-income",
		getParentRoute: () => Route$37
	}),
	TeamMembersRoute: Route$6.update({
		id: "/team-members",
		path: "/team-members",
		getParentRoute: () => Route$37
	}),
	UploadRoute: Route$5.update({
		id: "/upload",
		path: "/upload",
		getParentRoute: () => Route$37
	}),
	WalletBalanceRoute: Route$4.update({
		id: "/wallet-balance",
		path: "/wallet-balance",
		getParentRoute: () => Route$37
	}),
	WatchLaterRoute: Route$3.update({
		id: "/watch-later",
		path: "/watch-later",
		getParentRoute: () => Route$37
	}),
	WithdrawalBalanceRoute: Route$2.update({
		id: "/withdrawal-balance",
		path: "/withdrawal-balance",
		getParentRoute: () => Route$37
	}),
	YourVideosRoute: Route$1.update({
		id: "/your-videos",
		path: "/your-videos",
		getParentRoute: () => Route$37
	}),
	WatchVideoIdRoute: Route.update({
		id: "/watch/$videoId",
		path: "/watch/$videoId",
		getParentRoute: () => Route$37
	})
};
var routeTree = Route$37._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { trending as A, Sidebar as C, creators as D, categories as E, thumb_4_default as M, recent as O, recordNewVideoUpload as S, allVideos as T, VIDEO_CATEGORIES as _, interleaveFeedWithImages as a, getStoredVideos as b, Route$36 as c, getDailyWithdrawnAmount as d, getEligibleGlobalIncomeUsers as f, validateWithdrawalRequest as g, processWithdrawal as h, fetchUploadedImages as i, thumb_2_default as j, recommended as k, WITHDRAWAL_RULES as l, getUserWallet as m, Route as n, recordNewImageUpload as o, getUserLedger as p, Route$9 as r, VideoHubLayout as s, router_exports as t, distributePremiumVideoIncome as u, calculateUserVideoCounts as v, Navbar as w, markVideoPromoted as x, fetchUploadedVideos as y };
