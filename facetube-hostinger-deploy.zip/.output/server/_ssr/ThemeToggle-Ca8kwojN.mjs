import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { J as Moon, Qt as Check, ut as Laptop, v as Sun } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DXiBuP5A.js
/**
* FaceTube - Centralized Production PHP REST API Client
* Replaces Supabase queries with direct PHP + MySQL backend endpoints.
* Base URL configurable via VITE_API_BASE_URL (defaults to /api)
*/
var API_BASE_URL = "/api".replace(/\/+$/, "");
var TOKEN_STORAGE_KEY = "facetube_auth_token";
function getStoredAuthToken() {
	if (typeof window === "undefined") return null;
	try {
		return localStorage.getItem("facetube_auth_token") || null;
	} catch {
		return null;
	}
}
function setStoredAuthToken(token) {
	if (typeof window === "undefined") return;
	try {
		if (token) localStorage.setItem(TOKEN_STORAGE_KEY, token);
		else localStorage.removeItem(TOKEN_STORAGE_KEY);
	} catch {}
}
/**
* Universal API Fetch Wrapper with Bearer Authentication
*/
async function apiFetch(endpoint, options = {}) {
	const token = getStoredAuthToken();
	const headers = {
		Accept: "application/json",
		...options.headers
	};
	if (!(options.body instanceof FormData) && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
	if (token && !headers["Authorization"]) headers["Authorization"] = `Bearer ${token}`;
	const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
	const url = `${API_BASE_URL}${cleanEndpoint}`;
	const res = await fetch(url, {
		...options,
		headers
	});
	const contentType = res.headers.get("content-type") || "";
	let data = null;
	if (contentType.includes("application/json")) try {
		data = await res.json();
	} catch {
		data = null;
	}
	else {
		const text = await res.text();
		try {
			data = JSON.parse(text);
		} catch {
			data = text;
		}
	}
	if (typeof data === "string" && (data.includes("<?php") || data.startsWith("<!DOCTYPE") || data.startsWith("<html"))) throw new Error(`Invalid response received from endpoint ${cleanEndpoint}`);
	if (!res.ok) {
		const errorMsg = typeof data === "object" && data?.error || typeof data === "string" && data || `HTTP error ${res.status}: ${res.statusText}`;
		throw new Error(errorMsg);
	}
	return data;
}
/**
* Modular FaceTube PHP Backend Endpoints
*/
var api = {
	auth: {
		register: async (params) => {
			const res = await apiFetch("/auth/register.php", {
				method: "POST",
				body: JSON.stringify(params)
			});
			if (res.token) setStoredAuthToken(res.token);
			return res;
		},
		login: async (params) => {
			const res = await apiFetch("/auth/login.php", {
				method: "POST",
				body: JSON.stringify(params)
			});
			if (res.token) setStoredAuthToken(res.token);
			return res;
		},
		logout: async () => {
			try {
				await apiFetch("/auth/logout.php", { method: "POST" });
			} finally {
				setStoredAuthToken(null);
			}
		},
		me: async () => {
			return apiFetch("/auth/me.php");
		}
	},
	users: {
		getProfile: async (userId) => {
			return apiFetch(`/users/profile.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		updateProfile: async (data) => {
			return apiFetch("/users/profile.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		},
		listUsers: async () => {
			return apiFetch("/users/list.php");
		}
	},
	videos: {
		list: async (params) => {
			const searchParams = new URLSearchParams();
			if (params?.userId) searchParams.set("userId", params.userId);
			if (params?.videoType) searchParams.set("videoType", params.videoType);
			if (params?.contentType) searchParams.set("contentType", params.contentType);
			if (params?.category) searchParams.set("category", params.category);
			if (params?.search) searchParams.set("search", params.search);
			if (params?.limit) searchParams.set("limit", String(params.limit));
			if (params?.offset) searchParams.set("offset", String(params.offset));
			const qs = searchParams.toString();
			return apiFetch(`/videos/list.php${qs ? `?${qs}` : ""}`);
		},
		get: async (id) => {
			return apiFetch(`/videos/get.php?id=${encodeURIComponent(id)}`);
		},
		create: async (videoData) => {
			return apiFetch("/videos/create.php", {
				method: "POST",
				body: JSON.stringify(videoData)
			});
		},
		like: async (videoId, userId) => {
			return apiFetch("/videos/like.php", {
				method: "POST",
				body: JSON.stringify({
					videoId,
					userId
				})
			});
		},
		getCounts: async (userId) => {
			return apiFetch(`/videos/counts.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		promote: async (data) => {
			return apiFetch("/videos/promote.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		}
	},
	comments: {
		list: async (videoId) => {
			return apiFetch(`/comments/list.php?videoId=${encodeURIComponent(videoId)}`);
		},
		create: async (data) => {
			return apiFetch("/comments/create.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		}
	},
	images: {
		list: async (params) => {
			const searchParams = new URLSearchParams();
			if (params?.userId) searchParams.set("userId", params.userId);
			if (params?.category) searchParams.set("category", params.category);
			if (params?.limit) searchParams.set("limit", String(params.limit));
			const qs = searchParams.toString();
			return apiFetch(`/images/list.php${qs ? `?${qs}` : ""}`);
		},
		create: async (imageData) => {
			return apiFetch("/images/create.php", {
				method: "POST",
				body: JSON.stringify(imageData)
			});
		}
	},
	wallet: {
		getBalance: async (userId) => {
			return apiFetch(`/wallet/balance.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		getTransactions: async (userId, limit) => {
			const params = new URLSearchParams();
			if (userId) params.set("userId", userId);
			if (limit) params.set("limit", String(limit));
			const qs = params.toString();
			return apiFetch(`/wallet/transactions.php${qs ? `?${qs}` : ""}`);
		},
		withdraw: async (data) => {
			return apiFetch("/wallet/withdraw.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		}
	},
	kyc: {
		getPersonal: async (userId) => {
			return apiFetch(`/kyc/personal.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		savePersonal: async (data) => {
			return apiFetch("/kyc/personal.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		},
		getBank: async (userId) => {
			return apiFetch(`/kyc/bank.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		saveBank: async (data) => {
			return apiFetch("/kyc/bank.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		}
	},
	referrals: { getDashboard: async (userId) => {
		return apiFetch(`/referrals/dashboard.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
	} },
	certificates: {
		get: async (userId) => {
			return apiFetch(`/certificates/get.php${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`);
		},
		save: async (certData) => {
			return apiFetch("/certificates/save.php", {
				method: "POST",
				body: JSON.stringify(certData)
			});
		}
	},
	payments: {
		createOrder: async (data) => {
			return apiFetch("/payments/create-order.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		},
		verify: async (data) => {
			return apiFetch("/payments/verify.php", {
				method: "POST",
				body: JSON.stringify(data)
			});
		},
		getTransactions: async () => {
			return apiFetch("/payments/transactions.php");
		}
	},
	uploads: {
		uploadImage: async (file) => {
			const formData = new FormData();
			formData.append("image", file);
			return apiFetch("/uploads/image.php", {
				method: "POST",
				body: formData
			});
		},
		uploadVideo: async (file) => {
			const formData = new FormData();
			formData.append("video", file);
			return apiFetch("/uploads/video.php", {
				method: "POST",
				body: formData
			});
		},
		uploadKyc: async (file) => {
			const formData = new FormData();
			formData.append("document", file);
			return apiFetch("/uploads/kyc.php", {
				method: "POST",
				body: formData
			});
		}
	},
	admin: {
		getStats: async () => {
			return apiFetch("/admin/stats.php");
		},
		updateRole: async (targetUserId, role) => {
			return apiFetch("/admin/role.php", {
				method: "POST",
				body: JSON.stringify({
					targetUserId,
					role
				})
			});
		}
	}
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/ThemeToggle-Ca8kwojN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY_SENT_EMAILS = "facetube_sent_welcome_emails_v2";
var OFFICIAL_LOGIN_LINK = "https://youtube-clone-ui-8qmb.vercel.app/login";
function generateWelcomeEmailContent(name, email, userId, password = "••••••••", loginLink = OFFICIAL_LOGIN_LINK) {
	return {
		subject: "Welcome to Facetube",
		body: `Hello ${name}

Your Facetube account has been created successfully.

Account Details:
------------------------------------------
• User Name: ${name}
• User ID: ${userId}
• Registered Email: ${email}
• Password: ${password}
------------------------------------------

Login Link:
${loginLink}

You can log in using either your User ID or Email.`
	};
}
/**
* Dispatches real welcome email through the server endpoint.
* Falls back to recording the failure gracefully if the server returns an error.
*/
async function sendWelcomeEmail({ name, email, userId, password, loginLink = OFFICIAL_LOGIN_LINK }) {
	const { subject, body } = generateWelcomeEmailContent(name, email, userId, password, loginLink);
	let dispatchResult = {
		success: false,
		error: "Email delivery failed"
	};
	try {
		const response = await fetch("/api/send-welcome-email", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				userName: name,
				userId,
				email,
				password: password || "",
				loginLink
			})
		});
		const data = await response.json();
		if (response.ok && data.success) dispatchResult = {
			success: true,
			provider: data.provider,
			messageId: data.messageId
		};
		else dispatchResult = {
			success: false,
			provider: data.provider || "none",
			error: data.error || "Email delivery failed"
		};
	} catch (netErr) {
		const msg = netErr instanceof Error ? netErr.message : String(netErr);
		console.error("[Email Client] Network error reaching email endpoint:", msg);
		dispatchResult = {
			success: false,
			error: "Email delivery failed"
		};
	}
	const emailRecord = {
		id: "email_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 6),
		recipientEmail: email,
		recipientName: name,
		userId,
		subject,
		body,
		sentAt: (/* @__PURE__ */ new Date()).toISOString(),
		status: dispatchResult.success ? "delivered" : "failed",
		provider: dispatchResult.provider,
		error: dispatchResult.error
	};
	try {
		const updated = [emailRecord, ...getSentWelcomeEmails().slice(0, 49)];
		localStorage.setItem(STORAGE_KEY_SENT_EMAILS, JSON.stringify(updated));
	} catch (_e) {}
	if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("facetube:welcome_email_sent", { detail: emailRecord }));
	return dispatchResult;
}
function getSentWelcomeEmails() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY_SENT_EMAILS);
		if (!raw) return [];
		return JSON.parse(raw);
	} catch {
		return [];
	}
}
var LOCAL_STORAGE_DB_USERS_KEY = "facetube_db_users_v2";
var INITIAL_SEED_USERS = [
	{
		id: "a0000000-0000-0000-0000-000000000001",
		user_id: "FT102857",
		name: "FaceTube Administrator",
		mobile: "+1 555-019-2834",
		email: "admin@facetube.com",
		password_hash: "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f",
		referral_code: "FTVIP",
		created_at: (/* @__PURE__ */ new Date(Date.now() - 2592e6)).toISOString(),
		role: "admin"
	},
	{
		id: "a0000000-0000-0000-0000-000000000002",
		user_id: "FT483921",
		name: "Alex Rivera",
		mobile: "+1 555-014-8392",
		email: "alex@facetube.com",
		password_hash: "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f",
		referral_code: "CREATOR50",
		created_at: (/* @__PURE__ */ new Date(Date.now() - 1296e6)).toISOString(),
		role: "user"
	},
	{
		id: "a0000000-0000-0000-0000-000000000003",
		user_id: "FT900431",
		name: "Maya Lin",
		mobile: "+1 555-019-0043",
		email: "maya@facetube.com",
		password_hash: "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f",
		referral_code: null,
		created_at: (/* @__PURE__ */ new Date(Date.now() - 6048e5)).toISOString(),
		role: "user"
	}
];
/**
* Reads local cached database users from localStorage
*/
function getLocalDbUsers() {
	try {
		const raw = localStorage.getItem(LOCAL_STORAGE_DB_USERS_KEY);
		if (raw) return JSON.parse(raw);
		localStorage.setItem(LOCAL_STORAGE_DB_USERS_KEY, JSON.stringify(INITIAL_SEED_USERS));
		return INITIAL_SEED_USERS;
	} catch (_e) {
		return INITIAL_SEED_USERS;
	}
}
/**
* Creates a new user record in the MySQL 'users' database table via PHP API
*/
async function registerUserInDatabase({ name, mobile, email, password, referralCode }) {
	const trimmedName = name.trim();
	const trimmedMobile = mobile.trim();
	const normalizedEmail = email.trim().toLowerCase();
	let generatedUserId = "";
	let newUser = null;
	let apiRes;
	try {
		apiRes = await api.auth.register({
			name: trimmedName,
			mobile: trimmedMobile,
			email: normalizedEmail,
			password,
			referralCode: referralCode?.trim() || void 0
		});
	} catch (apiErr) {
		const errorMsg = apiErr instanceof Error ? apiErr.message : "Failed to connect to the database. Registration could not be completed.";
		throw new Error(errorMsg);
	}
	if (!apiRes || !apiRes.user) {
		const errorMsg = apiRes?.message || apiRes?.error || "Database registration failed: User record could not be created in MySQL.";
		throw new Error(errorMsg);
	}
	newUser = {
		id: apiRes.user.id,
		user_id: apiRes.user.user_id,
		name: apiRes.user.name,
		mobile: apiRes.user.mobile,
		email: apiRes.user.email,
		password_hash: "SECURED_BY_PHP_BCRYPT",
		referral_code: apiRes.user.referral_code || null,
		created_at: apiRes.user.created_at || (/* @__PURE__ */ new Date()).toISOString(),
		role: apiRes.user.role || "user"
	};
	generatedUserId = apiRes.user.user_id;
	let emailDelivery = {
		success: false,
		provider: "none",
		error: "Email delivery failed",
		messageId: void 0
	};
	if (apiRes.emailDelivery) emailDelivery = {
		success: apiRes.emailDelivery.success,
		provider: apiRes.emailDelivery.provider || "none",
		error: apiRes.emailDelivery.error,
		messageId: apiRes.emailDelivery.messageId
	};
	else try {
		const loginLink = (typeof window !== "undefined" && window.location.origin ? window.location.origin : "https://facetube.online") + "/login";
		const res = await sendWelcomeEmail({
			name: trimmedName,
			email: normalizedEmail,
			userId: generatedUserId,
			password,
			loginLink
		});
		emailDelivery = {
			success: res.success,
			provider: res.provider || "none",
			error: res.error,
			messageId: res.messageId
		};
	} catch (emailErr) {
		emailDelivery = {
			success: false,
			provider: "none",
			error: `Email delivery failed: ${emailErr instanceof Error ? emailErr.message : String(emailErr)}`,
			messageId: void 0
		};
	}
	return {
		user: newUser,
		userId: generatedUserId,
		emailDelivery
	};
}
var AuthContext = (0, import_react.createContext)(void 0);
var LOCAL_STORAGE_SESSION_KEY = "facetube_session_v2";
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [dbUser, setDbUser] = (0, import_react.useState)(null);
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [role, setRole] = (0, import_react.useState)("user");
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const [usersList, setUsersList] = (0, import_react.useState)([]);
	const syncUsersList = (0, import_react.useCallback)(() => {
		const formatted = getLocalDbUsers().map((u) => ({
			id: u.id,
			user_id: u.user_id,
			username: u.user_id.toLowerCase(),
			name: u.name,
			full_name: u.name,
			mobile: u.mobile,
			email: u.email,
			role: u.role || (u.email === "admin@facetube.com" ? "admin" : "user"),
			referral_code: u.referral_code,
			created_at: u.created_at
		}));
		setUsersList(formatted);
	}, []);
	const refreshUsers = (0, import_react.useCallback)(async () => {
		try {
			const res = await api.users.listUsers();
			if (res && res.users && res.users.length > 0) {
				const combined = res.users.map((u) => ({
					id: u.id,
					user_id: u.user_id,
					username: (u.user_id || "").toLowerCase(),
					name: u.name,
					full_name: u.name,
					mobile: u.mobile,
					email: u.email,
					role: u.role === "admin" || u.email === "admin@facetube.com" ? "admin" : "user",
					referral_code: u.referral_code,
					created_at: u.created_at
				}));
				setUsersList(combined);
				return;
			}
		} catch {}
		syncUsersList();
	}, [syncUsersList]);
	(0, import_react.useEffect)(() => {
		syncUsersList();
		api.auth.me().then((res) => {
			if (res && res.authenticated && res.user) {
				const u = res.user;
				const resolvedRole = u.role === "admin" || u.email === "admin@facetube.com" ? "admin" : "user";
				const newProfile = {
					id: u.id,
					user_id: u.user_id,
					username: u.user_id,
					name: u.name,
					full_name: u.name,
					mobile: u.mobile,
					email: u.email,
					avatar_url: u.avatar_url,
					referral_code: u.referral_code,
					created_at: u.created_at
				};
				const authUser = {
					id: u.id,
					email: u.email,
					user_metadata: {
						name: u.name,
						full_name: u.name,
						mobile: u.mobile,
						user_id: u.user_id,
						avatar_url: u.avatar_url
					}
				};
				const newDbUser = {
					id: u.id,
					user_id: u.user_id,
					name: u.name,
					mobile: u.mobile,
					email: u.email,
					password_hash: "SECURED_BY_PHP_BCRYPT",
					referral_code: u.referral_code,
					created_at: u.created_at,
					role: resolvedRole
				};
				setUser(authUser);
				setProfile(newProfile);
				setDbUser(newDbUser);
				setRole(resolvedRole);
			} else {
				setUser(null);
				setProfile(null);
				setDbUser(null);
				setRole(null);
				try {
					localStorage.removeItem(LOCAL_STORAGE_SESSION_KEY);
				} catch (_e) {}
			}
		}).catch(() => {
			setUser(null);
			setProfile(null);
			setDbUser(null);
			setRole(null);
			try {
				localStorage.removeItem(LOCAL_STORAGE_SESSION_KEY);
			} catch (_e) {}
		}).finally(() => {
			setIsLoading(false);
		});
	}, [syncUsersList]);
	/**
	* Database-backed User Registration via PHP MySQL Backend
	*/
	const signUp = async (params) => {
		try {
			const { user: newDbUser, userId, emailDelivery } = await registerUserInDatabase({
				name: params.name || params.fullName || "FaceTube User",
				mobile: params.mobile,
				email: params.email,
				password: params.password,
				referralCode: params.referralCode
			});
			const newProfile = {
				id: newDbUser.id,
				user_id: userId,
				username: userId,
				name: newDbUser.name,
				full_name: newDbUser.name,
				mobile: newDbUser.mobile,
				email: newDbUser.email,
				referral_code: newDbUser.referral_code,
				created_at: newDbUser.created_at
			};
			const authUser = {
				id: newDbUser.id,
				email: newDbUser.email,
				user_metadata: {
					name: newDbUser.name,
					full_name: newDbUser.name,
					mobile: newDbUser.mobile,
					user_id: userId
				}
			};
			setDbUser(newDbUser);
			setProfile(newProfile);
			setUser(authUser);
			setRole(newDbUser.role || "user");
			try {
				localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify({
					user: authUser,
					profile: newProfile,
					dbUser: newDbUser,
					role: newDbUser.role || "user"
				}));
			} catch (_e) {}
			syncUsersList();
			return {
				success: true,
				user: newDbUser,
				userId,
				emailDelivery,
				error: null
			};
		} catch (err) {
			return {
				success: false,
				error: err instanceof Error ? err : new Error(String(err))
			};
		}
	};
	/**
	* Database-backed Login: Supports login using User ID (FT123456) OR Email via PHP API
	*/
	const signIn = async (params) => {
		const rawIdentifier = (params.identifier || params.email || "").trim();
		const password = params.password;
		if (!rawIdentifier) return {
			success: false,
			error: /* @__PURE__ */ new Error("Please enter your User ID or Email.")
		};
		if (!password) return {
			success: false,
			error: /* @__PURE__ */ new Error("Please enter your password.")
		};
		try {
			let loginRes;
			try {
				loginRes = await api.auth.login({
					identifier: rawIdentifier,
					password
				});
			} catch (apiErr) {
				const msg = apiErr instanceof Error ? apiErr.message : "Database authentication error. Please verify your connection.";
				return {
					success: false,
					error: new Error(msg)
				};
			}
			if (!loginRes || !loginRes.success || !loginRes.user) return {
				success: false,
				error: new Error(loginRes?.message || "Authentication failed. Please verify your User ID or Email and password.")
			};
			const authenticatedUser = loginRes.user;
			const resolvedRole = authenticatedUser.role || (authenticatedUser.email === "admin@facetube.com" ? "admin" : "user");
			const authProfile = {
				id: authenticatedUser.id,
				user_id: authenticatedUser.user_id,
				username: authenticatedUser.user_id,
				name: authenticatedUser.name,
				full_name: authenticatedUser.name,
				mobile: authenticatedUser.mobile,
				email: authenticatedUser.email,
				referral_code: authenticatedUser.referral_code,
				created_at: authenticatedUser.created_at
			};
			const authUser = {
				id: authenticatedUser.id,
				email: authenticatedUser.email,
				user_metadata: {
					user_id: authenticatedUser.user_id,
					name: authenticatedUser.name,
					full_name: authenticatedUser.name,
					mobile: authenticatedUser.mobile
				}
			};
			const dbUserRecord = {
				id: authenticatedUser.id,
				user_id: authenticatedUser.user_id,
				name: authenticatedUser.name,
				mobile: authenticatedUser.mobile,
				email: authenticatedUser.email,
				password_hash: "SECURED_BY_PHP_BCRYPT",
				referral_code: authenticatedUser.referral_code,
				created_at: authenticatedUser.created_at,
				role: resolvedRole
			};
			setDbUser(dbUserRecord);
			setProfile(authProfile);
			setUser(authUser);
			setRole(resolvedRole);
			try {
				localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify({
					user: authUser,
					profile: authProfile,
					dbUser: dbUserRecord,
					role: resolvedRole
				}));
			} catch (_e) {}
			return {
				success: true,
				error: null
			};
		} catch (err) {
			return {
				success: false,
				error: err instanceof Error ? err : new Error(String(err))
			};
		}
	};
	/**
	* Sign Out method
	*/
	const signOut = async () => {
		try {
			await api.auth.logout();
		} catch {}
		setStoredAuthToken(null);
		setUser(null);
		setProfile(null);
		setDbUser(null);
		setRole("user");
		try {
			localStorage.removeItem(LOCAL_STORAGE_SESSION_KEY);
		} catch (_e) {}
	};
	/**
	* Update User Role (Admin action)
	*/
	const updateUserRole = async (targetUserId, newRole) => {
		if (role !== "admin") {
			console.error("Only admins can update roles.");
			return false;
		}
		try {
			await api.admin.updateRole(targetUserId, newRole);
		} catch (e) {
			console.warn("API role update error:", e);
		}
		setUsersList((prev) => prev.map((u) => {
			if (u.id === targetUserId || u.user_id?.toUpperCase() === targetUserId.toUpperCase() || u.username.toUpperCase() === targetUserId.toUpperCase()) return {
				...u,
				role: newRole
			};
			return u;
		}));
		return true;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user,
			profile,
			dbUser,
			role,
			isAdmin: role === "admin",
			isLoading,
			isConfigured: true,
			signUp,
			signIn,
			signOut,
			updateUserRole,
			allUsers: usersList,
			refreshUsers
		},
		children
	});
}
function useAuth() {
	const context = (0, import_react.useContext)(AuthContext);
	if (!context) throw new Error("useAuth must be used within an AuthProvider");
	return context;
}
var THEME_STORAGE_KEY = "facetube-theme";
var ThemeContext = (0, import_react.createContext)(void 0);
function getSystemTheme() {
	if (typeof window === "undefined") return "dark";
	return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function getStoredTheme() {
	if (typeof window === "undefined") return "system";
	try {
		const stored = localStorage.getItem(THEME_STORAGE_KEY);
		if (stored === "light" || stored === "dark" || stored === "system") return stored;
	} catch {}
	return "system";
}
function ThemeProvider({ children }) {
	const [theme, setThemeState] = (0, import_react.useState)("system");
	const [systemTheme, setSystemTheme] = (0, import_react.useState)("dark");
	(0, import_react.useEffect)(() => {
		const stored = getStoredTheme();
		if (stored) setThemeState(stored);
		setSystemTheme(getSystemTheme());
	}, []);
	const resolvedTheme = (0, import_react.useMemo)(() => {
		if (theme === "system") return systemTheme;
		return theme;
	}, [theme, systemTheme]);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
		const handleChange = (e) => {
			const isDark = e.matches;
			setSystemTheme(isDark ? "dark" : "light");
		};
		setSystemTheme(mediaQuery.matches ? "dark" : "light");
		if (mediaQuery.addEventListener) {
			mediaQuery.addEventListener("change", handleChange);
			return () => mediaQuery.removeEventListener("change", handleChange);
		} else {
			mediaQuery.addListener(handleChange);
			return () => mediaQuery.removeListener(handleChange);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof document === "undefined") return;
		const root = document.documentElement;
		if (resolvedTheme === "dark") {
			root.classList.add("dark");
			root.style.colorScheme = "dark";
		} else {
			root.classList.remove("dark");
			root.style.colorScheme = "light";
		}
	}, [resolvedTheme]);
	const setTheme = (0, import_react.useCallback)((newTheme) => {
		setThemeState(newTheme);
		try {
			localStorage.setItem(THEME_STORAGE_KEY, newTheme);
		} catch {}
	}, []);
	const toggleTheme = (0, import_react.useCallback)(() => {
		setThemeState((prev) => {
			let next;
			if (prev === "system") next = "light";
			else if (prev === "light") next = "dark";
			else next = "system";
			try {
				localStorage.setItem(THEME_STORAGE_KEY, next);
			} catch {}
			return next;
		});
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		theme,
		resolvedTheme,
		systemTheme,
		setTheme,
		toggleTheme
	}), [
		theme,
		resolvedTheme,
		systemTheme,
		setTheme,
		toggleTheme
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, {
		value,
		children
	});
}
function useTheme() {
	const context = (0, import_react.useContext)(ThemeContext);
	if (!context) throw new Error("useTheme must be used within a ThemeProvider");
	return context;
}
function FacetubeLogoIcon({ size = 36, className = "" }) {
	const uid = (0, import_react.useId)().replace(/[^a-zA-Z0-9]/g, "");
	const sphereId = `ft_sphere_${uid}`;
	const specularId = `ft_specular_${uid}`;
	const rimId = `ft_rim_${uid}`;
	const dropId = `ft_drop_${uid}`;
	const innerRedId = `ft_innerRed_${uid}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		viewBox: "0 0 512 512",
		width: size,
		height: size,
		className: `shrink-0 select-none ${className}`,
		style: {
			width: size,
			height: size
		},
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: sphereId,
					cx: "35%",
					cy: "30%",
					r: "68%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#ff3b2e"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "35%",
							stopColor: "#f40600"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "70%",
							stopColor: "#db0000"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "90%",
							stopColor: "#b00000"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#800000"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: specularId,
					cx: "40%",
					cy: "20%",
					r: "50%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#ffffff",
							stopOpacity: "0.48"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "40%",
							stopColor: "#ffffff",
							stopOpacity: "0.18"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "80%",
							stopColor: "#ffffff",
							stopOpacity: "0"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: rimId,
					x1: "20%",
					y1: "0%",
					x2: "80%",
					y2: "100%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#ff7b70",
							stopOpacity: "0.7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "50%",
							stopColor: "#ff2617",
							stopOpacity: "0.2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#4a0000",
							stopOpacity: "0.8"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
					id: dropId,
					x: "-15%",
					y: "-15%",
					width: "130%",
					height: "135%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
						dx: "0",
						dy: "6",
						stdDeviation: "8",
						floodColor: "#4a0000",
						floodOpacity: "0.4"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: innerRedId,
					x1: "0%",
					y1: "0%",
					x2: "0%",
					y2: "100%",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: "#eb0900"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: "#cf0000"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "256",
				cy: "256",
				r: "246",
				fill: `url(#${sphereId})`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "256",
				cy: "256",
				r: "245",
				fill: "none",
				stroke: `url(#${rimId})`,
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "256",
				cy: "150",
				rx: "200",
				ry: "110",
				fill: `url(#${specularId})`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				filter: `url(#${dropId})`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "116",
						y: "154",
						width: "280",
						height: "196",
						rx: "38",
						ry: "38",
						fill: "#FFFFFF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "143",
						y: "166",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "205",
						y: "166",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "267",
						y: "166",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "329",
						y: "166",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "143",
						y: "315",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "205",
						y: "315",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "267",
						y: "315",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "329",
						y: "315",
						width: "35",
						height: "23",
						rx: "4",
						fill: `url(#${innerRedId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M 223 207 C 223 201 229.5 197.2 234.8 200.4 L 295.6 245.4 C 300.6 248.4 300.6 255.6 295.6 258.6 L 234.8 303.6 C 229.5 306.8 223 303 223 297 Z",
						fill: `url(#${innerRedId})`
					})
				]
			})
		]
	});
}
function Logo({ size = 34, showName = true, className = "", asLink = true }) {
	const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacetubeLogoIcon, { size }), showName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "text-[1.18rem] font-extrabold tracking-tight text-foreground",
		children: ["Face", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-brand",
			children: "Tube"
		})]
	})] });
	if (!asLink) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `flex shrink-0 items-center gap-2.5 ${className}`,
		children: content
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: `flex shrink-0 items-center gap-2.5 ${className}`,
		children: content
	});
}
var themeOptions = [
	{
		value: "light",
		label: "Forced Light",
		shortLabel: "Light",
		description: "Force light appearance regardless of device",
		icon: Sun
	},
	{
		value: "dark",
		label: "Forced Dark",
		shortLabel: "Dark",
		description: "Force dark appearance regardless of device",
		icon: Moon
	},
	{
		value: "system",
		label: "System Theme",
		shortLabel: "System",
		description: "Match device operating system appearance",
		icon: Laptop
	}
];
function ThemeToggle({ className = "", showLabelsOnWide = true }) {
	const { theme, resolvedTheme, systemTheme, setTheme } = useTheme();
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const menuRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		function handleClickOutside(event) {
			if (menuRef.current && !menuRef.current.contains(event.target)) setMobileMenuOpen(false);
		}
		if (mobileMenuOpen) {
			document.addEventListener("mousedown", handleClickOutside);
			return () => document.removeEventListener("mousedown", handleClickOutside);
		}
	}, [mobileMenuOpen]);
	const ActiveIcon = theme === "light" ? Sun : theme === "dark" ? Moon : Laptop;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative inline-flex items-center ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "radiogroup",
			"aria-label": "Theme selection",
			className: "hidden items-center rounded-full border border-border bg-secondary/70 p-0.5 shadow-inner sm:inline-flex",
			children: themeOptions.map((opt) => {
				const Icon = opt.icon;
				const isSelected = theme === opt.value;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "radio",
					"aria-checked": isSelected,
					title: `${opt.label}: ${opt.description}${opt.value === "system" ? ` (Currently: ${systemTheme})` : ""}`,
					onClick: () => setTheme(opt.value),
					className: `relative flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand ${isSelected ? "bg-background text-foreground shadow-sm font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-background/40"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
						showLabelsOnWide && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden xl:inline text-[11px] tracking-tight",
							children: opt.shortLabel
						}),
						opt.value === "system" && isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-1.5 w-1.5 rounded-full bg-brand",
							title: `System is active (${systemTheme} mode)`
						})
					]
				}, opt.value);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative sm:hidden",
			ref: menuRef,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-label": `Current theme: ${theme}. Click to switch theme.`,
				"aria-expanded": mobileMenuOpen,
				onClick: () => setMobileMenuOpen((v) => !v),
				className: "relative grid h-10 w-10 place-items-center rounded-full text-foreground/80 transition hover:bg-secondary active:scale-95",
				title: `Theme: ${theme === "system" ? `System (${resolvedTheme})` : theme}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveIcon, { className: "h-5 w-5 text-foreground" }), theme === "system" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute right-2 top-2 h-2 w-2 rounded-full bg-brand ring-2 ring-background",
					title: "Following system theme"
				})]
			}), mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-0 top-12 z-50 w-52 rounded-2xl border border-border bg-card p-1.5 shadow-2xl animate-in fade-in-0 zoom-in-95",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-border/70 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold text-foreground",
						children: "Theme appearance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted-foreground",
						children: [
							"Current:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold capitalize text-foreground",
								children: theme === "system" ? `System (${resolvedTheme})` : theme
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-1",
					children: themeOptions.map((opt) => {
						const Icon = opt.icon;
						const isSelected = theme === opt.value;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setTheme(opt.value);
								setMobileMenuOpen(false);
							},
							className: `flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-medium transition ${isSelected ? "bg-brand/10 font-semibold text-brand" : "text-foreground hover:bg-secondary"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: opt.label }), opt.value === "system" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-muted-foreground",
										children: [
											"Matches device (",
											systemTheme,
											")"
										]
									})]
								})]
							}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 shrink-0 text-brand" })]
						}, opt.value);
					})
				})]
			})]
		})]
	});
}
//#endregion
export { ThemeToggle as a, sendWelcomeEmail as c, ThemeProvider as i, useAuth as l, FacetubeLogoIcon as n, generateWelcomeEmailContent as o, Logo as r, getLocalDbUsers as s, AuthProvider as t, api as u };
