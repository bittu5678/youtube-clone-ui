import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Kt as CircleCheck, Lt as CreditCard, M as RefreshCw, Nt as Earth, dn as ArrowDownToLine, m as TrendingUp, qt as CircleAlert, r as Wallet, s as Users } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { d as getDailyWithdrawnAmount, g as validateWithdrawalRequest, h as processWithdrawal, l as WITHDRAWAL_RULES, m as getUserWallet, p as getUserLedger, s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
import { n as getPersonalKyc, t as getBankKyc } from "./kyc-service-oYEql6hM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet-balance-BYObJeH4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WalletBalancePage() {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const [ledger, setLedger] = (0, import_react.useState)([]);
	const [alreadyWithdrawnToday, setAlreadyWithdrawnToday] = (0, import_react.useState)(0);
	const [isRefreshing, setIsRefreshing] = (0, import_react.useState)(false);
	const [withdrawAmount, setWithdrawAmount] = (0, import_react.useState)("1000");
	const [withdrawing, setWithdrawing] = (0, import_react.useState)(false);
	const [validationError, setValidationError] = (0, import_react.useState)("");
	const [successMsg, setSuccessMsg] = (0, import_react.useState)("");
	const [isKycVerified, setIsKycVerified] = (0, import_react.useState)(true);
	const loadWalletData = (0, import_react.useCallback)(async () => {
		setIsRefreshing(true);
		try {
			const [w, txs, dailyWithdrawn, personalKyc, bankKyc] = await Promise.all([
				getUserWallet(userId),
				getUserLedger(userId),
				getDailyWithdrawnAmount(userId),
				getPersonalKyc(userId),
				getBankKyc(userId)
			]);
			setWallet(w);
			setLedger(txs);
			setAlreadyWithdrawnToday(dailyWithdrawn);
			const kycOk = personalKyc?.status === "Verified" && bankKyc?.status === "Verified";
			setIsKycVerified(kycOk);
		} catch (err) {
			console.error("Failed to load wallet data:", err);
		} finally {
			setIsRefreshing(false);
		}
	}, [userId]);
	(0, import_react.useEffect)(() => {
		loadWalletData();
	}, [loadWalletData]);
	const balance = wallet ? wallet.balance : 4280.5;
	const remainingDailyLimit = Math.max(0, WITHDRAWAL_RULES.MAX_DAILY_LIMIT - alreadyWithdrawnToday);
	const handleAmountChange = (val) => {
		setWithdrawAmount(val);
		setValidationError("");
		const num = Number(val);
		if (!isNaN(num) && num > 0) {
			if (num < WITHDRAWAL_RULES.MIN_AMOUNT) setValidationError(`Minimum withdrawal amount is ₹${WITHDRAWAL_RULES.MIN_AMOUNT.toLocaleString("en-IN")}. You cannot withdraw less than ₹1,000.`);
			else if (alreadyWithdrawnToday >= WITHDRAWAL_RULES.MAX_DAILY_LIMIT) setValidationError(`Daily withdrawal limit of ₹${WITHDRAWAL_RULES.MAX_DAILY_LIMIT.toLocaleString("en-IN")} reached. Further withdrawals are blocked until tomorrow.`);
			else if (alreadyWithdrawnToday + num > WITHDRAWAL_RULES.MAX_DAILY_LIMIT) setValidationError(`Daily limit exceeded. You have already withdrawn ₹${alreadyWithdrawnToday.toLocaleString("en-IN")} today. Maximum additional withdrawal allowed today is ₹${remainingDailyLimit.toLocaleString("en-IN")}.`);
			else if (num > balance) setValidationError(`Insufficient wallet balance. Your available balance is ₹${balance.toFixed(2)}, which is less than requested ₹${num.toLocaleString("en-IN")}.`);
		}
	};
	const handleWithdraw = async (e) => {
		e.preventDefault();
		setValidationError("");
		setSuccessMsg("");
		const amount = Number(withdrawAmount);
		const validation = await validateWithdrawalRequest(userId, amount);
		if (!validation.valid) {
			setValidationError(validation.error || "Invalid withdrawal request.");
			toast.error(validation.error);
			return;
		}
		if (!isKycVerified) {
			setValidationError("KYC verification required. Complete your Personal & Bank KYC before requesting a withdrawal.");
			toast.error("KYC verification required for withdrawals.");
			return;
		}
		setWithdrawing(true);
		try {
			const serverRes = await fetch("/api/wallet/withdraw", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					userId,
					amount
				})
			});
			const serverData = await serverRes.json();
			if (!serverRes.ok || !serverData.success) {
				setValidationError(serverData.error || "Server validation rejected withdrawal request.");
				toast.error(serverData.error || "Withdrawal failed server verification.");
				setWithdrawing(false);
				return;
			}
			const bankKyc = await getBankKyc(userId);
			const res = await processWithdrawal(userId, amount, {
				accountHolder: bankKyc?.accountHolderName,
				accountNumber: bankKyc?.accountNumber,
				bankName: bankKyc?.bankName,
				upiId: bankKyc?.upiId
			});
			if (res.success && res.updatedWallet) {
				setWallet(res.updatedWallet);
				setSuccessMsg(`🎉 Withdrawal request for ₹${amount.toLocaleString("en-IN")} submitted successfully! Reference: ${res.transaction?.transactionId}`);
				toast.success(`Withdrawal of ₹${amount.toLocaleString("en-IN")} processed!`);
				await loadWalletData();
				setWithdrawAmount("1000");
			} else {
				setValidationError(res.error || "Could not process withdrawal.");
				toast.error(res.error || "Withdrawal failed.");
			}
		} catch (err) {
			setValidationError(err.message || "Network error processing withdrawal.");
			toast.error("Network error processing withdrawal.");
		} finally {
			setWithdrawing(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
							children: "Wallet Balance & Ledger"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadWalletData,
							disabled: isRefreshing,
							className: "rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground transition",
							title: "Refresh wallet from database",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-4 w-4 ${isRefreshing ? "animate-spin text-brand" : ""}` })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Unified income ledger for User ",
							userId,
							" aggregating Referral Income, Global Pool, and Ad Revenue"
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/withdrawal-balance",
						className: "inline-flex items-center justify-center gap-2 rounded-full border border-border bg-secondary/80 px-4 py-2 text-xs font-bold text-foreground transition hover:bg-secondary active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "h-3.5 w-3.5" }), "Withdrawal History"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 via-card to-card p-6 sm:p-8 shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row lg:items-center justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex items-center gap-1 rounded-md bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400 uppercase tracking-wider",
								children: "Total Available Balance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-4xl sm:text-5xl font-black text-foreground tracking-tight",
								children: ["₹", balance.toLocaleString("en-IN", {
									minimumFractionDigits: 2,
									maximumFractionDigits: 2
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-4 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1 text-emerald-400 font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }), " Verified Ledger Protected"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Daily Limit:",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
											"₹",
											WITHDRAWAL_RULES.MAX_DAILY_LIMIT.toLocaleString("en-IN"),
											"/day"
										] })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Remaining Today:",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-foreground",
											children: ["₹", remainingDailyLimit.toLocaleString("en-IN")]
										})
									] })
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleWithdraw,
						className: "rounded-xl border border-border bg-background/90 p-5 space-y-3 w-full lg:w-96 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Request Withdrawal:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-400 font-bold",
									children: "₹1,000 min · ₹10,000 max/day"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-bold text-sm",
									children: "₹"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: withdrawAmount,
									onChange: (e) => handleAmountChange(e.target.value),
									className: `w-full rounded-lg border pl-8 pr-3 py-2 text-sm font-bold text-foreground focus:outline-none ${validationError ? "border-red-500 focus:border-red-500 bg-red-500/5" : "border-border bg-card focus:border-brand"}`,
									min: WITHDRAWAL_RULES.MIN_AMOUNT,
									max: WITHDRAWAL_RULES.MAX_DAILY_LIMIT,
									step: "100",
									placeholder: "Enter amount (Min ₹1,000)"
								})]
							}),
							validationError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 p-2.5 text-xs text-red-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "leading-tight font-medium",
									children: validationError
								})]
							}),
							successMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-2.5 text-xs text-emerald-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "leading-tight font-medium",
									children: successMsg
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-secondary/50 p-2 text-[11px] text-muted-foreground space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Today's Withdrawals:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground",
										children: [
											"₹",
											alreadyWithdrawnToday.toLocaleString("en-IN"),
											" / ₹10,000"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-1.5 w-full bg-secondary rounded-full overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-emerald-500 rounded-full transition-all",
										style: { width: `${Math.min(100, alreadyWithdrawnToday / WITHDRAWAL_RULES.MAX_DAILY_LIMIT * 100)}%` }
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								disabled: withdrawing || Boolean(validationError) || remainingDailyLimit === 0,
								className: "w-full inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-emerald-500 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "h-4 w-4" }), withdrawing ? "Processing Payout..." : remainingDailyLimit === 0 ? "Daily Limit Reached (₹10,000)" : `Withdraw ₹${Number(withdrawAmount || 0).toLocaleString("en-IN")}`]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground font-medium flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3 w-3 text-rose-400" }), "Referral Income"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xl font-bold text-foreground",
								children: ["₹", wallet ? wallet.referralIncome.toFixed(2) : "1,079.50"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "₹1 / Premium Video upload"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground font-medium flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3 text-yellow-400" }), "Video AdSense"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xl font-bold text-yellow-400",
								children: ["₹", wallet ? wallet.adsenseIncome.toFixed(2) : "1,890.20"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Ad revenue monetization"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground font-medium flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Earth, { className: "h-3 w-3 text-cyan-400" }), "Global Pool"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xl font-bold text-cyan-400",
								children: ["₹", wallet ? wallet.globalIncome.toFixed(2) : "2,450.00"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "₹3 pool distributions"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 space-y-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground font-medium flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-3 w-3 text-indigo-400" }), "Affiliate Links"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xl font-bold text-indigo-400",
								children: ["₹", wallet ? wallet.affiliateIncome.toFixed(2) : "940.80"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "Gear & product sales"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card overflow-hidden shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 border-b border-border flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-bold text-foreground",
						children: "Official Transaction Ledger"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Audit-trail synced records with instant balance re-calculation"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground font-mono",
						children: [ledger.length, " Transactions"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-secondary/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Transaction ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Description"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Timestamp"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right whitespace-nowrap",
									children: "Status"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border font-medium",
							children: ledger.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "transition hover:bg-secondary/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-mono text-xs font-bold text-amber-400 whitespace-nowrap",
										children: tx.transactionId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 whitespace-nowrap",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${tx.incomeType === "withdrawal" ? "bg-orange-500/10 text-orange-400" : "bg-secondary text-foreground"}`,
											children: tx.incomeType.replace(/_/g, " ")
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground max-w-sm truncate",
										children: tx.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: `px-4 py-3 font-mono text-xs font-black whitespace-nowrap ${tx.amount < 0 ? "text-orange-400" : "text-emerald-400"}`,
										children: tx.amount < 0 ? `-₹${Math.abs(tx.amount).toFixed(2)}` : `+₹${tx.amount.toFixed(2)}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground whitespace-nowrap",
										children: new Date(tx.createdAt).toLocaleDateString()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right whitespace-nowrap",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }), "Settled"]
										})
									})
								]
							}, tx.id))
						})]
					})
				})]
			})
		]
	}) });
}
//#endregion
export { WalletBalancePage as component };
