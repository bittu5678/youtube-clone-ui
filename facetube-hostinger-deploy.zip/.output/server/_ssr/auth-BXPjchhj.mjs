import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, c as sendWelcomeEmail, l as useAuth, n as FacetubeLogoIcon, o as generateWelcomeEmailContent, r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { At as EyeOff, C as ShieldCheck, Ct as Gift, Kt as CircleCheck, Qt as Check, at as Lock, c as User, kt as Eye, n as X, pt as Inbox, qt as CircleAlert, rt as Mail, un as ArrowLeft, z as Phone, zt as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BXPjchhj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var perks = [
	"Automatic unique FT User ID generation (e.g. FT102857)",
	"Seamless login using either User ID or Email",
	"Personalised recommendations and creator subscriptions",
	"Database-backed profile with welcome email dispatch"
];
function Field({ icon: Icon, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "group flex h-12 items-center gap-3 rounded-xl border border-border bg-secondary/50 px-4 transition focus-within:border-brand/50 focus-within:bg-background focus-within:shadow-lift",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 shrink-0 text-muted-foreground transition group-focus-within:text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			...props,
			className: "h-full w-full min-w-0 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
		})]
	});
}
function AuthPage() {
	const navigate = useNavigate();
	const { user, profile, role, isAdmin, signIn, signUp, signOut } = useAuth();
	const [mode, setMode] = (0, import_react.useState)("login");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [showConfirmPassword, setShowConfirmPassword] = (0, import_react.useState)(false);
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [mobile, setMobile] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [referralCode, setReferralCode] = (0, import_react.useState)("");
	const [loginIdentifier, setLoginIdentifier] = (0, import_react.useState)("");
	const [loginPassword, setLoginPassword] = (0, import_react.useState)("");
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const [successMsg, setSuccessMsg] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [showSuccessPopup, setShowSuccessPopup] = (0, import_react.useState)(false);
	const [registeredUser, setRegisteredUser] = (0, import_react.useState)(null);
	const [registeredUserId, setRegisteredUserId] = (0, import_react.useState)("");
	const [copiedId, setCopiedId] = (0, import_react.useState)(false);
	const [showEmailModal, setShowEmailModal] = (0, import_react.useState)(false);
	const [emailDeliveryStatus, setEmailDeliveryStatus] = (0, import_react.useState)(null);
	const [registeredPassword, setRegisteredPassword] = (0, import_react.useState)("");
	const [isRetryingEmail, setIsRetryingEmail] = (0, import_react.useState)(false);
	const isSignup = mode === "signup";
	(0, import_react.useEffect)(() => {
		setErrorMsg(null);
		setSuccessMsg(null);
	}, [mode]);
	const handleCopyUserId = (idToCopy) => {
		if (!idToCopy) return;
		navigator.clipboard.writeText(idToCopy);
		setCopiedId(true);
		toast.success("User ID copied to clipboard!");
		setTimeout(() => setCopiedId(false), 2500);
	};
	const handleRetryEmail = async () => {
		if (!registeredUserId) return;
		setIsRetryingEmail(true);
		try {
			const res = await sendWelcomeEmail({
				name: registeredUser?.name || fullName,
				email: registeredUser?.email || email,
				userId: registeredUserId,
				password: registeredPassword || password,
				loginLink: "https://youtube-clone-ui-8qmb.vercel.app/login"
			});
			setEmailDeliveryStatus(res);
			if (res.success) toast.success(`Welcome email sent to ${registeredUser?.email || email}`);
			else toast.error("Email delivery failed");
		} catch (_e) {
			toast.error("Email delivery failed");
		} finally {
			setIsRetryingEmail(false);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMsg(null);
		setSuccessMsg(null);
		if (isSignup) {
			if (!fullName.trim()) {
				setErrorMsg("Please enter your Full Name.");
				return;
			}
			if (fullName.trim().length < 2) {
				setErrorMsg("Full Name must be at least 2 characters long.");
				return;
			}
			if (!mobile.trim()) {
				setErrorMsg("Please enter your Mobile Number.");
				return;
			}
			if (mobile.replace(/[^0-9+]/g, "").length < 7) {
				setErrorMsg("Please enter a valid Mobile Number (at least 7 digits).");
				return;
			}
			if (!email.trim() || !email.includes("@")) {
				setErrorMsg("Please enter a valid email address.");
				return;
			}
			if (!password) {
				setErrorMsg("Please enter a password.");
				return;
			}
			if (password.length < 6) {
				setErrorMsg("Password must be at least 6 characters long.");
				return;
			}
			if (password !== confirmPassword) {
				setErrorMsg("Passwords do not match. Please verify your confirm password.");
				return;
			}
			setSubmitting(true);
			const res = await signUp({
				name: fullName.trim(),
				mobile: mobile.trim(),
				email: email.trim(),
				password,
				referralCode: referralCode.trim() || void 0
			});
			setSubmitting(false);
			if (!res.success || !res.userId) setErrorMsg(res.error?.message || "Failed to create account. Please try again.");
			else {
				setRegisteredUserId(res.userId);
				if (res.user) setRegisteredUser(res.user);
				setRegisteredPassword(password);
				if (res.emailDelivery) {
					setEmailDeliveryStatus(res.emailDelivery);
					if (!res.emailDelivery.success) toast.error("Email delivery failed");
					else toast.success(`Welcome email sent to ${res.user?.email || email}`);
				}
				setShowSuccessPopup(true);
				setSuccessMsg(`Registration successful! Generated User ID: ${res.userId}`);
				setLoginIdentifier(res.userId);
				setLoginPassword(password);
			}
		} else {
			if (!loginIdentifier.trim()) {
				setErrorMsg("Please enter your User ID (e.g. FT123456) or Email.");
				return;
			}
			if (!loginPassword) {
				setErrorMsg("Please enter your password.");
				return;
			}
			setSubmitting(true);
			const res = await signIn({
				identifier: loginIdentifier.trim(),
				password: loginPassword
			});
			setSubmitting(false);
			if (!res.success) setErrorMsg(res.error?.message || "Invalid credentials. Please verify your User ID / Email and password.");
			else {
				setSuccessMsg("Signed in successfully! Redirecting to feed...");
				toast.success("Welcome back to FaceTube!");
				setTimeout(() => {
					navigate({ to: "/" });
				}, 800);
			}
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background font-sans text-foreground lg:grid lg:grid-cols-[1.05fr_1fr]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "relative hidden overflow-hidden bg-gradient-to-br from-brand via-brand-dark to-black p-12 lg:flex lg:flex-col lg:justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": true,
						className: "pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": true,
						className: "pointer-events-none absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-black/30 blur-3xl"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacetubeLogoIcon, {
							size: 44,
							className: "drop-shadow-lg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xl font-extrabold tracking-tight text-white",
							children: "FaceTube"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative max-w-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 drop-shadow-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacetubeLogoIcon, { size: 96 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-4xl font-extrabold leading-tight tracking-tight text-white",
								children: "Every story worth watching, in one hub."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-8 space-y-3",
								children: perks.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 text-sm text-white/85",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-white/15",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3 text-white" })
									}), p]
								}, p))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative text-xs text-white/60",
						children: "© 2026 FaceTube. Database-backed streaming platform with Supabase PostgreSQL."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex min-h-screen flex-col justify-center px-5 py-10 sm:px-10 lg:px-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-8 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition hover:text-brand",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Back to FaceTube"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, { showLabelsOnWide: false })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-8 lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 40 })
						}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-secondary/40 p-6 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 place-items-center rounded-full bg-brand text-base font-bold text-brand-foreground shadow-sm",
									children: profile?.name ? profile.name.substring(0, 2).toUpperCase() : profile?.user_id ? profile.user_id.substring(0, 2) : "FT"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-lg font-bold truncate",
												children: profile?.name || user.email?.split("@")[0]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-md px-2 py-0.5 text-xs font-semibold uppercase tracking-wider ${isAdmin ? "bg-brand text-brand-foreground shadow-sm" : "bg-muted text-muted-foreground"}`,
												children: role
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-mono font-semibold text-brand",
											children: ["User ID: ", profile?.user_id || "FT102857"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground truncate",
											children: user.email
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-col gap-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/",
										className: "grid h-11 place-items-center rounded-xl bg-brand text-sm font-bold text-brand-foreground shadow-lift transition hover:bg-brand-dark",
										children: "Go to Feed"
									}),
									isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/admin",
										className: "flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-background text-sm font-semibold text-foreground transition hover:bg-secondary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-brand" }), "Open Admin Panel"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: async () => {
											await signOut();
											toast.success("Signed out successfully.");
										},
										className: "h-11 rounded-xl border border-border text-sm font-semibold text-muted-foreground transition hover:bg-secondary hover:text-foreground",
										children: "Sign Out"
									})
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl font-extrabold tracking-tight",
								children: isSignup ? "Create your account" : "Welcome back"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: isSignup ? "Register now to get your unique FT User ID and start streaming." : "Sign in using your FT User ID or Email to continue."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-7 grid grid-cols-2 gap-1 rounded-full bg-secondary p-1",
								children: ["login", "signup"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode(m),
									className: `rounded-full py-2 text-sm font-semibold transition ${mode === m ? "bg-background text-foreground shadow-card" : "text-muted-foreground hover:text-foreground"}`,
									children: m === "login" ? "Sign in" : "Sign up"
								}, m))
							}),
							errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-start gap-2.5 rounded-xl border border-destructive/30 bg-destructive/10 p-3.5 text-sm text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
							}),
							successMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-start gap-2.5 rounded-xl border border-green-500/30 bg-green-500/10 p-3.5 text-sm text-green-600 dark:text-green-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: successMsg })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "mt-6 space-y-3",
								onSubmit: handleSubmit,
								children: [
									isSignup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											icon: User,
											type: "text",
											placeholder: "Full Name",
											value: fullName,
											onChange: (e) => setFullName(e.target.value),
											required: true,
											autoComplete: "name"
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											icon: Phone,
											type: "tel",
											placeholder: "Mobile Number",
											value: mobile,
											onChange: (e) => setMobile(e.target.value),
											required: true,
											autoComplete: "tel"
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											icon: Mail,
											type: "email",
											placeholder: "Email",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											required: true,
											autoComplete: "email"
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: Lock,
												type: showPassword ? "text" : "password",
												placeholder: "Password",
												value: password,
												onChange: (e) => setPassword(e.target.value),
												required: true,
												autoComplete: "new-password"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": showPassword ? "Hide password" : "Show password",
												onClick: () => setShowPassword((v) => !v),
												className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
												children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: Lock,
												type: showConfirmPassword ? "text" : "password",
												placeholder: "Confirm Password",
												value: confirmPassword,
												onChange: (e) => setConfirmPassword(e.target.value),
												required: true,
												autoComplete: "new-password"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": showConfirmPassword ? "Hide password" : "Show password",
												onClick: () => setShowConfirmPassword((v) => !v),
												className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
												children: showConfirmPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											icon: Gift,
											type: "text",
											placeholder: "Referral Code (Optional)",
											value: referralCode,
											onChange: (e) => setReferralCode(e.target.value),
											autoComplete: "off"
										}) })
									] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										icon: User,
										type: "text",
										placeholder: "User ID (FT123456) or Email",
										value: loginIdentifier,
										onChange: (e) => setLoginIdentifier(e.target.value),
										required: true,
										autoComplete: "username"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-[11px] text-muted-foreground px-1",
										children: [
											"Tip: You can log in using your ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "FT User ID" }),
											" (e.g. FT102857) or your ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Email" }),
											"."
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											icon: Lock,
											type: showPassword ? "text" : "password",
											placeholder: "Password",
											value: loginPassword,
											onChange: (e) => setLoginPassword(e.target.value),
											required: true,
											autoComplete: "current-password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": showPassword ? "Hide password" : "Show password",
											onClick: () => setShowPassword((v) => !v),
											className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
											children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between pt-1 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex items-center gap-2 text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												defaultChecked: true,
												className: "h-4 w-4 accent-current text-brand rounded"
											}), isSignup ? "I agree to the Terms & Privacy" : "Remember me"]
										}), !isSignup && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setLoginIdentifier("FT102857");
												setLoginPassword("password123");
												toast.info("Filled Admin User ID & Demo Password");
											},
											className: "font-medium text-brand hover:underline",
											children: "Fill Admin Demo (FT102857)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: submitting,
										className: "mt-2 h-12 w-full rounded-xl bg-brand text-sm font-bold text-brand-foreground shadow-lift transition hover:bg-brand-dark active:scale-[0.99] disabled:opacity-50",
										children: submitting ? isSignup ? "Creating account..." : "Signing in..." : isSignup ? "Create Account" : "Sign in"
									})
								]
							}),
							!isSignup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 rounded-xl border border-border/70 bg-secondary/30 p-3 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-foreground mb-1",
									children: "Quick Demo Accounts (Database Seeded):"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-1.5 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setLoginIdentifier("FT102857");
											setLoginPassword("password123");
										},
										className: "rounded-lg border border-border bg-background px-2.5 py-1.5 text-left hover:border-brand/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-brand block",
											children: "Admin: FT102857"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate block opacity-80",
											children: "admin@facetube.com"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setLoginIdentifier("FT483921");
											setLoginPassword("password123");
										},
										className: "rounded-lg border border-border bg-background px-2.5 py-1.5 text-left hover:border-brand/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-brand block",
											children: "Alex: FT483921"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate block opacity-80",
											children: "alex@facetube.com"
										})]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "my-6 flex items-center gap-3 text-xs uppercase tracking-widest text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
									"or continue with",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-3",
								children: ["Google", "Apple"].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setLoginIdentifier(p === "Google" ? "FT102857" : "FT483921");
										setLoginPassword("password123");
									},
									className: "h-11 rounded-xl border border-border text-sm font-semibold text-foreground transition hover:border-brand/40 hover:bg-secondary",
									children: [p, " (Demo)"]
								}, p))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-8 text-center text-sm text-muted-foreground",
								children: [
									isSignup ? "Already have an account?" : "New to FaceTube?",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMode(isSignup ? "login" : "signup"),
										className: "font-semibold text-brand hover:underline",
										children: isSignup ? "Sign in" : "Create one free"
									})
								]
							})
						] })
					]
				})
			}),
			showSuccessPopup && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "dialog",
				"aria-modal": "true",
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShowSuccessPopup(false),
							className: "absolute right-4 top-4 rounded-full p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-brand/15 text-brand shadow-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-9 w-9 text-brand" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl font-extrabold tracking-tight text-foreground",
								children: "Registration Successful!"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Your account has been securely saved into the database."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 rounded-2xl border-2 border-brand/30 bg-brand/5 p-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold uppercase tracking-wider text-brand",
									children: "Your User ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-center justify-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-3xl font-extrabold tracking-widest text-foreground",
										children: registeredUserId
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleCopyUserId(registeredUserId),
										"aria-label": "Copy User ID",
										className: "rounded-xl border border-brand/30 bg-background p-2 text-brand transition hover:bg-brand hover:text-brand-foreground",
										children: copiedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs font-semibold text-foreground/90",
									children: "You can login using your User ID or Email."
								})
							]
						}),
						registeredUser && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl border border-border/80 bg-secondary/40 p-3.5 text-xs space-y-1.5 text-foreground/85",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Full Name:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: registeredUser.name
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Email:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: registeredUser.email
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Mobile:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: registeredUser.mobile
									})]
								}),
								registeredUser.referral_code && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Referral Code:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-brand",
										children: registeredUser.referral_code
									})]
								})
							]
						}),
						emailDeliveryStatus?.success === true ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2.5 text-xs text-emerald-600 dark:text-emerald-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Welcome email sent to ", registeredUser?.email || email] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowEmailModal(true),
								className: "font-bold underline hover:text-emerald-700 dark:hover:text-emerald-300",
								children: "View Email"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between rounded-xl border border-destructive/40 bg-destructive/10 px-3.5 py-2.5 text-xs text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: emailDeliveryStatus?.error || "Email delivery failed"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowEmailModal(true),
								className: "font-bold underline hover:opacity-80",
								children: "View Details"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-col gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setShowSuccessPopup(false);
									setMode("login");
									setLoginIdentifier(registeredUserId);
								},
								className: "grid h-12 place-items-center rounded-xl bg-brand text-sm font-bold text-brand-foreground shadow-lift transition hover:bg-brand-dark",
								children: ["Log In Now with ", registeredUserId]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setShowSuccessPopup(false);
									navigate({ to: "/" });
								},
								className: "h-11 rounded-xl border border-border text-sm font-semibold text-muted-foreground transition hover:bg-secondary hover:text-foreground",
								children: "Go to Home Feed"
							})]
						})
					]
				})
			}),
			showEmailModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "dialog",
				"aria-modal": "true",
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShowEmailModal(false),
							className: "absolute right-4 top-4 rounded-full p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-9 w-9 place-items-center rounded-full bg-brand/15 text-brand",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-base font-bold text-foreground",
								children: "Welcome Email Preview"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Delivered upon successful registration"
							})] })]
						}),
						emailDeliveryStatus?.success === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3.5 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0" }), "Email delivery failed"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: handleRetryEmail,
									disabled: isRetryingEmail,
									className: "rounded-md bg-destructive text-destructive-foreground px-2.5 py-1 text-[11px] font-bold hover:opacity-90 disabled:opacity-50",
									children: isRetryingEmail ? "Retrying..." : "Retry Delivery"
								})]
							}), emailDeliveryStatus.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[11px] opacity-80",
								children: emailDeliveryStatus.error
							})]
						}) : emailDeliveryStatus?.success ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3.5 flex items-center justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-600 dark:text-emerald-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
									" Delivered via",
									" ",
									emailDeliveryStatus.provider?.toUpperCase() || "SMTP/RESEND"
								]
							}), emailDeliveryStatus.messageId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[10px] opacity-75",
								children: [
									"ID: ",
									emailDeliveryStatus.messageId.slice(0, 14),
									"..."
								]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl border border-border bg-secondary/30 p-4 text-xs font-mono",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-border/80 pb-2 mb-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-muted-foreground",
										children: "To:"
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: registeredUser?.email || email
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-muted-foreground",
										children: "Subject:"
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground font-semibold",
										children: "Welcome to Facetube"
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "whitespace-pre-wrap font-sans text-sm leading-relaxed text-foreground/90",
								children: generateWelcomeEmailContent(registeredUser?.name || fullName, registeredUser?.email || email, registeredUserId, registeredPassword || password).body
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowEmailModal(false),
								className: "rounded-xl bg-secondary px-5 py-2 text-xs font-semibold text-foreground transition hover:bg-secondary/80",
								children: "Close Preview"
							})
						})
					]
				})
			})
		]
	});
}
//#endregion
export { AuthPage as component };
