import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { L as Plus, N as Radio, c as User, et as Megaphone, ht as House, ln as ArrowRight, mt as Image, n as X, o as Video, t as Zap, y as Sparkles } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thumb-6-BJ7y275J.js
var thumb_1_default = "/assets/thumb-1-BLDUMvA-.jpg";
var thumb_3_default = "/assets/thumb-3-CjusrIMk.jpg";
var thumb_5_default = "/assets/thumb-5-C5dA8AC_.jpg";
var thumb_6_default = "/assets/thumb-6-C43Zhxnm.jpg";
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/BottomNav-D75yrKNZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShortsIcon({ className = "h-5 w-5", active = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: active ? "currentColor" : "none",
		stroke: "currentColor",
		strokeWidth: active ? "0" : "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "5",
				y: "2.5",
				width: "14",
				height: "19",
				rx: "3.5",
				ry: "3.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "10,8.5 16,12 10,15.5",
				fill: "currentColor",
				strokeWidth: "0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "10",
				y1: "4.5",
				x2: "14",
				y2: "4.5",
				stroke: "currentColor",
				strokeWidth: "1.5",
				strokeLinecap: "round"
			})
		]
	});
}
var UPLOAD_OPTIONS_LIST = [
	{
		id: "free",
		title: "Free",
		subtitle: "Free Short & Long Videos · Fee: ₹0",
		badge: "Free · ₹0",
		icon: Video,
		accentClass: "border-sky-500/30 hover:border-sky-500/60 bg-sky-500/5 hover:bg-sky-500/10",
		iconBgClass: "bg-sky-500/20 text-sky-400 ring-1 ring-sky-500/30",
		description: "Publish standard public videos with ₹0 upload fee and no payment required."
	},
	{
		id: "premium",
		title: "Premium",
		subtitle: "Premium Short & Long Videos · Fee: ₹6",
		badge: "Premium · ₹6",
		icon: Sparkles,
		isPremium: true,
		accentClass: "border-amber-500/50 hover:border-amber-400 bg-gradient-to-r from-amber-500/15 via-card to-card hover:from-amber-500/20 ring-1 ring-amber-500/30 shadow-[0_0_20px_rgba(245,158,11,0.1)]",
		iconBgClass: "bg-gradient-to-br from-amber-400 to-yellow-500 text-black ring-1 ring-amber-400/60 font-black",
		description: "Monetized video upload unlocking Direct Referral (₹1) and Global Income Pool (₹3)."
	},
	{
		id: "ad_promotion",
		title: "Ad Promotion",
		subtitle: "Short & Long Promotion · 7d ₹100, 15d ₹200...",
		badge: "Ad Promotion",
		icon: Megaphone,
		accentClass: "border-emerald-500/30 hover:border-emerald-500/60 bg-emerald-500/5 hover:bg-emerald-500/10",
		iconBgClass: "bg-emerald-500/20 text-emerald-400 ring-1 ring-emerald-500/30",
		description: "Launch targeted demographic promotion campaigns with verified payment tracking."
	},
	{
		id: "image",
		title: "Image Upload",
		subtitle: "JPG, PNG, WEBP · Media Library",
		badge: "Image Upload",
		icon: Image,
		accentClass: "border-teal-500/30 hover:border-teal-500/60 bg-teal-500/5 hover:bg-teal-500/10",
		iconBgClass: "bg-teal-500/20 text-teal-400 ring-1 ring-teal-500/30",
		description: "Upload independent image assets: thumbnails, channel graphics, and photo posts."
	}
];
function UploadOptionsModal({ isOpen, onClose }) {
	(0, import_react.useEffect)(() => {
		if (!isOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isOpen, onClose]);
	(0, import_react.useEffect)(() => {
		if (isOpen) document.body.style.overflow = "hidden";
		else document.body.style.overflow = "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [isOpen]);
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 bg-black/65 backdrop-blur-sm transition-opacity animate-in fade-in",
			onClick: onClose,
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "upload-options-title",
			className: "relative z-10 w-full max-w-lg rounded-t-3xl border border-border bg-card p-5 shadow-2xl transition-all animate-in slide-in-from-bottom-5 sm:rounded-3xl sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto -mt-2 mb-4 h-1.5 w-12 rounded-full bg-muted-foreground/30 sm:hidden" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start justify-between border-b border-border/60 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 rounded-full border border-brand/30 bg-brand/10 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider text-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3 w-3" }), "FaceTube Studio"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "upload-options-title",
							className: "mt-1.5 text-lg font-bold text-foreground sm:text-xl",
							children: "Upload Options"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Select one of the 4 publishing pathways"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "grid h-8 w-8 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground active:scale-95",
						"aria-label": "Close upload options",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2.5 max-h-[60vh] overflow-y-auto pr-1",
					children: UPLOAD_OPTIONS_LIST.map((opt) => {
						const Icon = opt.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/upload",
							search: { mode: opt.id },
							onClick: onClose,
							className: `group flex items-center justify-between rounded-2xl border p-3.5 text-left transition-all active:scale-[0.99] ${opt.accentClass}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3.5 min-w-0 pr-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `grid h-11 w-11 shrink-0 place-items-center rounded-xl ${opt.iconBgClass} transition group-hover:scale-105`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-foreground group-hover:text-brand transition-colors truncate",
											children: opt.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${opt.isPremium ? "border border-amber-400/40 bg-amber-400/15 text-amber-300" : "bg-secondary/80 text-muted-foreground"}`,
											children: opt.badge
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground truncate mt-0.5",
										children: opt.subtitle
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0 ml-auto",
								children: [opt.isPremium && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center justify-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -inset-1 rounded-full bg-amber-400/35 blur-sm animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center gap-1 rounded-full border border-amber-400/60 bg-gradient-to-r from-amber-500/25 via-yellow-400/35 to-amber-500/25 px-2 py-0.5 text-[10px] font-black tracking-wide text-amber-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3.5 w-3.5 fill-amber-400 text-amber-300 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PREMIUM" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 shrink-0 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-brand ml-1" })]
							})]
						}, opt.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 pt-3 border-t border-border/60 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Looking for full overview?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/upload",
						onClick: onClose,
						className: "inline-flex items-center gap-1.5 rounded-full bg-secondary px-3.5 py-1.5 text-xs font-semibold text-foreground transition hover:bg-brand hover:text-white",
						children: ["Open Full Studio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3" })]
					})]
				})
			]
		})]
	});
}
function BottomNav() {
	const currentPath = useRouterState().location.pathname;
	const { user, profile } = useAuth();
	const [uploadModalOpen, setUploadModalOpen] = (0, import_react.useState)(false);
	const isHomeActive = currentPath === "/";
	const isShortsActive = currentPath.startsWith("/shorts");
	const isLiveActive = currentPath.startsWith("/live");
	const isYouActive = currentPath.startsWith("/profile") || currentPath.startsWith("/auth");
	const isUploadActive = currentPath.startsWith("/upload") || uploadModalOpen;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Bottom Navigation",
		className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur-md pb-[env(safe-area-inset-bottom)] md:bottom-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-auto md:min-w-[480px] md:max-w-xl md:rounded-2xl md:border md:border-border/80 md:bg-card/90 md:shadow-2xl md:backdrop-blur-xl md:px-3 md:py-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "grid grid-cols-5 items-center justify-items-center h-14 md:h-13",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "w-full flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: `flex w-full flex-col items-center justify-center gap-1 py-1 text-[11px] font-medium transition active:scale-95 ${isHomeActive ? "text-brand font-semibold" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: `h-5 w-5 ${isHomeActive ? "stroke-[2.4]" : "stroke-[1.8]"}` })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Home" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "w-full flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/shorts",
						className: `flex w-full flex-col items-center justify-center gap-1 py-1 text-[11px] font-medium transition active:scale-95 ${isShortsActive ? "text-brand font-semibold" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortsIcon, {
								className: "h-5 w-5",
								active: isShortsActive
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shorts" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "w-full flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-label": "Upload Options",
						onClick: () => setUploadModalOpen(true),
						className: "group relative -mt-2.5 md:-mt-1 flex flex-col items-center justify-center focus-visible:outline-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid h-11 w-11 place-items-center rounded-full border-2 transition-all duration-200 shadow-md group-hover:scale-105 active:scale-95 ${isUploadActive ? "bg-brand text-white border-brand shadow-brand/20 ring-4 ring-brand/20" : "bg-secondary text-foreground border-border/80 hover:border-brand/60 hover:text-brand"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-6 w-6 stroke-[2.4]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Upload"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "w-full flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/live",
						className: `flex w-full flex-col items-center justify-center gap-1 py-1 text-[11px] font-medium transition active:scale-95 ${isLiveActive ? "text-brand font-semibold" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: `h-5 w-5 ${isLiveActive ? "stroke-[2.4] text-red-500" : "stroke-[1.8]"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -right-1 -top-0.5 h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Live" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "w-full flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/profile",
						className: `flex w-full flex-col items-center justify-center gap-1 py-1 text-[11px] font-medium transition active:scale-95 ${isYouActive ? "text-brand font-semibold" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative",
							children: user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold text-white transition ${isYouActive ? "ring-2 ring-brand bg-gradient-to-br from-brand to-brand-dark" : "bg-gradient-to-br from-brand to-brand-dark"}`,
								children: (profile?.username || user.email || "U").charAt(0).toUpperCase()
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: `h-5 w-5 ${isYouActive ? "stroke-[2.4]" : "stroke-[1.8]"}` })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "You" })]
					})
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadOptionsModal, {
		isOpen: uploadModalOpen,
		onClose: () => setUploadModalOpen(false)
	})] });
}
//#endregion
export { thumb_5_default as a, thumb_3_default as i, ShortsIcon as n, thumb_6_default as o, thumb_1_default as r, BottomNav as t };
