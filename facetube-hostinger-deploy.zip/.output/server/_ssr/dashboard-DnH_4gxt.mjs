import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Ft as DollarSign, Ht as Clock, Wt as Clapperboard, an as Bell, ct as LayoutDashboard, m as TrendingUp, o as Video, r as Wallet, t as Zap } from "../_libs/lucide-react.mjs";
import { m as getUserWallet, s as VideoHubLayout, v as calculateUserVideoCounts } from "./router-vsnEDfJA.mjs";
import { t as DashboardSummaryCards } from "./DashboardSummaryCards-DipxqPw2.mjs";
import { t as getReferralDashboardData } from "./referral-service-B5C9bF_V.mjs";
import { n as calculateRankFromSubscribers } from "./certificate-service-C_JpbKzf.mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as CartesianGrid, r as YAxis, s as Bar, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DnH_4gxt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUBSCRIBER_CHART_DATA = [
	{
		day: "Mon",
		subscribers: 124200,
		growth: 120
	},
	{
		day: "Tue",
		subscribers: 124950,
		growth: 750
	},
	{
		day: "Wed",
		subscribers: 125600,
		growth: 650
	},
	{
		day: "Thu",
		subscribers: 126400,
		growth: 800
	},
	{
		day: "Fri",
		subscribers: 127100,
		growth: 700
	},
	{
		day: "Sat",
		subscribers: 127850,
		growth: 750
	},
	{
		day: "Sun",
		subscribers: 128400,
		growth: 550
	}
];
var WATCH_TIME_CHART_DATA = [
	{
		day: "Mon",
		hours: 410
	},
	{
		day: "Tue",
		hours: 520
	},
	{
		day: "Wed",
		hours: 480
	},
	{
		day: "Thu",
		hours: 640
	},
	{
		day: "Fri",
		hours: 780
	},
	{
		day: "Sat",
		hours: 910
	},
	{
		day: "Sun",
		hours: 860
	}
];
var REVENUE_CHART_DATA = [
	{
		day: "Mon",
		revenue: 240
	},
	{
		day: "Tue",
		revenue: 310
	},
	{
		day: "Wed",
		revenue: 290
	},
	{
		day: "Thu",
		revenue: 420
	},
	{
		day: "Fri",
		revenue: 530
	},
	{
		day: "Sat",
		revenue: 680
	},
	{
		day: "Sun",
		revenue: 590
	}
];
function DashboardPage() {
	const { user, profile, dbUser } = useAuth();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [videoCounts, setVideoCounts] = (0, import_react.useState)({
		freeShort: 1,
		freeLong: 1,
		premiumShort: 2,
		premiumLong: 1,
		totalFree: 2,
		totalPremium: 3,
		totalUploaded: 5
	});
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const [referralData, setReferralData] = (0, import_react.useState)(null);
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	(0, import_react.useEffect)(() => {
		let mounted = true;
		async function loadRealData() {
			try {
				const [counts, userWallet, refData] = await Promise.all([
					calculateUserVideoCounts(userId),
					getUserWallet(userId),
					getReferralDashboardData(userId)
				]);
				if (mounted) {
					setVideoCounts(counts);
					setWallet(userWallet);
					setReferralData(refData);
					setIsLoading(false);
				}
			} catch (err) {
				console.error("Dashboard real data load error:", err);
				if (mounted) setIsLoading(false);
			}
		}
		loadRealData();
		return () => {
			mounted = false;
		};
	}, [userId]);
	const currentCreatorRank = calculateRankFromSubscribers(128400);
	const dynamicCardOverrides = {
		"free-videos": String(videoCounts.totalFree),
		"premium-videos": String(videoCounts.totalPremium),
		"short-videos": String(videoCounts.freeShort + videoCounts.premiumShort),
		"total-referrals": referralData ? String(referralData.directReferralsCount) : "24",
		"total-team": referralData ? String(referralData.teamMembersCount) : "89",
		"wallet-balance": wallet ? `₹${wallet.balance.toFixed(2)}` : "₹4,280.50",
		"referral-income": referralData ? `₹${referralData.referralIncome.toFixed(2)}` : "₹1,079.50",
		"global-income": wallet ? `₹${wallet.globalIncome.toFixed(2)}` : "₹2,450.00",
		"current-rank": currentCreatorRank.awardName
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
							children: "Dashboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400",
							children: "Real Database Live"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"All 16 performance metrics, dynamic video classifications, and income streams for",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: userId })
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/wallet-balance",
						className: "inline-flex items-center justify-center gap-2 rounded-full border border-border bg-secondary/80 px-4 py-2 text-xs font-bold text-foreground transition hover:bg-secondary active:scale-95",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3.5 w-3.5 text-emerald-400" }),
							"Wallet: ",
							wallet ? `₹${wallet.balance.toFixed(2)}` : "₹4,280.50"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/upload",
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand px-4 py-2 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-3.5 w-3.5" }), "Upload Video"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-border bg-card p-6 sm:p-7 shadow-card space-y-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/60 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 rounded-md bg-brand/10 px-2 py-0.5 text-[11px] font-bold uppercase tracking-wider text-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-3.5 w-3.5" }), "Video Inventory Classification"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-lg sm:text-xl font-black text-foreground",
							children: "Uploaded Video Counts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Dynamically calculated from real uploaded video records for User ",
								userId,
								"."
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-muted-foreground",
							children: [
								"Total Uploaded:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-foreground",
									children: [videoCounts.totalUploaded, " Videos"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/upload",
							className: "inline-flex items-center gap-1 rounded-xl bg-secondary px-3 py-1.5 font-bold text-foreground hover:bg-secondary/80 transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+ Upload New" })
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-sky-500/30 bg-gradient-to-b from-sky-500/10 via-card to-card p-5 space-y-2 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-sky-400",
										children: "FREE · Short"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-8 w-8 place-items-center rounded-xl bg-sky-500/20 text-sky-400",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "h-4 w-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-black text-foreground tracking-tight",
									children: videoCounts.freeShort
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1 border-t border-sky-500/20 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-sky-300",
										children: "1. Free Short Video"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "9:16 Vertical"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-sky-500/30 bg-gradient-to-b from-sky-500/10 via-card to-card p-5 space-y-2 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-sky-400",
										children: "FREE · Long Form"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-8 w-8 place-items-center rounded-xl bg-sky-500/20 text-sky-400",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-4 w-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-black text-foreground tracking-tight",
									children: videoCounts.freeLong
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1 border-t border-sky-500/20 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-sky-300",
										children: "2. Free Long Video"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Standard 16:9"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-amber-500/40 bg-gradient-to-b from-amber-500/15 via-card to-card p-5 space-y-2 shadow-[0_0_20px_rgba(245,158,11,0.08)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3 w-3 fill-amber-400" }), "PREMIUM · Short"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-8 w-8 place-items-center rounded-xl bg-amber-400/20 text-amber-400 font-bold",
										children: "⚡"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-black text-foreground tracking-tight",
									children: videoCounts.premiumShort
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1 border-t border-amber-500/20 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-amber-300",
										children: "3. Premium Short Video"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-amber-400/80 font-mono",
										children: "Paid (₹6)"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-amber-500/40 bg-gradient-to-b from-amber-500/15 via-card to-card p-5 space-y-2 shadow-[0_0_20px_rgba(245,158,11,0.08)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3 w-3 fill-amber-400" }), "PREMIUM · Long Form"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-8 w-8 place-items-center rounded-xl bg-amber-400/20 text-amber-400 font-bold",
										children: "⚡"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-black text-foreground tracking-tight",
									children: videoCounts.premiumLong
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1 border-t border-amber-500/20 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-amber-300",
										children: "4. Premium Long Video"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-amber-400/80 font-mono",
										children: "Paid (₹6)"
									})]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-5 sm:p-6 shadow-card space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-3.5 w-3.5 text-rose-400" }), "Subscribers Growth"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-black text-foreground mt-0.5",
									children: "128.4K"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }), " +2.4K this mo"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-44 w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
										data: SUBSCRIBER_CHART_DATA,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "subGradient",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#f43f5e",
													stopOpacity: .4
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#f43f5e",
													stopOpacity: 0
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												stroke: "#27272a",
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "day",
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false,
												domain: ["dataMin - 1000", "dataMax + 500"],
												tickFormatter: (val) => `${(val / 1e3).toFixed(0)}k`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
												backgroundColor: "#18181b",
												borderColor: "#27272a",
												borderRadius: "12px",
												fontSize: "12px"
											} }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "subscribers",
												stroke: "#f43f5e",
												strokeWidth: 2.5,
												fillOpacity: 1,
												fill: "url(#subGradient)"
											})
										]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground text-center",
								children: ["Channel follower retention rate: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "94.2%" })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-5 sm:p-6 shadow-card space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-blue-400" }), "Watch Time (Hours)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-black text-foreground mt-0.5",
									children: "4,660 hrs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }), " +18.4%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-44 w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: WATCH_TIME_CHART_DATA,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												stroke: "#27272a",
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "day",
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
												backgroundColor: "#18181b",
												borderColor: "#27272a",
												borderRadius: "12px",
												fontSize: "12px"
											} }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "hours",
												fill: "#38bdf8",
												radius: [
													6,
													6,
													0,
													0
												]
											})
										]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground text-center",
								children: [
									"Avg view duration: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "8m 42s" }),
									" across all videos"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-5 sm:p-6 shadow-card space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-3.5 w-3.5 text-emerald-400" }), "Estimated Revenue"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-black text-emerald-400 mt-0.5",
									children: wallet ? `$${wallet.totalEarned.toFixed(2)}` : "$7,430.50"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }), " +26.8%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-44 w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
										data: REVENUE_CHART_DATA,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "revGradient",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#10b981",
													stopOpacity: .4
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#10b981",
													stopOpacity: 0
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												stroke: "#27272a",
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "day",
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												stroke: "#71717a",
												fontSize: 11,
												tickLine: false,
												tickFormatter: (v) => `$${v}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
												backgroundColor: "#18181b",
												borderColor: "#27272a",
												borderRadius: "12px",
												fontSize: "12px"
											} }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "revenue",
												stroke: "#10b981",
												strokeWidth: 2.5,
												fillOpacity: 1,
												fill: "url(#revGradient)"
											})
										]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground text-center",
								children: "Direct Referral + Global Pool + AdSense split"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 overflow-x-auto pb-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter("all"),
						className: `rounded-full px-4 py-1.5 text-xs font-bold transition ${filter === "all" ? "bg-brand text-white shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
						children: "All 16 Summary Cards"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter("income"),
						className: `rounded-full px-4 py-1.5 text-xs font-bold transition ${filter === "income" ? "bg-brand text-white shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
						children: "Income Streams (6)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter("videos"),
						className: `rounded-full px-4 py-1.5 text-xs font-bold transition ${filter === "videos" ? "bg-brand text-white shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
						children: "Video Content (6)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter("network"),
						className: `rounded-full px-4 py-1.5 text-xs font-bold transition ${filter === "network" ? "bg-brand text-white shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
						children: "Team & Subscribers (4)"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardSummaryCards, {
				filterCategory: filter,
				dynamicOverrides: dynamicCardOverrides
			})
		]
	}) });
}
//#endregion
export { DashboardPage as component };
