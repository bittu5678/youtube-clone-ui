import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Bt as Compass, G as Music, H as Newspaper, I as Podcast, Tt as Flame, Wt as Clapperboard, bt as GraduationCap, wt as Gamepad2, y as Sparkles } from "../_libs/lucide-react.mjs";
import { A as trending, D as creators, T as allVideos, s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
import { t as VideoCard } from "./VideoCard-Cc9hfZ35.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-4MOKAyNc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var exploreCategories = [
	{
		label: "Trending",
		icon: Flame,
		color: "text-amber-500 bg-amber-500/10 border-amber-500/20"
	},
	{
		label: "Music",
		icon: Music,
		color: "text-red-500 bg-red-500/10 border-red-500/20"
	},
	{
		label: "Gaming",
		icon: Gamepad2,
		color: "text-purple-500 bg-purple-500/10 border-purple-500/20"
	},
	{
		label: "Movies & Shows",
		icon: Clapperboard,
		color: "text-blue-500 bg-blue-500/10 border-blue-500/20"
	},
	{
		label: "News",
		icon: Newspaper,
		color: "text-emerald-500 bg-emerald-500/10 border-emerald-500/20"
	},
	{
		label: "Podcasts",
		icon: Podcast,
		color: "text-indigo-500 bg-indigo-500/10 border-indigo-500/20"
	},
	{
		label: "Learning",
		icon: GraduationCap,
		color: "text-cyan-500 bg-cyan-500/10 border-cyan-500/20"
	}
];
function ExplorePage() {
	const [selectedTag, setSelectedTag] = (0, import_react.useState)("Trending");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const filteredVideos = allVideos.filter((v) => {
		if (searchQuery.trim()) {
			const q = searchQuery.toLowerCase();
			return v.title.toLowerCase().includes(q) || v.channel.toLowerCase().includes(q) || v.category.toLowerCase().includes(q);
		}
		if (selectedTag === "Trending") return true;
		if (selectedTag === "Music") return v.category === "Music";
		if (selectedTag === "Gaming") return v.category === "Gaming";
		if (selectedTag === "Learning") return v.category === "Coding" || v.category === "AI" || v.category === "React";
		if (selectedTag === "Podcasts") return v.category === "Podcasts";
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, {
		query: searchQuery,
		onQueryChange: setSearchQuery,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 py-6 sm:px-6 lg:px-8 space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Explore"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Discover what's trending across FaceTube right now"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3",
					children: exploreCategories.map((cat) => {
						const Icon = cat.icon;
						const isSelected = selectedTag === cat.label;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedTag(cat.label),
							className: `flex items-center gap-2.5 rounded-2xl border p-3 text-left transition-all ${isSelected ? "bg-brand text-white border-brand shadow-sm" : `${cat.color} hover:scale-102 hover:shadow-sm`}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-5 w-5 shrink-0 ${isSelected ? "text-white" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-xs font-bold truncate ${isSelected ? "text-white" : "text-foreground"}`,
								children: cat.label
							})]
						}, cat.label);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "h-5 w-5 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold text-foreground sm:text-xl",
								children: "Trending Videos"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Updated in real-time"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
						children: trending.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: v }, `explore-trending-${v.id}`))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 rounded-3xl border border-border bg-card p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-bold text-foreground sm:text-lg",
								children: "Featured FaceTube Creators"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3",
						children: creators.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center justify-center p-3 rounded-2xl border border-border bg-background text-center transition hover:border-brand/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-sm font-bold text-white shadow-sm mb-2",
									children: c.initials
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-foreground truncate w-full",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground mt-0.5 truncate w-full",
									children: c.subs
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 rounded-full bg-secondary px-2 py-0.5 text-[9px] font-semibold text-muted-foreground",
									children: c.tag
								})
							]
						}, c.name))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold text-foreground sm:text-xl",
						children: selectedTag === "Trending" ? "Fresh Discoveries" : `${selectedTag} Videos`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
						children: filteredVideos.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: v }, `explore-feed-${v.id}`))
					})]
				})
			]
		})
	});
}
//#endregion
export { ExplorePage as component };
