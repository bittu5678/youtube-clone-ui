import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as ShieldCheck, Dt as FilePlay, Ft as DollarSign, Ht as Clock, Kt as CircleCheck, Qt as Check, R as Play, Tt as Flame, V as Pause, Vt as CloudUpload, et as Megaphone, jt as ExternalLink, kt as Eye, ln as ArrowRight, lt as Layers, q as MousePointerClick, s as Users, sn as Award, tn as Calendar, y as Sparkles } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ads-promotions-BTvyIL7Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AD_PLANS = [
	{
		id: "plan-7-days",
		name: "7-Day Sprint",
		durationLabel: "7 Days",
		days: 7,
		price: 100,
		dailyRate: "₹14.28/day",
		impressions: "15,000+ views",
		features: [
			"Standard video feed placement",
			"Suggested video cards boost",
			"Real-time impressions & CTR analytics",
			"Direct Referrer earns ₹10 (10%)"
		]
	},
	{
		id: "plan-15-days",
		name: "15-Day Booster",
		durationLabel: "15 Days",
		days: 15,
		price: 200,
		dailyRate: "₹13.33/day",
		impressions: "45,000+ views",
		features: [
			"Mid-roll stream placement",
			"Sidebar sticky recommendation",
			"Audience demographic targeting",
			"Direct Referrer earns ₹20 (10%)"
		]
	},
	{
		id: "plan-monthly",
		name: "Monthly Pro",
		durationLabel: "Monthly (30 Days)",
		days: 30,
		price: 300,
		dailyRate: "₹10.00/day",
		impressions: "120,000+ views",
		features: [
			"Home feed hero showcase",
			"Top search result priority badge",
			"Priority 24/7 video rotation",
			"Direct Referrer earns ₹30 (10%)"
		],
		isPopular: true
	},
	{
		id: "plan-yearly",
		name: "Yearly Enterprise",
		durationLabel: "Yearly (365 Days)",
		days: 365,
		price: 3e4,
		dailyRate: "₹82.19/day",
		impressions: "1,800,000+ views",
		features: [
			"365 Days Non-Stop Global Reach",
			"Verified Brand Partner spotlight",
			"Dedicated account manager support",
			"Direct Referrer earns ₹3,000 (10%)"
		],
		isBestValue: true
	}
];
var INITIAL_CAMPAIGNS = [{
	id: "camp-001",
	title: "FaceTube Creator Studio Pro Launch Promo",
	videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
	destinationUrl: "https://facetube.app/studio",
	category: "Technology",
	planName: "15-Day Booster",
	durationLabel: "15 Days",
	price: 200,
	referrerCommission: 20,
	startDate: "2026-09-15",
	expiryDate: "2026-09-30",
	status: "Active",
	impressions: 28410,
	clicks: 1140,
	ctr: "4.01%"
}, {
	id: "camp-002",
	title: "CyberShield Security Software Deal 50% Off",
	videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
	destinationUrl: "https://cybershield.security/offer",
	category: "Software",
	planName: "Monthly Pro",
	durationLabel: "Monthly (30 Days)",
	price: 300,
	referrerCommission: 30,
	startDate: "2026-09-02",
	expiryDate: "2026-10-02",
	status: "Active",
	impressions: 89340,
	clicks: 3420,
	ctr: "3.83%"
}];
function AdsPromotionsPage() {
	const { user, profile, dbUser } = useAuth();
	const userName = profile?.full_name || profile?.name || dbUser?.name || user?.user_metadata?.name || "Alex Rivera";
	const sponsorId = "FT810492";
	const sponsorName = "Samantha Chen";
	const [selectedPlanId, setSelectedPlanId] = (0, import_react.useState)("plan-monthly");
	const selectedPlan = AD_PLANS.find((p) => p.id === selectedPlanId) || AD_PLANS[2];
	const [videoFile, setVideoFile] = (0, import_react.useState)(null);
	const [videoPreviewUrl, setVideoPreviewUrl] = (0, import_react.useState)("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4");
	const [campaignTitle, setCampaignTitle] = (0, import_react.useState)("NextGen AI Video Creation Engine");
	const [destinationUrl, setDestinationUrl] = (0, import_react.useState)("https://mybrand.com/promo");
	const [category, setCategory] = (0, import_react.useState)("Technology & Gadgets");
	const [ctaText, setCtaText] = (0, import_react.useState)("Learn More");
	const [isUploading, setIsUploading] = (0, import_react.useState)(false);
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("wallet");
	const [isActivating, setIsActivating] = (0, import_react.useState)(false);
	const [campaigns, setCampaigns] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem("facetube_ad_promotions_v1");
			if (saved) return JSON.parse(saved);
		} catch (_e) {}
		return INITIAL_CAMPAIGNS;
	});
	(0, import_react.useEffect)(() => {
		localStorage.setItem("facetube_ad_promotions_v1", JSON.stringify(campaigns));
	}, [campaigns]);
	const handleVideoFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.type.startsWith("video/")) {
			toast.error("Please upload a valid video file (MP4, WebM, MOV).");
			return;
		}
		if (file.size > 157286400) {
			toast.error("Video file size cannot exceed 150MB.");
			return;
		}
		setVideoFile(file);
		const objectUrl = URL.createObjectURL(file);
		setVideoPreviewUrl(objectUrl);
		if (!campaignTitle || campaignTitle === "NextGen AI Video Creation Engine") setCampaignTitle(file.name.replace(/\.[^/.]+$/, ""));
		toast.success(`Video "${file.name}" loaded successfully for ad promotion!`);
	};
	const calculateExpiryDate = (days) => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() + days);
		return d.toISOString().split("T")[0];
	};
	const handleActivatePromotion = async () => {
		if (!campaignTitle.trim()) {
			toast.error("Please enter an Advertisement Campaign Title.");
			return;
		}
		setIsActivating(true);
		try {
			const { initiateAdsPromotionPayment } = await import("./razorpay-service-Cd_wwC5p.mjs");
			await initiateAdsPromotionPayment({
				userId: profile?.user_id || dbUser?.user_id || "FT483921",
				userName,
				userEmail: user?.email || void 0,
				userMobile: profile?.mobile || dbUser?.mobile || void 0,
				videoId: `camp-vid-${Date.now()}`,
				planId: selectedPlan.id,
				planName: selectedPlan.name,
				durationDays: selectedPlan.days,
				price: selectedPlan.price,
				directReferrerId: sponsorId,
				onSuccess: (res) => {
					const startDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
					const expiryDate = calculateExpiryDate(selectedPlan.days);
					const commission = Math.round(selectedPlan.price * .1);
					const paymentResult = res;
					const newCampaign = {
						id: `camp-${Date.now().toString().slice(-4)}`,
						title: campaignTitle,
						videoUrl: videoPreviewUrl,
						destinationUrl: destinationUrl || "https://facetube.app",
						category,
						planName: selectedPlan.name,
						durationLabel: selectedPlan.durationLabel,
						price: selectedPlan.price,
						referrerCommission: commission,
						startDate,
						expiryDate,
						status: "Active",
						impressions: 120,
						clicks: 8,
						ctr: "6.67%"
					};
					setCampaigns((prev) => [newCampaign, ...prev]);
					setIsActivating(false);
					toast.success(`🎉 Payment Verified! Promotion Activated for ₹${selectedPlan.price}!`, {
						description: `Payment ID: ${paymentResult?.paymentId || "Verified"}. Direct Referrer (${sponsorName} - ${sponsorId}) received ₹${commission} (10%) instant commission. Active until ${expiryDate}.`,
						duration: 7e3
					});
					const statusSection = document.getElementById("active-promotions-section");
					if (statusSection) statusSection.scrollIntoView({ behavior: "smooth" });
				},
				onFailure: (err) => {
					setIsActivating(false);
					toast.error(err || "Payment failed. Promotion was not activated.");
				},
				onCancel: () => {
					setIsActivating(false);
					toast.info("Payment cancelled. Promotion was not activated.");
				}
			});
		} catch (err) {
			setIsActivating(false);
			toast.error("Failed to connect with payment gateway.");
		}
	};
	const handleToggleStatus = (id) => {
		setCampaigns((prev) => prev.map((c) => {
			if (c.id === id) {
				const nextStatus = c.status === "Active" ? "Paused" : "Active";
				toast.info(`Campaign status updated to ${nextStatus}.`);
				return {
					...c,
					status: nextStatus
				};
			}
			return c;
		}));
	};
	const getRemainingDays = (expiryStr) => {
		const expiry = new Date(expiryStr).getTime();
		const now = (/* @__PURE__ */ new Date()).getTime();
		const diff = Math.ceil((expiry - now) / 864e5);
		return diff > 0 ? diff : 0;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-8 max-w-7xl mx-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand border border-brand/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
							children: "📢 Ads Promotions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400",
							children: "Live Network"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-0.5",
						children: "Boost your video advertisements across FaceTube creator streams with transparent pricing"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card px-4 py-2 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-semibold text-muted-foreground uppercase",
							children: "Active Promotions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-lg font-black text-foreground",
							children: [campaigns.filter((c) => c.status === "Active").length, " Running"]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-amber-500/40 bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-transparent p-5 sm:p-6 shadow-md relative overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-64 h-64 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-6 h-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-black text-foreground sm:text-xl",
									children: "🤝 Direct Referrer receives 10% one-time commission"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-amber-400 text-black px-2.5 py-0.5 text-xs font-black uppercase tracking-wider",
									children: "Instant Credit"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-muted-foreground max-w-2xl leading-relaxed",
								children: "Every time any user or creator launches an advertisement plan on FaceTube, their direct sponsor / referrer is instantly rewarded with a 10% cash commission credited to their withdrawal balance."
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 sm:grid-cols-4 gap-2 w-full lg:w-auto shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-amber-500/30 bg-black/40 px-3 py-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground uppercase font-bold",
									children: "7 Days (₹100)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-black text-amber-300",
									children: "₹10 (10%)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-amber-500/30 bg-black/40 px-3 py-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground uppercase font-bold",
									children: "15 Days (₹200)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-black text-amber-300",
									children: "₹20 (10%)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-amber-500/30 bg-black/40 px-3 py-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground uppercase font-bold",
									children: "Monthly (₹300)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-black text-amber-300",
									children: "₹30 (10%)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-amber-500/30 bg-black/40 px-3 py-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground uppercase font-bold",
									children: "Yearly (₹3000)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-black text-amber-300",
									children: "₹300 (10%)"
								})]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 sm:p-7 space-y-6 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-extrabold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlay, { className: "h-5 w-5 text-brand" }), "Advertisement Video Upload"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Upload your creative video ad, title, landing page, and category"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "Step 1 of 3"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground block",
								children: "Video Asset (MP4 / WebM / MOV)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative rounded-2xl border-2 border-dashed border-border hover:border-brand/60 bg-secondary/20 p-6 text-center transition-all group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "video/*",
									onChange: handleVideoFileChange,
									className: "absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10",
									"aria-label": "Upload Advertisement Video"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center justify-center space-y-2 pointer-events-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 rounded-2xl bg-brand/10 text-brand flex items-center justify-center group-hover:scale-110 transition-transform",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "w-6 h-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-foreground",
											children: videoFile ? videoFile.name : "Drag & drop video here, or browse files"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: "Recommended resolution: 1080p · Max size: 150MB · Duration: 15s to 90s"
										})
									]
								})]
							}),
							videoPreviewUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border overflow-hidden bg-black relative shadow-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "aspect-video w-full bg-black",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										src: videoPreviewUrl,
										controls: true,
										className: "w-full h-full object-contain",
										playsInline: true
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 bg-secondary/50 border-t border-border flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: "Ad Preview Ready"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground font-mono text-[11px]",
										children: ["Target: ", destinationUrl || "Default Link"]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground block",
								children: "Campaign Configuration"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-medium text-foreground block mb-1",
								children: "Campaign Title *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: campaignTitle,
								onChange: (e) => setCampaignTitle(e.target.value),
								placeholder: "e.g. 50% Off Smart Cloud Hosting Promo",
								className: "w-full rounded-xl border border-border bg-secondary/40 px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-brand focus:outline-none transition"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-medium text-foreground block mb-1",
								children: "Destination / Landing Page URL *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "url",
									value: destinationUrl,
									onChange: (e) => setDestinationUrl(e.target.value),
									placeholder: "https://yourwebsite.com/offer",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-3.5 pr-9 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-brand focus:outline-none transition"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-4 h-4 text-muted-foreground absolute right-3 top-3 pointer-events-none" })]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-medium text-foreground block mb-1",
									children: "Audience Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: category,
									onChange: (e) => setCategory(e.target.value),
									className: "w-full rounded-xl border border-border bg-secondary/40 px-3.5 py-2.5 text-sm text-foreground focus:border-brand focus:outline-none transition",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Technology & Gadgets",
											children: "Technology & Gadgets"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Software & Apps",
											children: "Software & Apps"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Gaming & Esports",
											children: "Gaming & Esports"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Finance & Crypto",
											children: "Finance & Crypto"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Education & Courses",
											children: "Education & Courses"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Lifestyle & Fashion",
											children: "Lifestyle & Fashion"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Health & Fitness",
											children: "Health & Fitness"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-medium text-foreground block mb-1",
									children: "Button Action (CTA)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: ctaText,
									onChange: (e) => setCtaText(e.target.value),
									className: "w-full rounded-xl border border-border bg-secondary/40 px-3.5 py-2.5 text-sm text-foreground focus:border-brand focus:outline-none transition",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Learn More",
											children: "Learn More"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Shop Now",
											children: "Shop Now"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Sign Up Free",
											children: "Sign Up Free"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Get Offer",
											children: "Get Offer"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Watch Video",
											children: "Watch Video"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Install App",
											children: "Install App"
										})
									]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-secondary/30 p-3.5 flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											"Direct Sponsor: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: sponsorName
											}),
											" (",
											sponsorId,
											")"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-amber-400",
									children: "10% One-Time Commission"
								})]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-extrabold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-5 w-5 text-brand" }), "Select Advertisement Promotion Plan"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Choose the best promotion duration for your marketing campaign"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "Step 2 of 3"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4",
					children: AD_PLANS.map((plan) => {
						const isSelected = plan.id === selectedPlanId;
						const commissionAmount = Math.round(plan.price * .1);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onClick: () => setSelectedPlanId(plan.id),
							className: `relative rounded-2xl border transition-all cursor-pointer flex flex-col justify-between p-5 ${isSelected ? "border-brand bg-brand/5 shadow-lg shadow-brand/10 ring-2 ring-brand/30" : "border-border bg-card hover:border-border/80 hover:bg-secondary/40"}`,
							children: [
								plan.isPopular && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand px-3 py-0.5 text-[10px] font-black uppercase tracking-wider text-white shadow-md flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-3 h-3" }), " Most Popular"]
								}),
								plan.isBestValue && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-amber-400 px-3 py-0.5 text-[10px] font-black uppercase tracking-wider text-black shadow-md flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3 h-3" }), " Best Value (Save ₹600)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2 mb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-extrabold text-foreground",
											children: plan.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground font-semibold",
											children: plan.durationLabel
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${isSelected ? "border-brand bg-brand text-white" : "border-muted-foreground/40 bg-secondary"}`,
											children: isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 stroke-[3]" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "my-3 pb-3 border-b border-border/80",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-3xl font-black tracking-tight text-foreground",
												children: ["₹", plan.price.toLocaleString("en-IN")]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-muted-foreground",
												children: ["/", plan.durationLabel]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[11px] text-muted-foreground mt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: plan.dailyRate }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-emerald-400 font-bold",
												children: plan.impressions
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 rounded-lg bg-amber-400/10 border border-amber-400/20 px-2.5 py-1.5 flex items-center justify-between text-[11px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-amber-400 font-semibold",
											children: "Direct Referrer"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-extrabold text-amber-300",
											children: [
												"₹",
												commissionAmount,
												" (10%)"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-2 text-xs text-zinc-300 mb-5",
										children: plan.features.map((feat, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3.5 h-3.5 text-brand shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: feat })]
										}, idx))
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: (e) => {
										e.stopPropagation();
										setSelectedPlanId(plan.id);
									},
									className: `w-full rounded-xl py-2.5 px-4 text-xs font-extrabold transition-all ${isSelected ? "bg-brand text-white shadow-md hover:bg-brand-dark" : "border border-border bg-secondary text-foreground hover:bg-secondary/80"}`,
									children: isSelected ? "Selected Plan ✓" : "Select Plan"
								})
							]
						}, plan.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 sm:p-7 space-y-6 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-extrabold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-5 w-5 text-emerald-400" }), "Payment Summary & Instant Activation"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Review your promotion package breakdown and complete campaign activation"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "Step 3 of 3"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-7 space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-secondary/20 p-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground font-medium",
										children: "Selected Plan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-foreground",
										children: selectedPlan.name
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground font-medium",
										children: "Duration"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-foreground",
										children: selectedPlan.durationLabel
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground font-medium",
										children: "Plan Base Amount"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-foreground",
										children: ["₹", selectedPlan.price.toLocaleString("en-IN")]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-amber-400 font-medium",
											children: "Direct Referrer 10% Commission"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] bg-amber-400/20 text-amber-300 px-1.5 py-0.2 rounded font-bold",
											children: "Credited"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-amber-400",
										children: ["₹", Math.round(selectedPlan.price * .1).toLocaleString("en-IN")]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground font-medium",
										children: "Network Listing & GST"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-emerald-400",
										children: "₹0 (Included / Free)"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-base pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-foreground",
										children: "Total Payable Amount"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-2xl font-black text-brand",
										children: ["₹", selectedPlan.price.toLocaleString("en-IN")]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-2",
							children: "Select Payment Method"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPaymentMethod("wallet"),
									className: `rounded-xl border p-3 text-left transition-all ${paymentMethod === "wallet" ? "border-brand bg-brand/10 text-foreground ring-1 ring-brand" : "border-border bg-secondary/30 text-muted-foreground hover:bg-secondary"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-foreground",
										children: "FaceTube Wallet"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-emerald-400 font-semibold mt-0.5",
										children: "Bal: ₹5,240.00"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPaymentMethod("upi"),
									className: `rounded-xl border p-3 text-left transition-all ${paymentMethod === "upi" ? "border-brand bg-brand/10 text-foreground ring-1 ring-brand" : "border-border bg-secondary/30 text-muted-foreground hover:bg-secondary"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-foreground",
										children: "UPI QR / Apps"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-muted-foreground mt-0.5",
										children: "GPay / PhonePe / Paytm"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPaymentMethod("card"),
									className: `rounded-xl border p-3 text-left transition-all ${paymentMethod === "card" ? "border-brand bg-brand/10 text-foreground ring-1 ring-brand" : "border-border bg-secondary/30 text-muted-foreground hover:bg-secondary"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-foreground",
										children: "Cards / NetBanking"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-muted-foreground mt-0.5",
										children: "Instant Gateway"
									})]
								})
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-5 flex flex-col justify-between space-y-4 rounded-xl border border-border bg-secondary/15 p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-foreground font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-400" }), "Promotion Launch Guarantee"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground leading-relaxed",
									children: "Your advertisement video will enter the FaceTube high-priority rotation immediately. Estimated delivery commences within 5 minutes of activation."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-black/40 border border-border p-3 text-xs space-y-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-zinc-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Campaign Name:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-white truncate max-w-[170px]",
												children: campaignTitle
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-zinc-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Target Expiry:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-emerald-400",
												children: calculateExpiryDate(selectedPlan.days)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-zinc-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Direct Sponsor Credit:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-semibold text-amber-300",
												children: [
													"₹",
													Math.round(selectedPlan.price * .1),
													" (10%)"
												]
											})]
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							id: "btn-activate-promotion",
							onClick: handleActivatePromotion,
							disabled: isActivating,
							className: "w-full rounded-xl bg-brand py-3.5 px-6 text-sm font-extrabold text-white shadow-lg shadow-brand/25 transition hover:bg-brand-dark active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2",
							children: isActivating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Activating Campaign & Crediting Referrer..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Activate Promotion Now (₹",
								selectedPlan.price,
								")"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })] })
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "active-promotions-section",
				className: "rounded-2xl border border-border bg-card p-5 sm:p-7 space-y-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-extrabold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5 text-brand" }), "Active Promotion Status & Expiry Dates"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Real-time performance tracking, impression counters, and expiry schedules"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20",
						children: [campaigns.length, " Total Campaigns"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-secondary/60 text-muted-foreground font-bold uppercase tracking-wider border-b border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Campaign Title"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Plan & Price"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Active Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Start Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Expiry Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Performance"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Referrer (10%)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: campaigns.map((camp) => {
								const remainingDays = getRemainingDays(camp.expiryDate);
								const isExpired = remainingDays === 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-secondary/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-3.5 px-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-foreground max-w-[220px] truncate",
												children: camp.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-muted-foreground flex items-center gap-1.5 mt-0.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded bg-secondary px-1.5 py-0.5 font-medium",
													children: camp.category
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono text-zinc-500",
													children: ["ID: ", camp.id]
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-3.5 px-4 font-semibold text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: camp.planName }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-brand font-bold",
												children: ["₹", camp.price]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${camp.status === "Active" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : camp.status === "Paused" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" : "bg-zinc-500/10 text-zinc-400 border border-zinc-500/20"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-1.5 h-1.5 rounded-full ${camp.status === "Active" ? "bg-emerald-400 animate-pulse" : "bg-zinc-400"}` }), camp.status]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4 text-muted-foreground font-medium",
											children: camp.startDate
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-3.5 px-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-foreground",
												children: camp.expiryDate
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `text-[10px] font-semibold flex items-center gap-1 mt-0.5 ${isExpired ? "text-rose-400" : "text-amber-400"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3 h-3" }), isExpired ? "Expired" : `${remainingDays} days remaining`]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1 text-foreground font-semibold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5 text-muted-foreground" }), camp.impressions.toLocaleString()]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "·"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1 text-emerald-400 font-semibold",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MousePointerClick, { className: "w-3.5 h-3.5" }),
															camp.clicks,
															" (",
															camp.ctr,
															")"
														]
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded bg-amber-400/10 border border-amber-400/20 px-2 py-0.5 text-[11px] font-bold text-amber-300",
												children: [
													"₹",
													camp.referrerCommission,
													" Paid"
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-end gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleToggleStatus(camp.id),
													className: "rounded-lg border border-border bg-secondary/80 p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary transition",
													title: camp.status === "Active" ? "Pause Campaign" : "Resume Campaign",
													children: camp.status === "Active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-3.5 h-3.5" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: camp.destinationUrl,
													target: "_blank",
													rel: "noopener noreferrer",
													className: "rounded-lg border border-border bg-secondary/80 p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary transition",
													title: "Visit Destination",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5" })
												})]
											})
										})
									]
								}, camp.id);
							})
						})]
					})
				})]
			})
		]
	}) });
}
//#endregion
export { AdsPromotionsPage as component };
