import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Kt as CircleCheck, L as Plus, et as Megaphone, o as Video, t as Zap } from "../_libs/lucide-react.mjs";
import { s as VideoHubLayout, v as calculateUserVideoCounts, y as fetchUploadedVideos } from "./router-vsnEDfJA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/your-videos-CdG4l1hj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function YourVideosPage() {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const channelName = profile?.name || dbUser?.name || "Creator";
	const [videos, setVideos] = (0, import_react.useState)([]);
	const [videoFilter, setVideoFilter] = (0, import_react.useState)("all");
	const [counts, setCounts] = (0, import_react.useState)({
		freeShort: 0,
		freeLong: 0,
		premiumShort: 0,
		premiumLong: 0,
		totalFree: 0,
		totalPremium: 0,
		totalUploaded: 0
	});
	(0, import_react.useEffect)(() => {
		fetchUploadedVideos(userId).then((list) => {
			setVideos(list);
		});
		calculateUserVideoCounts(userId).then((c) => {
			setCounts(c);
		});
	}, [userId]);
	const filteredVideos = videos.filter((v) => {
		if (videoFilter === "free_short") return v.videoType === "free" && v.contentType === "short";
		if (videoFilter === "free_long") return v.videoType === "free" && v.contentType === "long";
		if (videoFilter === "premium_short") return v.videoType === "premium" && v.contentType === "short";
		if (videoFilter === "premium_long") return v.videoType === "premium" && v.contentType === "long";
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Your Videos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Channel content hub, metadata records, and upload table for ",
							channelName,
							" (",
							userId,
							")"
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/upload",
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand px-5 py-2.5 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Upload New Video"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVideoFilter(videoFilter === "free_short" ? "all" : "free_short"),
						className: `rounded-2xl border p-4 text-left transition ${videoFilter === "free_short" ? "border-sky-500 bg-sky-500/15 ring-1 ring-sky-500/50" : "border-border bg-card hover:border-sky-500/40"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-sky-400",
								children: "FREE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-2xl font-black text-foreground mt-0.5",
								children: counts.freeShort
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-sky-300",
								children: "1. Free Short Video"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVideoFilter(videoFilter === "free_long" ? "all" : "free_long"),
						className: `rounded-2xl border p-4 text-left transition ${videoFilter === "free_long" ? "border-sky-500 bg-sky-500/15 ring-1 ring-sky-500/50" : "border-border bg-card hover:border-sky-500/40"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-sky-400",
								children: "FREE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-2xl font-black text-foreground mt-0.5",
								children: counts.freeLong
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-sky-300",
								children: "2. Free Long Video"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVideoFilter(videoFilter === "premium_short" ? "all" : "premium_short"),
						className: `rounded-2xl border p-4 text-left transition ${videoFilter === "premium_short" ? "border-amber-400 bg-amber-400/15 ring-1 ring-amber-400/50" : "border-border bg-card hover:border-amber-400/40"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-amber-400",
								children: "PREMIUM (₹6)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-2xl font-black text-foreground mt-0.5",
								children: counts.premiumShort
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-amber-300",
								children: "3. Premium Short Video"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVideoFilter(videoFilter === "premium_long" ? "all" : "premium_long"),
						className: `rounded-2xl border p-4 text-left transition ${videoFilter === "premium_long" ? "border-amber-400 bg-amber-400/15 ring-1 ring-amber-400/50" : "border-border bg-card hover:border-amber-400/40"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-amber-400",
								children: "PREMIUM (₹6)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-2xl font-black text-foreground mt-0.5",
								children: counts.premiumLong
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-amber-300",
								children: "4. Premium Long Video"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card overflow-hidden shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-bold text-foreground",
						children: [
							"Channel Uploads Ledger (",
							filteredVideos.length,
							" Videos)"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Verified database records with video type, content format, and payment verification status."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setVideoFilter("all"),
								className: `rounded-full px-3 py-1 text-xs font-bold transition ${videoFilter === "all" ? "bg-brand text-white" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
								children: "All Videos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setVideoFilter("free_short"),
								className: `rounded-full px-3 py-1 text-xs font-bold transition ${videoFilter === "free_short" ? "bg-sky-500 text-white" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
								children: "Free Short"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setVideoFilter("free_long"),
								className: `rounded-full px-3 py-1 text-xs font-bold transition ${videoFilter === "free_long" ? "bg-sky-500 text-white" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
								children: "Free Long"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setVideoFilter("premium_short"),
								className: `rounded-full px-3 py-1 text-xs font-bold transition ${videoFilter === "premium_short" ? "bg-amber-500 text-black" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
								children: "Premium Short"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setVideoFilter("premium_long"),
								className: `rounded-full px-3 py-1 text-xs font-bold transition ${videoFilter === "premium_long" ? "bg-amber-500 text-black" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
								children: "Premium Long"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-secondary/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Video Title & ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "User ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Classification"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Content Format"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Upload Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Payment Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 whitespace-nowrap",
									children: "Promotion"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right whitespace-nowrap",
									children: "Views"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border font-medium",
							children: filteredVideos.map((vid) => {
								const isPremium = vid.videoType === "premium";
								const isShort = vid.contentType === "short";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "transition hover:bg-secondary/20",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: vid.thumbnailUrl,
													alt: vid.title,
													className: "h-10 w-16 rounded-lg object-cover shrink-0"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 max-w-xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-bold text-foreground truncate",
														children: vid.title
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-[10px] font-mono text-muted-foreground",
														children: vid.id
													})]
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 font-mono text-xs font-bold text-rose-400 whitespace-nowrap",
											children: vid.userId
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 whitespace-nowrap",
											children: isPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-full border border-amber-400/50 bg-amber-400/15 px-2.5 py-0.5 text-[10px] font-black text-amber-300 shadow-[0_0_10px_rgba(251,191,36,0.2)]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3 w-3 fill-amber-400 text-amber-300" }), "Premium Video"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-full border border-sky-500/30 bg-sky-500/10 px-2.5 py-0.5 text-[10px] font-bold text-sky-400",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-3 w-3" }), "Free Video"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 whitespace-nowrap",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-md px-2 py-0.5 text-[10px] font-bold ${isShort ? "bg-rose-500/15 text-rose-400 border border-rose-500/30" : "bg-blue-500/15 text-blue-400 border border-blue-500/30"}`,
												children: isShort ? "Short Video (9:16)" : "Long Video (16:9)"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-muted-foreground whitespace-nowrap",
											children: new Date(vid.createdAt).toLocaleDateString()
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 whitespace-nowrap",
											children: isPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }), "Paid (₹6)"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground text-[11px]",
												children: "Not Required (₹0)"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 whitespace-nowrap",
											children: vid.isPromoted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "h-3 w-3" }), "Promoted"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground text-[11px]",
												children: "—"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-right font-mono text-xs font-bold text-foreground whitespace-nowrap",
											children: vid.views.toLocaleString()
										})
									]
								}, vid.id);
							})
						})]
					})
				})]
			})
		]
	}) });
}
//#endregion
export { YourVideosPage as component };
