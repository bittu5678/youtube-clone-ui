import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, l as useAuth, r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as PenLine, C as ShieldCheck, D as Send, E as Settings, Ft as DollarSign, Ht as Clock, Kt as CircleCheck, Lt as CreditCard, P as QrCode, Pt as Download, Qt as Check, St as GitBranch, T as Share2, W as Navigation, Z as MessageCircle, c as User, d as Upload, dt as Landmark, en as Camera, f as Twitter, g as ThumbsUp, gt as History, h as Trash2, it as LogOut, j as Save, kt as Eye, lt as Layers, m as TrendingUp, n as X, nn as Building, nt as MapPin, ot as LoaderCircle, rn as Building2, rt as Mail, s as Users, sn as Award, st as Link2, tn as Calendar, vt as HeartHandshake, y as Sparkles, yt as Hash, z as Phone, zt as Copy } from "../_libs/lucide-react.mjs";
import { t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as recent } from "./router-vsnEDfJA.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
import { t as SHORTS_LIST } from "./shorts-DrPnqhcl.mjs";
import { i as savePersonalKyc, n as getPersonalKyc, r as saveBankKyc, t as getBankKyc } from "./kyc-service-oYEql6hM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-neAE0xEm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function PersonalKycTab({ userId, defaultFullName, defaultMobile }) {
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [kycData, setKycData] = (0, import_react.useState)(null);
	const [formData, setFormData] = (0, import_react.useState)({
		fullName: defaultFullName || "",
		mobile: defaultMobile || "",
		dob: "",
		address: "",
		city: "",
		state: "",
		pincode: "",
		nomineeName: "",
		nomineeRelation: "Spouse",
		nomineeMobile: ""
	});
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		async function loadData() {
			setLoading(true);
			try {
				const data = await getPersonalKyc(userId, {
					fullName: defaultFullName,
					mobile: defaultMobile
				});
				if (isMounted) {
					setKycData(data);
					setFormData({
						fullName: data.fullName || defaultFullName || "",
						mobile: data.mobile || defaultMobile || "",
						dob: data.dob || "",
						address: data.address || "",
						city: data.city || "",
						state: data.state || "",
						pincode: data.pincode || "",
						nomineeName: data.nomineeName || "",
						nomineeRelation: data.nomineeRelation || "Spouse",
						nomineeMobile: data.nomineeMobile || ""
					});
				}
			} catch (err) {
				console.error("Failed loading Personal KYC:", err);
			} finally {
				if (isMounted) setLoading(false);
			}
		}
		loadData();
		return () => {
			isMounted = false;
		};
	}, [
		userId,
		defaultFullName,
		defaultMobile
	]);
	const handleChange = (e) => {
		const { name, value } = e.target;
		setFormData((prev) => ({
			...prev,
			[name]: value
		}));
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!formData.fullName.trim()) {
			toast.error("Please enter your full name.");
			return;
		}
		if (!formData.mobile.trim()) {
			toast.error("Please enter your mobile number.");
			return;
		}
		setSaving(true);
		try {
			const res = await savePersonalKyc(userId, formData);
			if (res.success) {
				setKycData(res.data);
				toast.success("Personal KYC details saved successfully in database!");
			} else toast.error(res.error || "Failed to save Personal KYC.");
		} catch (err) {
			toast.error("An error occurred while saving KYC.");
			console.error(err);
		} finally {
			setSaving(false);
		}
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-center p-12 text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-brand mr-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium",
			children: "Loading Personal KYC record..."
		})]
	});
	const isVerified = kycData?.status === "Verified";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-border bg-card p-5 sm:p-7 shadow-sm transition",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-8 w-8 place-items-center rounded-xl bg-brand/10 text-brand",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-foreground",
					children: "Personal KYC Verification"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mt-1",
				children: "Complete your personal identity profile and nominee details for seamless withdrawals and compliance."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${isVerified ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-amber-500/10 text-amber-400 border border-amber-500/20"}`,
					children: [isVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5" }), kycData?.status || "Pending Verification"]
				}), kycData?.updatedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted-foreground hidden md:inline",
					children: ["Last saved: ", new Date(kycData.updatedAt).toLocaleDateString()]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			className: "mt-6 space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-3.5 w-3.5 text-brand" }), "1. Applicant Identity"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["Full Name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "fullName",
									value: formData.fullName,
									onChange: handleChange,
									placeholder: "e.g. Alex Rivera",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["Mobile Number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "tel",
									name: "mobile",
									value: formData.mobile,
									onChange: handleChange,
									placeholder: "e.g. +1 555-014-8392",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Date of Birth"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									name: "dob",
									value: formData.dob,
									onChange: handleChange,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "City"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "city",
									value: formData.city,
									onChange: handleChange,
									placeholder: "e.g. San Francisco",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "State"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "state",
									value: formData.state,
									onChange: handleChange,
									placeholder: "e.g. California",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "PIN Code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "pincode",
									value: formData.pincode,
									onChange: handleChange,
									placeholder: "e.g. 94107",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-semibold text-foreground mb-1.5",
							children: "Full Address"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-3.5 top-3 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								name: "address",
								rows: 2,
								value: formData.address,
								onChange: handleChange,
								placeholder: "Apartment, Street address, Landmark...",
								className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
							})]
						})]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-4 border-t border-border/70",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5 text-purple-400" }), "2. Nominee Information"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Nominee Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "nomineeName",
									value: formData.nomineeName,
									onChange: handleChange,
									placeholder: "e.g. Elena Rivera",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Nominee Relation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "nomineeRelation",
									value: formData.nomineeRelation,
									onChange: handleChange,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground outline-none transition focus:border-brand focus:ring-1 focus:ring-brand",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Spouse",
											children: "Spouse"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Father",
											children: "Father"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Mother",
											children: "Mother"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Brother",
											children: "Brother"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Sister",
											children: "Sister"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Son",
											children: "Son"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Daughter",
											children: "Daughter"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Other",
											children: "Other"
										})
									]
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Nominee Mobile Number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "tel",
									name: "nomineeMobile",
									value: formData.nomineeMobile,
									onChange: handleChange,
									placeholder: "e.g. +1 555-014-9921",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-4 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "🔒 All personal information is encrypted and stored securely according to compliance standards."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: saving,
						className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-brand px-6 py-2.5 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95 disabled:opacity-50",
						children: saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), "Saving KYC..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4" }), "Save KYC"] })
					})]
				})
			]
		})]
	});
}
function BankKycTab({ userId, defaultFullName }) {
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [kycData, setKycData] = (0, import_react.useState)(null);
	const [formData, setFormData] = (0, import_react.useState)({
		accountHolderName: defaultFullName || "",
		bankName: "",
		accountNumber: "",
		ifscCode: "",
		branchName: "",
		accountType: "Saving",
		upiId: "",
		upiQrCodeUrl: ""
	});
	const [scannerOpen, setScannerOpen] = (0, import_react.useState)(false);
	const [cameraActive, setCameraActive] = (0, import_react.useState)(false);
	const videoRef = (0, import_react.useRef)(null);
	const mediaStreamRef = (0, import_react.useRef)(null);
	const fileInputRef = (0, import_react.useRef)(null);
	const scannerFileInputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		async function loadData() {
			setLoading(true);
			try {
				const data = await getBankKyc(userId, { fullName: defaultFullName });
				if (isMounted) {
					setKycData(data);
					setFormData({
						accountHolderName: data.accountHolderName || defaultFullName || "",
						bankName: data.bankName || "",
						accountNumber: data.accountNumber || "",
						ifscCode: data.ifscCode || "",
						branchName: data.branchName || "",
						accountType: data.accountType || "Saving",
						upiId: data.upiId || "",
						upiQrCodeUrl: data.upiQrCodeUrl || ""
					});
				}
			} catch (err) {
				console.error("Failed loading Bank KYC:", err);
			} finally {
				if (isMounted) setLoading(false);
			}
		}
		loadData();
		return () => {
			isMounted = false;
			stopCamera();
		};
	}, [userId, defaultFullName]);
	const handleFileUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			toast.error("Please upload an image file (PNG, JPG, or WebP).");
			return;
		}
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			setFormData((prev) => ({
				...prev,
				upiQrCodeUrl: result
			}));
			toast.success("UPI QR Code uploaded successfully!");
		};
		reader.readAsDataURL(file);
	};
	const handleRemoveQr = () => {
		setFormData((prev) => ({
			...prev,
			upiQrCodeUrl: ""
		}));
		if (fileInputRef.current) fileInputRef.current.value = "";
		toast.info("UPI QR Code removed.");
	};
	const startCamera = async () => {
		setCameraActive(true);
		try {
			if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
				const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
				mediaStreamRef.current = stream;
				if (videoRef.current) {
					videoRef.current.srcObject = stream;
					videoRef.current.play();
				}
			} else toast.info("Camera device not accessible in current iframe. You can scan via file upload!");
		} catch (err) {
			console.warn("Camera access denied or unavailable:", err);
			toast.info("Camera preview unavailable. Please select or drop a QR code image to scan!");
		}
	};
	const stopCamera = () => {
		if (mediaStreamRef.current) {
			mediaStreamRef.current.getTracks().forEach((track) => track.stop());
			mediaStreamRef.current = null;
		}
		setCameraActive(false);
	};
	const openScanner = () => {
		setScannerOpen(true);
		startCamera();
	};
	const closeScanner = () => {
		stopCamera();
		setScannerOpen(false);
	};
	const handleSimulatedScan = (detectedUpi) => {
		setFormData((prev) => ({
			...prev,
			upiId: detectedUpi
		}));
		toast.success(`QR Code Scanned! UPI ID set to: ${detectedUpi}`);
		closeScanner();
	};
	const handleScannerFileSelect = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (ev) => {
			const dataUrl = ev.target?.result;
			setFormData((prev) => ({
				...prev,
				upiQrCodeUrl: dataUrl,
				upiId: prev.upiId || `${userId.toLowerCase()}@facetube`
			}));
			toast.success("QR Code recognized from image!");
			closeScanner();
		};
		reader.readAsDataURL(file);
	};
	const handleChange = (e) => {
		const { name, value } = e.target;
		if (name === "ifscCode") setFormData((prev) => ({
			...prev,
			[name]: value.toUpperCase()
		}));
		else setFormData((prev) => ({
			...prev,
			[name]: value
		}));
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!formData.accountHolderName.trim()) {
			toast.error("Please enter the Account Holder Name.");
			return;
		}
		if (!formData.bankName.trim()) {
			toast.error("Please enter the Bank Name.");
			return;
		}
		if (!formData.accountNumber.trim()) {
			toast.error("Please enter the Account Number.");
			return;
		}
		if (!formData.ifscCode.trim()) {
			toast.error("Please enter the IFSC Code.");
			return;
		}
		setSaving(true);
		try {
			const res = await saveBankKyc(userId, formData);
			if (res.success) {
				setKycData(res.data);
				toast.success("Bank KYC details saved successfully in database!");
			} else toast.error(res.error || "Failed to save Bank KYC.");
		} catch (err) {
			toast.error("An error occurred while saving Bank details.");
			console.error(err);
		} finally {
			setSaving(false);
		}
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-center p-12 text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-brand mr-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium",
			children: "Loading Bank KYC record..."
		})]
	});
	const isVerified = kycData?.status === "Verified";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-border bg-card p-5 sm:p-7 shadow-sm transition",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-8 w-8 place-items-center rounded-xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold text-foreground",
						children: "Bank KYC & Payout Details"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "Provide your bank account and UPI details to receive creator royalties, direct referral commissions, and team income."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${isVerified ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-amber-500/10 text-amber-400 border border-amber-500/20"}`,
						children: [isVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5" }), kycData?.status || "Pending Verification"]
					}), kycData?.updatedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[11px] text-muted-foreground hidden md:inline",
						children: ["Last saved: ", new Date(kycData.updatedAt).toLocaleDateString()]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "mt-6 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-3.5 w-3.5 text-brand" }), "1. Bank Account Details"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["Account Holder Name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "accountHolderName",
									value: formData.accountHolderName,
									onChange: handleChange,
									placeholder: "As per bank passbook",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["Bank Name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "bankName",
									value: formData.bankName,
									onChange: handleChange,
									placeholder: "e.g. Chase Bank / HDFC Bank",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["Account Number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "accountNumber",
									value: formData.accountNumber,
									onChange: handleChange,
									placeholder: "e.g. 849201948201",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: ["IFSC Code ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "ifscCode",
									value: formData.ifscCode,
									onChange: handleChange,
									placeholder: "e.g. CHAS0002914",
									required: true,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 uppercase outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Branch Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									name: "branchName",
									value: formData.branchName,
									onChange: handleChange,
									placeholder: "e.g. Downtown Financial Center",
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold text-foreground mb-1.5",
								children: "Account Type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "accountType",
									value: formData.accountType,
									onChange: handleChange,
									className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground outline-none transition focus:border-brand focus:ring-1 focus:ring-brand",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Saving",
										children: "Saving Account"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Current",
										children: "Current Account"
									})]
								})]
							})] })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 border-t border-border/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "h-3.5 w-3.5 text-emerald-400" }), "2. UPI & QR Code Settings"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold text-foreground mb-1.5",
									children: "UPI ID (Virtual Payment Address)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										name: "upiId",
										value: formData.upiId,
										onChange: handleChange,
										placeholder: "e.g. username@okaxis or mobile@upi",
										className: "w-full rounded-xl border border-border bg-secondary/40 pl-10 pr-3.5 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-brand focus:ring-1 focus:ring-brand"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[10px] text-muted-foreground",
									children: "Enter your Google Pay, PhonePe, Paytm, or BHIM UPI ID for direct bank deposits."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: openScanner,
										className: "inline-flex items-center gap-2 rounded-xl border border-border bg-secondary/60 px-3.5 py-2 text-xs font-semibold text-foreground transition hover:border-brand hover:text-brand",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-3.5 w-3.5 text-brand" }), "Open QR Scanner / Camera"]
									})
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold text-foreground mb-1.5",
									children: "Upload UPI QR Code"
								}),
								formData.upiQrCodeUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative rounded-2xl border border-border bg-secondary/30 p-3 flex items-center gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-20 w-20 rounded-xl overflow-hidden bg-white p-1 border border-border shrink-0 flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: formData.upiQrCodeUrl,
											alt: "Uploaded UPI QR Code",
											className: "h-full w-full object-contain"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-foreground truncate",
												children: "UPI QR Code Attached"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground mt-0.5",
												children: "Ready to process instant QR payments"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => fileInputRef.current?.click(),
														className: "text-[11px] font-semibold text-brand hover:underline",
														children: "Change Image"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground/50",
														children: "·"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: handleRemoveQr,
														className: "inline-flex items-center gap-1 text-[11px] font-semibold text-destructive hover:underline",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3 w-3" }), "Remove"]
													})
												]
											})
										]
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: () => fileInputRef.current?.click(),
									className: "group flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-border hover:border-brand/60 bg-secondary/20 p-5 text-center cursor-pointer transition",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-10 w-10 rounded-full bg-brand/10 text-brand flex items-center justify-center mb-2 group-hover:scale-110 transition",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Click or drag & drop UPI QR Code"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-muted-foreground mt-0.5",
											children: "Supports PNG, JPG, or WebP (Max 5MB)"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileInputRef,
									type: "file",
									accept: "image/*",
									onChange: handleFileUpload,
									className: "hidden"
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "🔒 Bank account details are stored using end-to-end encryption for payout transfers."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: saving,
							className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-brand px-6 py-2.5 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95 disabled:opacity-50",
							children: saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), "Saving Bank Details..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4" }), "Save Bank Details"] })
						})]
					})
				]
			}),
			scannerOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-in fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-5 w-5 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-bold text-foreground",
									children: "QR Scanner & Detector"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: closeScanner,
								className: "rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-square w-full rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-border",
									children: [cameraActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										ref: videoRef,
										autoPlay: true,
										playsInline: true,
										muted: true,
										className: "h-full w-full object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-6 text-center text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "h-16 w-16 mx-auto mb-2 opacity-40 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold",
											children: "Camera standby"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-8 border-2 border-brand/80 rounded-2xl pointer-events-none flex flex-col justify-between p-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 border-t-2 border-l-2 border-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 border-t-2 border-r-2 border-brand" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-0.5 bg-brand shadow-[0_0_8px_rgba(255,0,0,0.8)] animate-pulse" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 border-b-2 border-l-2 border-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 border-b-2 border-r-2 border-brand" })]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-center text-[11px] text-muted-foreground",
									children: "Position your UPI QR code inside the viewfinder to scan."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => scannerFileInputRef.current?.click(),
											className: "w-full flex items-center justify-center gap-2 rounded-xl border border-border bg-secondary/60 py-2.5 text-xs font-semibold text-foreground hover:bg-secondary transition",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4 text-brand" }), "Scan from Image / Gallery File"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											ref: scannerFileInputRef,
											type: "file",
											accept: "image/*",
											onChange: handleScannerFileSelect,
											className: "hidden"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleSimulatedScan(`${userId.toLowerCase()}@okhdfcbank`),
											className: "w-full flex items-center justify-center gap-1.5 rounded-xl bg-brand/10 py-2 text-xs font-semibold text-brand hover:bg-brand/20 transition",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }),
												"Autofill UPI from Verified Profile (",
												userId.toLowerCase(),
												"@okhdfcbank)"
											]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 pt-3 border-t border-border flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: closeScanner,
								className: "rounded-xl px-4 py-2 text-xs font-semibold text-muted-foreground hover:text-foreground",
								children: "Close"
							})
						})
					]
				})
			})
		]
	});
}
function ReferralLinkTab({ userId, userName }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [qrDataUrl, setQrDataUrl] = (0, import_react.useState)("");
	const [generatingQr, setGeneratingQr] = (0, import_react.useState)(true);
	const [shareModalOpen, setShareModalOpen] = (0, import_react.useState)(false);
	const referralLink = `${typeof window !== "undefined" ? window.location.origin : "https://facetube.app"}/auth?ref=${encodeURIComponent(userId)}`;
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		async function createQr() {
			try {
				setGeneratingQr(true);
				const url = await import_lib.toDataURL(referralLink, {
					width: 400,
					margin: 2,
					color: {
						dark: "#000000",
						light: "#ffffff"
					},
					errorCorrectionLevel: "H"
				});
				if (isMounted) setQrDataUrl(url);
			} catch (err) {
				console.error("Failed to generate QR code:", err);
			} finally {
				if (isMounted) setGeneratingQr(false);
			}
		}
		createQr();
		return () => {
			isMounted = false;
		};
	}, [referralLink]);
	const handleCopyLink = async () => {
		try {
			if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(referralLink);
			else {
				const el = document.createElement("textarea");
				el.value = referralLink;
				document.body.appendChild(el);
				el.select();
				document.execCommand("copy");
				document.body.removeChild(el);
			}
			setCopied(true);
			toast.success("Referral link copied to clipboard!");
			setTimeout(() => setCopied(false), 2500);
		} catch {
			toast.error("Failed to copy link. Please copy manually.");
		}
	};
	const handleShare = async () => {
		const shareData = {
			title: "Join FaceTube",
			text: `Join FaceTube with my referral code ${userId} and unlock premium video earnings & monetization!`,
			url: referralLink
		};
		if (navigator.share && navigator.canShare && navigator.canShare(shareData)) try {
			await navigator.share(shareData);
			toast.success("Shared successfully!");
			return;
		} catch (e) {
			if (e.name !== "AbortError") setShareModalOpen(true);
			return;
		}
		setShareModalOpen(true);
	};
	const handleDownloadQr = () => {
		if (!qrDataUrl) {
			toast.error("QR Code is not ready yet.");
			return;
		}
		try {
			const link = document.createElement("a");
			link.href = qrDataUrl;
			link.download = `facetube-referral-qr-${userId}.png`;
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			toast.success("Referral QR Code downloaded!");
		} catch {
			toast.error("Could not download QR code.");
		}
	};
	const shareText = encodeURIComponent(`Join FaceTube with my referral code ${userId} and earn passive income watching & publishing videos: ${referralLink}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-border bg-card p-5 sm:p-7 shadow-sm transition",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-8 w-8 place-items-center rounded-xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold text-foreground",
						children: "Your Referral Link & QR Code"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "Invite creators and members to FaceTube using your personal referral link. Earn direct referral bonus and monthly volume commissions."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full bg-brand/10 border border-brand/20 px-3 py-1 text-xs font-bold text-brand",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-3.5 w-3.5" }),
							"Active User ID: ",
							userId
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-secondary/30 p-4 sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 text-brand" }), "Your Referral Link"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold text-emerald-400",
										children: "Auto-Generated"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											readOnly: true,
											value: referralLink,
											className: "w-full rounded-xl border border-border bg-card pl-10 pr-3.5 py-2.5 text-xs text-foreground font-mono outline-none select-all"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: handleCopyLink,
											className: "flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-xl bg-brand px-4 py-2.5 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
											children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-white" }), "Copied!"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), "Copy Link"] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleShare,
											className: "flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-xl border border-border bg-secondary/70 px-4 py-2.5 text-xs font-bold text-foreground transition hover:bg-secondary active:scale-95",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4 text-brand" }), "Share"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2.5 text-[11px] text-muted-foreground",
									children: [
										"Anyone who clicks this link will automatically have your User ID (",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: userId
										}),
										") prefilled as their sponsor upon registration."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-secondary/20 p-4 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xs font-bold text-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-brand" }), "Referral Program Benefits"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-2 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-brand mt-1.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: "Direct Commission:"
										}), " Receive ₹500 instant bonus credited for every verified creator or member joining through your link."] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-brand mt-1.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: "Monthly Team Volume:"
										}), " Earn recurring team turnover percentage up to 10 tier levels."] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-brand mt-1.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: "Instant Wallet Settlements:"
											}),
											" Track referrals in real-time on your",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-brand font-medium",
												children: "Referral Members"
											}),
											" &",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-brand font-medium",
												children: "Team Members"
											}),
											" tables."
										] })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-foreground mb-2",
							children: "Quick Share Channels"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `https://wa.me/?text=${shareText}`,
									target: "_blank",
									rel: "noreferrer",
									className: "flex items-center justify-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 py-2 px-3 text-xs font-semibold text-emerald-400 hover:bg-emerald-500/20 transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-3.5 w-3.5" }), "WhatsApp"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(`Join FaceTube with sponsor code ${userId}`)}`,
									target: "_blank",
									rel: "noreferrer",
									className: "flex items-center justify-center gap-1.5 rounded-xl border border-sky-500/30 bg-sky-500/10 py-2 px-3 text-xs font-semibold text-sky-400 hover:bg-sky-500/20 transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3.5 w-3.5" }), "Telegram"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `https://twitter.com/intent/tweet?text=${shareText}`,
									target: "_blank",
									rel: "noreferrer",
									className: "flex items-center justify-center gap-1.5 rounded-xl border border-blue-500/30 bg-blue-500/10 py-2 px-3 text-xs font-semibold text-blue-400 hover:bg-blue-500/20 transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Twitter, { className: "h-3.5 w-3.5" }), "Twitter (X)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `mailto:?subject=${encodeURIComponent("Join me on FaceTube")}&body=${shareText}`,
									className: "flex items-center justify-center gap-1.5 rounded-xl border border-border bg-secondary/50 py-2 px-3 text-xs font-semibold text-foreground hover:bg-secondary transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5" }), "Email"]
								})
							]
						})] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-5 flex flex-col items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-xs rounded-2xl border border-border bg-secondary/40 p-6 flex flex-col items-center text-center shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-foreground",
									children: "Referral QR Code"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative p-3 bg-white rounded-2xl shadow-inner border border-border/40",
								children: generatingQr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-48 w-48 flex items-center justify-center text-black/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium animate-pulse",
										children: "Generating QR..."
									})
								}) : qrDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: qrDataUrl,
									alt: `Referral QR Code for ${userId}`,
									className: "h-48 w-48 object-contain rounded-lg"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-48 w-48 flex items-center justify-center text-destructive text-xs",
									children: "Failed to load QR"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-foreground",
									children: userName ? `${userName}'s QR` : "FaceTube Referral QR"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] font-mono text-muted-foreground mt-0.5",
									children: ["Code: ", userId]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: handleDownloadQr,
								disabled: generatingQr || !qrDataUrl,
								className: "mt-4 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-secondary hover:bg-secondary/80 border border-border py-2.5 px-4 text-xs font-bold text-foreground transition active:scale-95 disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4 text-brand" }), "Download QR"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2.5 text-[10px] text-muted-foreground",
								children: "Scan with any camera or QR app to open registration directly."
							})
						]
					})
				})]
			}),
			shareModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-bold text-foreground",
								children: "Share Referral Link"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShareModalOpen(false),
							className: "rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://wa.me/?text=${shareText}`,
								target: "_blank",
								rel: "noreferrer",
								className: "flex items-center gap-3 w-full rounded-xl border border-border bg-secondary/50 p-3 text-xs font-semibold text-foreground hover:bg-secondary transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Share via WhatsApp" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(`Join FaceTube with sponsor code ${userId}`)}`,
								target: "_blank",
								rel: "noreferrer",
								className: "flex items-center gap-3 w-full rounded-xl border border-border bg-secondary/50 p-3 text-xs font-semibold text-foreground hover:bg-secondary transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-8 w-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Share via Telegram" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://twitter.com/intent/tweet?text=${shareText}`,
								target: "_blank",
								rel: "noreferrer",
								className: "flex items-center gap-3 w-full rounded-xl border border-border bg-secondary/50 p-3 text-xs font-semibold text-foreground hover:bg-secondary transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-8 w-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Twitter, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Post on Twitter (X)" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									handleCopyLink();
									setShareModalOpen(false);
								},
								className: "flex items-center gap-3 w-full rounded-xl border border-border bg-secondary/50 p-3 text-xs font-semibold text-foreground hover:bg-secondary transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-8 w-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy Referral URL" })]
							})
						]
					})]
				})
			})
		]
	});
}
function ProfilePage() {
	const { user, profile, dbUser, role: _role, isAdmin, signOut, signIn, allUsers } = useAuth();
	const [demoSwitchOpen, setDemoSwitchOpen] = (0, import_react.useState)(false);
	const [profileTab, setProfileTab] = (0, import_react.useState)("personal-kyc");
	const [activeTab, setActiveTab] = (0, import_react.useState)("videos");
	const [editProfileOpen, setEditProfileOpen] = (0, import_react.useState)(false);
	const userMeta = user?.user_metadata;
	const currentUserId = profile?.user_id || dbUser?.user_id || (typeof userMeta?.user_id === "string" ? userMeta.user_id : "") || "FT483921";
	const currentFullName = profile?.full_name || profile?.name || dbUser?.name || (typeof userMeta?.name === "string" ? userMeta.name : "") || "Alex Rivera";
	const currentMobile = profile?.mobile || dbUser?.mobile || (typeof userMeta?.mobile === "string" ? userMeta.mobile : "") || "+1 555-014-8392";
	const [channelName, setChannelName] = (0, import_react.useState)(profile?.full_name || profile?.name || dbUser?.name || "Alex Rivera");
	const [channelHandle, setChannelHandle] = (0, import_react.useState)(profile?.username || currentUserId.toLowerCase());
	const [channelBio, setChannelBio] = (0, import_react.useState)("Building full-stack web applications, modern UI kits, and sharing creative tutorials weekly.");
	const [userVideos, setUserVideos] = (0, import_react.useState)([
		{
			id: "uv-1",
			title: "Building a Full-Stack YouTube Clone with React 19 & Tailwind CSS",
			channel: channelName,
			views: "142K views",
			age: "3 days ago",
			duration: "34:20",
			category: "Coding",
			thumb: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
			description: "Full guide covering real-time chat, video player, and dark mode.",
			initials: "AS",
			tint: "#e11d48"
		},
		{
			id: "uv-2",
			title: "Clean Code Architecture: How to Structure High-Growth React Apps",
			channel: channelName,
			views: "89K views",
			age: "2 weeks ago",
			duration: "21:15",
			category: "Coding",
			thumb: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80",
			description: "State management, modular routing, and clean architectural patterns.",
			initials: "AS",
			tint: "#2563eb"
		},
		{
			id: "uv-3",
			title: "Next-Gen CSS Tips & Tricks: Typography, Grid, and Fluid Scaling",
			channel: channelName,
			views: "54K views",
			age: "1 month ago",
			duration: "18:40",
			category: "Design",
			thumb: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80",
			description: "Advanced CSS layout tricks to elevate modern web interfaces.",
			initials: "AS",
			tint: "#10b981"
		},
		{
			id: "uv-4",
			title: "Mastering Database Schemas & Authentication Security Rules",
			channel: channelName,
			views: "36K views",
			age: "2 months ago",
			duration: "28:10",
			category: "Tech",
			thumb: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
			description: "Step-by-step security guidelines and robust database modeling.",
			initials: "AS",
			tint: "#8b5cf6"
		}
	]);
	const historyVideos = recent.slice(0, 4);
	const handleSwitchUser = async (email) => {
		try {
			await signIn({
				identifier: email,
				password: "password123"
			});
			setDemoSwitchOpen(false);
		} catch {}
	};
	const handleDeleteVideo = (id, title) => {
		setUserVideos((prev) => prev.filter((v) => v.id !== id));
		toast.success(`Deleted "${title.slice(0, 24)}..."`);
	};
	const handleSaveProfile = (e) => {
		e.preventDefault();
		setEditProfileOpen(false);
		toast.success("Profile updated successfully!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground antialiased selection:bg-brand selection:text-white pb-24 md:pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-brand/10 px-2.5 py-0.5 text-[11px] font-extrabold uppercase tracking-wider text-brand",
							children: "You"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, { showLabelsOnWide: false }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "grid h-9 w-9 place-items-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground transition",
							"aria-label": "Account settings",
							title: "Account settings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4" })
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-5xl px-4 sm:px-6 pt-6 space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-20 w-20 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand via-brand-dark to-black text-2xl font-bold text-white ring-4 ring-brand/20 shadow-md",
									children: (channelName || "A").charAt(0).toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-xl sm:text-2xl font-extrabold text-foreground",
											children: channelName
										}), isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-brand px-2.5 py-0.5 text-[10px] font-bold text-brand-foreground shadow-sm",
											children: "Admin"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-0.5 flex flex-wrap items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"@",
											channelHandle,
											" · ",
											user ? user.email : "creator@facetube.app"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono font-bold text-brand bg-brand/10 px-2 py-0.5 rounded-md border border-brand/20",
											children: ["ID: ", currentUserId]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: "12.4K"
											}), " subscribers"] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: "1.8M"
											}), " total views"] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: userVideos.length
											}), " videos"] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-foreground/80 line-clamp-2 max-w-xl",
										children: channelBio
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 w-full sm:w-auto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setEditProfileOpen(true),
										className: "inline-flex items-center gap-1.5 rounded-full bg-brand px-4 py-2 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "h-3.5 w-3.5" }), "Edit Profile"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDemoSwitchOpen((o) => !o),
										className: "rounded-full border border-border bg-secondary/60 px-4 py-2 text-xs font-semibold text-foreground transition hover:bg-secondary",
										children: "Switch User"
									}),
									user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => signOut(),
										className: "inline-flex items-center gap-1.5 rounded-full border border-red-500/30 bg-red-500/10 px-3.5 py-2 text-xs font-semibold text-red-500 transition hover:bg-red-500/20",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" }), "Sign Out"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/auth",
										className: "rounded-full bg-brand px-5 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-brand-dark",
										children: "Sign In"
									})
								]
							})]
						}), demoSwitchOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 pt-5 border-t border-border/70 space-y-2 animate-in fade-in",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider",
								children: "Quick switch to demo user profile:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-2",
								children: (allUsers || []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleSwitchUser(u.email),
									className: `flex items-center justify-between rounded-xl border p-2.5 text-xs text-left transition ${user?.email === u.email ? "border-brand bg-brand/10 font-bold text-brand ring-1 ring-brand" : "border-border bg-secondary/40 text-foreground hover:bg-secondary"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: u.full_name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-muted-foreground",
										children: [
											"@",
											u.username,
											" · ",
											u.role
										]
									})] }), user?.email === u.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-brand" })]
								}, u.id))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-3xl border border-border bg-card p-5 shadow-sm space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-brand" }), "Channel Analytics (Last 28 Days)"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/your-videos",
								className: "text-xs font-semibold text-brand hover:underline",
								children: "Full Studio"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border bg-secondary/40 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Views"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4 text-blue-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-2xl font-black text-foreground",
											children: "1.8M"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[11px] font-semibold text-emerald-500",
											children: "+14.2% vs previous period"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border bg-secondary/40 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Watch Time"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-purple-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-2xl font-black text-foreground",
											children: "84.2K hrs"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[11px] font-semibold text-emerald-500",
											children: "+9.8% vs previous period"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border bg-secondary/40 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Estimated Revenue"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-4 w-4 text-emerald-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-2xl font-black text-foreground",
											children: "$4,280.50"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[11px] font-semibold text-emerald-500",
											children: "+$520.20 this month"
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5 w-full sm:w-auto",
									children: [
										{
											id: "personal-kyc",
											label: "Personal KYC",
											icon: User,
											emoji: "👤"
										},
										{
											id: "bank-kyc",
											label: "Bank KYC",
											icon: Landmark,
											emoji: "🏦"
										},
										{
											id: "referral-link",
											label: "Referral Link",
											icon: Link2,
											emoji: "🔗"
										}
									].map((tab) => {
										const Icon = tab.icon;
										const isActive = profileTab === tab.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setProfileTab(tab.id),
											className: `relative flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${isActive ? "bg-brand text-white shadow-lift ring-2 ring-brand/30" : "bg-secondary/60 text-muted-foreground hover:text-foreground hover:bg-secondary"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tab.emoji }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tab.label })
											]
										}, tab.id);
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground font-medium hidden sm:inline",
									children: "Account Management & Verification"
								})]
							}),
							profileTab === "personal-kyc" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonalKycTab, {
								userId: currentUserId,
								defaultFullName: currentFullName,
								defaultMobile: currentMobile
							}),
							profileTab === "bank-kyc" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BankKycTab, {
								userId: currentUserId,
								defaultFullName: currentFullName
							}),
							profileTab === "referral-link" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferralLinkTab, {
								userId: currentUserId,
								userName: channelName
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-bold uppercase tracking-wider text-muted-foreground",
									children: "Channel Media & Playlists"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex border-b border-border",
								children: [
									{
										id: "videos",
										label: "Videos",
										count: userVideos.length
									},
									{
										id: "shorts",
										label: "Shorts",
										count: SHORTS_LIST.length
									},
									{
										id: "playlists",
										label: "Playlists",
										count: 3
									}
								].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setActiveTab(tab.id),
									className: `relative flex items-center gap-2 px-5 py-3 text-sm font-semibold transition ${activeTab === tab.id ? "text-brand" : "text-muted-foreground hover:text-foreground"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tab.label }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold text-muted-foreground",
											children: tab.count
										}),
										activeTab === tab.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 inset-x-0 h-0.5 bg-brand rounded-full" })
									]
								}, tab.id))
							}),
							activeTab === "videos" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												"Showing ",
												userVideos.length,
												" uploaded videos"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/upload",
											className: "rounded-full bg-brand px-4 py-1.5 text-xs font-bold text-white transition hover:bg-brand-dark shadow-sm",
											children: "Upload New"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
										children: userVideos.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "group relative rounded-2xl border border-border bg-card p-2.5 transition-all hover:border-brand/40 hover:shadow-md flex flex-col justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/watch/$videoId",
												params: { videoId: v.id },
												className: "block",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative aspect-video rounded-xl overflow-hidden bg-black mb-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: v.thumb,
														alt: v.title,
														className: "h-full w-full object-cover transition duration-300 group-hover:scale-105 opacity-90"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "absolute bottom-1.5 right-1.5 rounded-md bg-black/80 px-1.5 py-0.5 text-[10px] font-bold text-white",
														children: v.duration
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "text-xs font-bold text-foreground line-clamp-2 group-hover:text-brand transition-colors",
													children: v.title
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-[11px] text-muted-foreground",
												children: [
													v.views,
													" · ",
													v.age
												]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 flex items-center justify-between border-t border-border/50 pt-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded bg-brand/10 px-1.5 py-0.5 text-[10px] font-bold text-brand",
													children: "Monetized"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => handleDeleteVideo(v.id, v.title),
													className: "flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold text-destructive transition hover:bg-destructive/10 active:scale-95",
													title: "Delete video",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" }), "Delete"]
												})]
											})]
										}, v.id))
									}),
									userVideos.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "py-12 text-center rounded-2xl border border-dashed border-border p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-semibold text-foreground",
												children: "No videos uploaded yet"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-1",
												children: "Upload your first video to grow your channel audience."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/upload",
												className: "mt-4 inline-block rounded-full bg-brand px-5 py-2 text-xs font-bold text-white",
												children: "Upload Video"
											})
										]
									})
								]
							}),
							activeTab === "shorts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4",
								children: SHORTS_LIST.map((short) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/shorts",
									className: "group relative rounded-2xl overflow-hidden border border-border bg-black aspect-[9/16] shadow-sm transition hover:scale-[1.02]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: short.thumb,
											alt: short.title,
											className: "h-full w-full object-cover opacity-85 transition group-hover:opacity-100"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute bottom-3 left-3 right-3 text-white",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold line-clamp-2",
												children: short.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-[10px] text-white/80",
												children: [short.likes, " likes"]
											})]
										})
									]
								}, short.id))
							}),
							activeTab === "playlists" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/watch-later",
										className: "group rounded-2xl border border-border bg-card p-4 transition hover:border-brand/50 shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "aspect-video rounded-xl bg-blue-500/10 flex flex-col items-center justify-center text-blue-500 mb-3 group-hover:bg-blue-500/20 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-8 w-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 text-xs font-bold",
													children: "Watch Later"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-bold text-foreground group-hover:text-brand",
												children: "Watch Later"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-0.5",
												children: "Updated recently · Private"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/liked-videos",
										className: "group rounded-2xl border border-border bg-card p-4 transition hover:border-brand/50 shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "aspect-video rounded-xl bg-amber-500/10 flex flex-col items-center justify-center text-amber-500 mb-3 group-hover:bg-amber-500/20 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "h-8 w-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 text-xs font-bold",
													children: "Liked Videos"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-bold text-foreground group-hover:text-brand",
												children: "Liked Videos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-0.5",
												children: "All favorited videos · Private"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/history",
										className: "group rounded-2xl border border-border bg-card p-4 transition hover:border-brand/50 shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "aspect-video rounded-xl bg-brand/10 flex flex-col items-center justify-center text-brand mb-3 group-hover:bg-brand/20 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-8 w-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 text-xs font-bold",
													children: "Watch History"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-bold text-foreground group-hover:text-brand",
												children: "Watch History"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-0.5",
												children: "Continuous stream · You only"
											})
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-base font-bold text-foreground",
									children: "Recently Watched"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/history",
								className: "text-xs font-semibold text-brand hover:underline",
								children: "View all"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
							children: historyVideos.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/watch/$videoId",
								params: { videoId: v.id },
								className: "group rounded-xl border border-border bg-card p-2 transition-all hover:border-brand/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative aspect-video rounded-lg overflow-hidden bg-black mb-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: v.thumb,
												alt: v.title,
												className: "h-full w-full object-cover transition duration-300 group-hover:scale-105 opacity-90"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute bottom-1 right-1 rounded bg-black/80 px-1 py-0.5 text-[9px] font-bold text-white",
												children: v.duration
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 inset-x-0 h-0.5 bg-red-600 w-3/4" })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs font-bold text-foreground line-clamp-1 group-hover:text-brand transition-colors",
										children: v.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground mt-0.5 truncate",
										children: v.channel
									})
								]
							}, v.id))
						})]
					})
				]
			}),
			editProfileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-bold text-foreground",
							children: "Edit Channel Profile"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setEditProfileOpen(false),
							className: "rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveProfile,
						className: "mt-4 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Channel Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: channelName,
								onChange: (e) => setChannelName(e.target.value),
								required: true,
								className: "mt-1.5 w-full rounded-xl border border-border bg-secondary/60 px-3.5 py-2 text-xs text-foreground outline-none focus:border-brand"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Handle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1.5 flex items-center rounded-xl border border-border bg-secondary/60 px-3.5 py-2 text-xs text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground mr-1",
									children: "@"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: channelHandle,
									onChange: (e) => setChannelHandle(e.target.value),
									required: true,
									className: "w-full bg-transparent outline-none text-foreground text-xs"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Channel Description"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 3,
								value: channelBio,
								onChange: (e) => setChannelBio(e.target.value),
								className: "mt-1.5 w-full rounded-xl border border-border bg-secondary/60 px-3.5 py-2 text-xs text-foreground outline-none focus:border-brand"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2 border-t border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setEditProfileOpen(false),
									className: "rounded-full px-4 py-2 text-xs font-semibold text-muted-foreground hover:text-foreground",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "rounded-full bg-brand px-5 py-2 text-xs font-bold text-white shadow-lift hover:bg-brand-dark transition active:scale-95",
									children: "Save Changes"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
//#endregion
export { ProfilePage as component };
