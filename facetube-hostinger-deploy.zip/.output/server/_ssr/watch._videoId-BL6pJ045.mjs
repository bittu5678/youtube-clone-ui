import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { D as Send, E as Settings, Pt as Download, R as Play, T as Share2, _ as ThumbsDown, a as Volume2, g as ThumbsUp, in as Bookmark, tt as Maximize2 } from "../_libs/lucide-react.mjs";
import { t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { T as allVideos, a as interleaveFeedWithImages, i as fetchUploadedImages, n as Route, w as Navbar } from "./router-vsnEDfJA.mjs";
import { t as VideoCard } from "./VideoCard-Cc9hfZ35.mjs";
import { t as ImageCard } from "./ImageCard-DVUtqDL3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._videoId-BL6pJ045.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WatchPage() {
	const { video } = Route.useLoaderData();
	const { user, profile } = useAuth();
	const [subscribed, setSubscribed] = (0, import_react.useState)(false);
	const [liked, setLiked] = (0, import_react.useState)(false);
	const [disliked, setDisliked] = (0, import_react.useState)(false);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const [commentText, setCommentText] = (0, import_react.useState)("");
	const [comments, setComments] = (0, import_react.useState)([{
		id: "c1",
		n: "Aria Kapoor",
		i: "AK",
		t: "The pacing on this is perfect. Bookmarked the whole middle section.",
		time: "2 days ago"
	}, {
		id: "c2",
		n: "Marcus Bell",
		i: "MB",
		t: "Been waiting for this one. The part at 08:12 finally made it click for me.",
		time: "2 days ago"
	}]);
	const related = allVideos.filter((v) => v.id !== video.id).slice(0, 8);
	const [uploadedImages, setUploadedImages] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		fetchUploadedImages().then((imgs) => {
			if (imgs && imgs.length > 0) setUploadedImages(imgs);
		}).catch((err) => console.error("Error loading images for related feed:", err));
	}, []);
	const interleavedRelated = interleaveFeedWithImages(related, uploadedImages, 5);
	const handleToggleLike = () => {
		setLiked((v) => !v);
		if (!liked && disliked) setDisliked(false);
	};
	const handleToggleDislike = () => {
		setDisliked((v) => !v);
		if (!disliked && liked) setLiked(false);
	};
	const handleShare = () => {
		if (navigator.share) navigator.share({
			title: video.title,
			url: window.location.href
		}).catch(() => {});
		else {
			navigator.clipboard.writeText(window.location.href);
			toast.success("Link copied to clipboard!");
		}
	};
	const handleToggleSave = () => {
		setSaved((prev) => {
			const next = !prev;
			toast.success(next ? "Added to Watch Later!" : "Removed from Watch Later.");
			return next;
		});
	};
	const handleAddComment = (e) => {
		e.preventDefault();
		if (!commentText.trim()) return;
		const authorName = profile?.full_name || user?.email?.split("@")[0] || "You";
		const authorInitials = authorName.slice(0, 2).toUpperCase();
		setComments((prev) => [{
			id: `c-${Date.now()}`,
			n: authorName,
			i: authorInitials,
			t: commentText.trim(),
			time: "Just now"
		}, ...prev]);
		setCommentText("");
		toast.success("Comment posted!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background font-sans text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, { onToggleSidebar: () => {} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-[1600px] gap-8 px-4 py-6 pb-24 sm:px-6 lg:grid-cols-[minmax(0,1fr)_400px] lg:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden rounded-2xl bg-black shadow-lift",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: video.thumb,
									alt: video.title,
									width: 1280,
									height: 720,
									className: "aspect-video w-full object-cover opacity-55"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Play video",
									className: "absolute inset-0 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-20 w-20 place-items-center rounded-full bg-brand text-brand-foreground shadow-lift transition hover:scale-105",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-9 w-9 translate-x-[2px] fill-current" })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-4 pb-3 pt-10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1 w-full overflow-hidden rounded-full bg-white/25",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/3 rounded-full bg-brand" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-3 text-white/90",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-4 w-4" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs tabular-nums",
												children: ["08:12 / ", video.duration]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-auto flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "h-4 w-4" })]
											})
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 text-xl font-extrabold leading-snug tracking-tight sm:text-2xl",
							children: video.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 shrink-0 place-items-center rounded-full text-sm font-bold text-white",
									style: { backgroundColor: video.tint },
									children: video.initials
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-semibold",
										children: video.channel
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: "1.2M subscribers"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSubscribed((v) => {
											const next = !v;
											toast.success(next ? `Subscribed to ${video.channel}!` : `Unsubscribed.`);
											return next;
										});
									},
									className: `ml-1 rounded-full px-5 py-2 text-sm font-semibold transition ${subscribed ? "bg-secondary text-foreground hover:bg-muted" : "bg-brand text-brand-foreground shadow-lift hover:bg-brand-dark"}`,
									children: subscribed ? "Subscribed" : "Subscribe"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "ml-auto flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center overflow-hidden rounded-full bg-secondary",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: handleToggleLike,
													className: `flex items-center gap-2 px-4 py-2 text-sm font-medium transition hover:bg-muted ${liked ? "text-brand font-bold" : "text-foreground"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: `h-4 w-4 ${liked ? "fill-brand" : ""}` }), liked ? "24K" : "23K"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-6 w-px bg-border" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": "Dislike",
													onClick: handleToggleDislike,
													className: `px-4 py-2 transition hover:bg-muted ${disliked ? "text-foreground font-bold" : "text-foreground"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsDown, { className: `h-4 w-4 ${disliked ? "fill-foreground" : ""}` })
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleShare,
											className: "flex items-center gap-2 rounded-full bg-secondary px-4 py-2 text-sm font-medium text-foreground transition hover:bg-muted active:scale-95",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: "Share"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => toast.info("Download starting..."),
											className: "flex items-center gap-2 rounded-full bg-secondary px-4 py-2 text-sm font-medium text-foreground transition hover:bg-muted active:scale-95",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: "Download"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleToggleSave,
											className: `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition active:scale-95 ${saved ? "bg-brand text-white" : "bg-secondary text-foreground hover:bg-muted"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `h-4 w-4 ${saved ? "fill-white" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: saved ? "Saved" : "Save"
											})]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 rounded-2xl bg-secondary/70 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold",
									children: [
										video.views,
										" · ",
										video.age,
										" · ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-brand",
											children: ["#", video.category]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: `mt-2 text-sm leading-relaxed text-foreground/85 ${expanded ? "" : "line-clamp-2"}`,
									children: [
										video.description,
										" Chapters, resources and the full project source are linked below. Thanks for watching — leave a comment with what you want covered next on",
										" ",
										video.channel,
										"."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setExpanded((v) => !v),
									className: "mt-2 text-sm font-semibold text-muted-foreground hover:text-foreground",
									children: expanded ? "Show less" : "Show more"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-8 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-base font-bold",
										children: [comments.length + 1282, " Comments"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAddComment,
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-xs font-bold text-white shadow-sm",
										children: (profile?.username || user?.email || "U").charAt(0).toUpperCase()
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Add a comment...",
											value: commentText,
											onChange: (e) => setCommentText(e.target.value),
											className: "w-full border-b border-border bg-transparent pb-1.5 text-sm text-foreground outline-none transition focus:border-brand"
										}), commentText.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-end gap-2 animate-in fade-in",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCommentText(""),
												className: "rounded-full px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground",
												children: "Cancel"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "submit",
												className: "inline-flex items-center gap-1.5 rounded-full bg-brand px-4 py-1.5 text-xs font-bold text-white shadow-sm transition hover:bg-brand-dark",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3 w-3" }), "Comment"]
											})]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-5",
									children: comments.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 animate-in fade-in",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-xs font-bold text-brand-foreground",
											children: c.i
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-sm font-semibold",
												children: [
													c.n,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-normal text-muted-foreground",
														children: ["· ", c.time]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-foreground/85 mt-0.5",
												children: c.t
											})]
										})]
									}, c.id))
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-4 text-base font-bold",
						children: "Related content"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-x-5 gap-y-7 sm:grid-cols-2 lg:grid-cols-1",
						children: interleavedRelated.map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
//#endregion
export { WatchPage as component };
