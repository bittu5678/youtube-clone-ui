import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { N as Radio, Wt as Clapperboard, s as Users } from "../_libs/lucide-react.mjs";
import { D as creators, T as allVideos, s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
import { t as VideoCard } from "./VideoCard-Cc9hfZ35.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subscriptions-ovj6tUwz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SubscriptionsPage() {
	const [selectedFilter, setSelectedFilter] = (0, import_react.useState)("All");
	const [selectedCreator, setSelectedCreator] = (0, import_react.useState)(null);
	const filteredVideos = allVideos.filter((v) => {
		if (selectedCreator) return v.channel === selectedCreator;
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Subscriptions"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Latest videos from your subscribed channels"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/80 px-3.5 py-1.5 text-xs font-semibold text-foreground transition hover:bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }),
							"Manage (",
							creators.length,
							")"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/live",
						className: "inline-flex items-center gap-1.5 rounded-full bg-red-500/10 px-3.5 py-1.5 text-xs font-bold text-red-500 transition hover:bg-red-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "h-3.5 w-3.5" }), "Live Now"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSelectedCreator(null),
					className: `flex flex-col items-center gap-1.5 shrink-0 transition ${selectedCreator === null ? "opacity-100" : "opacity-70 hover:opacity-100"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `grid h-14 w-14 place-items-center rounded-full border-2 transition ${selectedCreator === null ? "border-brand bg-brand text-white shadow-md" : "border-border bg-secondary text-foreground"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] font-semibold text-foreground max-w-[64px] truncate",
						children: "All"
					})]
				}), creators.map((c, i) => {
					const isSelected = selectedCreator === c.name;
					const isLive = i === 1;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSelectedCreator(isSelected ? null : c.name),
						className: `relative flex flex-col items-center gap-1.5 shrink-0 group transition ${isSelected ? "opacity-100 scale-105" : "opacity-80 hover:opacity-100"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `relative grid h-14 w-14 place-items-center rounded-full font-bold text-sm text-white shadow-sm transition-all ${isSelected ? "ring-4 ring-brand bg-gradient-to-br from-brand to-brand-dark" : isLive ? "ring-2 ring-red-500 bg-gradient-to-br from-red-600 to-amber-600" : "ring-2 ring-border bg-gradient-to-br from-neutral-800 to-neutral-700 group-hover:ring-brand/50"}`,
							children: [
								c.initials,
								isLive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -bottom-1 rounded-full bg-red-600 px-1.5 py-0.2 text-[8px] font-black uppercase text-white tracking-widest ring-2 ring-background",
									children: "LIVE"
								}),
								!isLive && i % 2 === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 right-0 h-2.5 w-2.5 rounded-full bg-brand ring-2 ring-background" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-medium text-foreground max-w-[64px] truncate",
							children: c.name
						})]
					}, c.name);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 border-b border-border/70 pb-3",
				children: [
					"All",
					"Today",
					"Live",
					"Continue"
				].map((filter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelectedFilter(filter),
					className: `rounded-full px-4 py-1 text-xs font-semibold transition ${selectedFilter === filter ? "bg-foreground text-background shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground"}`,
					children: filter
				}, filter))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-bold text-foreground sm:text-lg",
						children: selectedCreator ? `Uploads from ${selectedCreator}` : "Recent Uploads"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [filteredVideos.length, " videos available"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
					children: filteredVideos.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: v }, `sub-video-${v.id}`))
				})]
			})
		]
	}) });
}
//#endregion
export { SubscriptionsPage as component };
