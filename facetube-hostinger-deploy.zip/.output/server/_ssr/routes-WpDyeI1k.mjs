import { o as __toESM } from "../_runtime.mjs";
import { r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as Search, R as Play, Tt as Flame, Ut as Clock3, Xt as ChevronLeft, Yt as ChevronRight, in as Bookmark, k as SearchX, on as BadgeCheck, y as Sparkles } from "../_libs/lucide-react.mjs";
import { n as ShortsIcon, t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { A as trending, C as Sidebar, D as creators, E as categories, O as recent, T as allVideos, a as interleaveFeedWithImages, c as Route$36, i as fetchUploadedImages, k as recommended, w as Navbar } from "./router-vsnEDfJA.mjs";
import { t as VideoCard } from "./VideoCard-Cc9hfZ35.mjs";
import { t as SHORTS_LIST } from "./shorts-DrPnqhcl.mjs";
import { t as ImageCard } from "./ImageCard-DVUtqDL3.mjs";
import { t as Footer } from "./Footer-DiXczCHA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-WpDyeI1k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_default = "/assets/hero-B-w4XirO.jpg";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden rounded-3xl bg-[#141416] text-white shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_default,
					alt: "Creator filming in a red-lit studio",
					width: 1600,
					height: 900,
					className: "h-full w-full object-cover opacity-55"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-[#0d0d0f] via-[#0d0d0f]/85 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#b3121c]/35 via-transparent to-transparent" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative grid gap-8 p-6 sm:p-10 lg:grid-cols-[minmax(0,1fr)_420px] lg:items-center lg:p-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 backdrop-blur",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
							size: 20,
							showName: false,
							asLink: false
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold uppercase tracking-[0.18em] text-white/80",
							children: "FaceTube Originals"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-extrabold leading-[1.08] tracking-tight sm:text-5xl",
						children: "Inside the studio: how modern creators ship a video a day"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-lg text-sm leading-relaxed text-white/70 sm:text-base",
						children: "A feature-length look at the workflows, gear and editing systems behind the fastest-growing channels on FaceTube."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "inline-flex items-center gap-2 rounded-full bg-brand px-6 py-3 text-sm font-semibold text-brand-foreground shadow-lift transition hover:bg-brand-dark active:scale-95",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current" }), "Watch Now"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-6 py-3 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "h-4 w-4" }), "Watch Later"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-white/55",
								children: "48:12 · 2.4M views"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "group relative hidden overflow-hidden rounded-2xl border border-white/15 shadow-2xl lg:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_default,
					alt: "Featured video preview",
					width: 1600,
					height: 900,
					className: "aspect-video w-full object-cover transition-transform duration-700 group-hover:scale-105"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center bg-black/25",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-16 w-16 place-items-center rounded-full bg-brand/95 shadow-lift transition group-hover:scale-110",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-6 w-6 translate-x-[2px] fill-current text-white" })
					})
				})]
			})]
		})]
	});
}
function ShortsShelf({ title = "Shorts", items = SHORTS_LIST, className = "" }) {
	const navigate = useNavigate();
	const scrollRef = (0, import_react.useRef)(null);
	const [canScrollLeft, setCanScrollLeft] = (0, import_react.useState)(false);
	const [canScrollRight, setCanScrollRight] = (0, import_react.useState)(true);
	const isDownRef = (0, import_react.useRef)(false);
	const startXRef = (0, import_react.useRef)(0);
	const scrollLeftRef = (0, import_react.useRef)(0);
	const hasDraggedRef = (0, import_react.useRef)(false);
	const [isDragging, setIsDragging] = (0, import_react.useState)(false);
	const checkScroll = (0, import_react.useCallback)(() => {
		const el = scrollRef.current;
		if (!el) return;
		const atStart = el.scrollLeft <= 4;
		const atEnd = el.scrollLeft >= el.scrollWidth - el.clientWidth - 8;
		setCanScrollLeft(!atStart);
		setCanScrollRight(!atEnd);
	}, []);
	(0, import_react.useEffect)(() => {
		checkScroll();
		const el = scrollRef.current;
		if (!el) return;
		el.addEventListener("scroll", checkScroll, { passive: true });
		window.addEventListener("resize", checkScroll);
		return () => {
			el.removeEventListener("scroll", checkScroll);
			window.removeEventListener("resize", checkScroll);
		};
	}, [checkScroll]);
	const handleScroll = (direction) => {
		const el = scrollRef.current;
		if (!el) return;
		const scrollAmount = el.clientWidth * .75;
		el.scrollBy({
			left: direction === "left" ? -scrollAmount : scrollAmount,
			behavior: "smooth"
		});
	};
	const handleMouseDown = (e) => {
		const el = scrollRef.current;
		if (!el) return;
		isDownRef.current = true;
		hasDraggedRef.current = false;
		startXRef.current = e.pageX - el.offsetLeft;
		scrollLeftRef.current = el.scrollLeft;
		setIsDragging(true);
	};
	const handleMouseMove = (e) => {
		if (!isDownRef.current) return;
		const el = scrollRef.current;
		if (!el) return;
		const walk = (e.pageX - el.offsetLeft - startXRef.current) * 1.4;
		if (Math.abs(walk) > 5) hasDraggedRef.current = true;
		el.scrollLeft = scrollLeftRef.current - walk;
	};
	const handleMouseUp = () => {
		isDownRef.current = false;
		setIsDragging(false);
	};
	const handleMouseLeave = () => {
		isDownRef.current = false;
		setIsDragging(false);
	};
	const handleCardClick = (e, shortId) => {
		if (hasDraggedRef.current) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
		navigate({
			to: "/shorts",
			search: { id: shortId }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `relative my-10 sm:my-12 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-red-600 text-white shadow-sm ring-2 ring-red-600/20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortsIcon, {
						className: "h-5 w-5 fill-white text-white",
						active: true
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold tracking-tight text-foreground sm:text-xl",
						children: title
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground sm:text-sm",
					children: "Trending quick vertical videos"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 sm:gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shorts",
						className: "hidden sm:inline-flex text-xs font-semibold text-brand hover:underline mr-2",
						children: "Explore all"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => handleScroll("left"),
						disabled: !canScrollLeft,
						"aria-label": "Scroll Shorts left",
						className: `grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-foreground transition-all shadow-sm ${canScrollLeft ? "hover:bg-secondary hover:scale-105 active:scale-95 cursor-pointer" : "opacity-35 cursor-not-allowed"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => handleScroll("right"),
						disabled: !canScrollRight,
						"aria-label": "Scroll Shorts right",
						className: `grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-foreground transition-all shadow-sm ${canScrollRight ? "hover:bg-secondary hover:scale-105 active:scale-95 cursor-pointer" : "opacity-35 cursor-not-allowed"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scrollRef,
			onMouseDown: handleMouseDown,
			onMouseMove: handleMouseMove,
			onMouseUp: handleMouseUp,
			onMouseLeave: handleMouseLeave,
			className: `flex gap-3.5 sm:gap-4 overflow-x-auto pb-3 pt-1 px-0.5 select-none [scrollbar-width:none] [&::-webkit-scrollbar]:hidden ${isDragging ? "cursor-grabbing" : "cursor-grab active:cursor-grabbing"}`,
			style: {
				scrollSnapType: isDragging ? "none" : "x proximity",
				WebkitOverflowScrolling: "touch"
			},
			children: items.map((short) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				onClick: (e) => handleCardClick(e, short.id),
				style: { scrollSnapAlign: "start" },
				className: "group relative w-[160px] sm:w-[185px] md:w-[210px] shrink-0 aspect-[9/16] rounded-2xl overflow-hidden bg-muted border border-border/80 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lift hover:border-brand/40 cursor-pointer",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: short.thumb,
						alt: short.title,
						draggable: false,
						loading: "lazy",
						className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 select-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent pointer-events-none" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute top-2.5 right-2.5 flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-bold text-white backdrop-blur-md opacity-90 group-hover:opacity-100 transition-opacity",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortsIcon, {
							className: "h-3 w-3 text-red-500 fill-red-500",
							active: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shorts" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-12 w-12 place-items-center rounded-full bg-red-600/90 text-white shadow-xl backdrop-blur-sm transform scale-90 group-hover:scale-100 transition-transform duration-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-5 w-5 fill-white translate-x-0.5" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-3.5 flex flex-col justify-end pointer-events-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs sm:text-sm font-bold text-white line-clamp-2 leading-snug drop-shadow-md group-hover:text-red-300 transition-colors",
							children: short.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1.5 flex items-center justify-between text-[11px] sm:text-xs text-white/80 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "drop-shadow-sm font-semibold text-white/90",
								children: short.views
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-white/60",
								children: short.creator
							})]
						})]
					})
				]
			}, short.id))
		})]
	});
}
function SectionHeading({ icon: Icon, title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "truncate text-lg font-bold tracking-tight text-foreground sm:text-xl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm text-muted-foreground",
				children: subtitle
			})]
		})]
	});
}
function Index() {
	const searchParams = Route$36.useSearch();
	const [railOpen, setRailOpen] = (0, import_react.useState)(true);
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	const [activeCategory, setActiveCategory] = (0, import_react.useState)("All");
	const [query, setQuery] = (0, import_react.useState)(searchParams.q || "");
	const [uploadedImages, setUploadedImages] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (searchParams.q !== void 0) setQuery(searchParams.q);
	}, [searchParams.q]);
	(0, import_react.useEffect)(() => {
		fetchUploadedImages().then((imgs) => {
			if (imgs && imgs.length > 0) setUploadedImages(imgs);
		}).catch((err) => console.error("Error loading feed images:", err));
	}, []);
	const isFiltering = query.trim().length > 0 || activeCategory !== "All";
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		const seen = /* @__PURE__ */ new Set();
		return allVideos.filter((v) => {
			if (seen.has(v.title)) return false;
			const matchesCategory = activeCategory === "All" || v.category === activeCategory;
			const matchesQuery = q.length === 0 || v.title.toLowerCase().includes(q) || v.channel.toLowerCase().includes(q) || v.category.toLowerCase().includes(q) || v.description.toLowerCase().includes(q);
			if (!matchesCategory || !matchesQuery) return false;
			seen.add(v.title);
			return true;
		});
	}, [query, activeCategory]);
	const interleavedRecommended = (0, import_react.useMemo)(() => {
		return interleaveFeedWithImages(recommended, uploadedImages, 5);
	}, [uploadedImages]);
	const interleavedTrending = (0, import_react.useMemo)(() => {
		return interleaveFeedWithImages(trending, uploadedImages, 5);
	}, [uploadedImages]);
	const interleavedRecent = (0, import_react.useMemo)(() => {
		return interleaveFeedWithImages(recent, uploadedImages, 5);
	}, [uploadedImages]);
	const interleavedFiltered = (0, import_react.useMemo)(() => {
		return interleaveFeedWithImages(results, uploadedImages, 5);
	}, [results, uploadedImages]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background font-sans text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {
				onToggleSidebar: () => {
					setRailOpen((v) => !v);
					setDrawerOpen((v) => !v);
				},
				query,
				onQueryChange: setQuery
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
					open: railOpen,
					drawerOpen,
					onClose: () => setDrawerOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-w-0 flex-1 pb-24 lg:pb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-16 z-30 border-b border-border bg-background/90 backdrop-blur-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 pt-3 md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex h-10 items-center rounded-full border border-border bg-secondary/60 px-4 focus-within:border-brand/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "search",
									value: query,
									onChange: (e) => setQuery(e.target.value),
									placeholder: "Search videos, creators, topics…",
									className: "h-full w-full min-w-0 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2 overflow-x-auto px-4 py-3 [scrollbar-width:none] sm:px-6 [&::-webkit-scrollbar]:hidden",
							children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setActiveCategory(c),
								className: `shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-all ${activeCategory === c ? "bg-foreground text-background shadow-card" : "bg-secondary text-foreground/75 hover:-translate-y-0.5 hover:bg-brand/10 hover:text-brand"}`,
								children: c
							}, c))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-6 sm:px-6 lg:px-8",
						children: [isFiltering ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							icon: Search,
							title: query.trim() ? `Results for “${query.trim()}”` : `${activeCategory} videos`,
							subtitle: `${results.length} ${results.length === 1 ? "video" : "videos"} found${query.trim() && activeCategory !== "All" ? ` in ${activeCategory}` : ""}`
						}), interleavedFiltered.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4",
								children: interleavedFiltered.slice(0, 6).map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortsShelf, {}),
							interleavedFiltered.length > 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 mt-8",
								children: interleavedFiltered.slice(6).map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid place-items-center rounded-2xl border border-dashed border-border py-20 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchX, { className: "h-10 w-10 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base font-semibold",
									children: "No content matches your filters"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: "Try a different keyword or category."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setQuery("");
										setActiveCategory("All");
									},
									className: "mt-5 rounded-full bg-brand px-5 py-2 text-sm font-semibold text-brand-foreground transition hover:bg-brand-dark",
									children: "Clear filters"
								})
							]
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "mt-12",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
									icon: Sparkles,
									title: "Recommended for you",
									subtitle: "Picked from channels you watch"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4",
									children: interleavedRecommended.map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortsShelf, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "mt-14",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
									icon: Flame,
									title: "Trending now",
									subtitle: "What everyone is watching today"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4",
									children: interleavedTrending.map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "mt-14",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
									icon: BadgeCheck,
									title: "Popular creators",
									subtitle: "Channels growing fast on FaceTube"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6",
									children: creators.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "group rounded-2xl border border-border p-5 text-center shadow-card transition-all hover:-translate-y-1 hover:border-brand/30 hover:shadow-lift",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-sm font-bold text-brand-foreground transition-transform group-hover:scale-105",
												children: c.initials
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-3 truncate text-sm font-semibold text-foreground",
												children: c.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted-foreground",
												children: c.subs
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "mt-3 w-full rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-foreground transition hover:bg-brand hover:text-brand-foreground",
												children: "Subscribe"
											})
										]
									}, c.name))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "mt-14",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
									icon: Clock3,
									title: "Recently uploaded",
									subtitle: "Fresh from your subscriptions"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4",
									children: interleavedRecent.map((item) => item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video: item.data }, item.data.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCard, { image: item.data }, item.data.id))
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
//#endregion
export { Index as component };
