import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, l as useAuth, r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { D as Send, N as Radio, T as Share2, _t as Heart, s as Users } from "../_libs/lucide-react.mjs";
import { a as thumb_5_default, i as thumb_3_default, o as thumb_6_default, r as thumb_1_default, t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-Bi1mNrFV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LIVE_STREAMS = [
	{
		id: "live-1",
		title: "🔴 LIVE: 24-Hour Lo-Fi Coding & System Architecture Sprint (Q&A)",
		streamer: "DevForge Live",
		streamerHandle: "@devforge",
		initials: "DF",
		viewers: "12,450",
		category: "Coding & Tech",
		tags: [
			"typescript",
			"fullstack",
			"react"
		],
		thumb: thumb_1_default,
		isLive: true,
		startedTime: "Started 2 hours ago",
		chatMessages: [
			{
				user: "Sarah_Code",
				text: "Loving the clean Tailwind setup!",
				color: "text-purple-400"
			},
			{
				user: "ByteMaster",
				text: "Are you deploying this on Cloud Run?",
				color: "text-blue-400"
			},
			{
				user: "AlexDev",
				text: "What font are you using in VS Code?",
				color: "text-emerald-400"
			},
			{
				user: "ModeratorBot",
				text: "Welcome to FaceTube Live! Keep chat friendly 🎉",
				isMod: true,
				color: "text-brand"
			},
			{
				user: "Kiran_99",
				text: "The bottom navigation feels so smooth on mobile!",
				color: "text-amber-400"
			}
		]
	},
	{
		id: "live-2",
		title: "🔴 World Championship Grand Finals — Live Commentary & Analysis",
		streamer: "Apex Arena Esports",
		streamerHandle: "@apexarena",
		initials: "AA",
		viewers: "45,820",
		category: "Gaming",
		tags: [
			"esports",
			"fps",
			"finals"
		],
		thumb: thumb_5_default,
		isLive: true,
		startedTime: "Started 45 mins ago",
		chatMessages: [
			{
				user: "SniperPro",
				text: "THAT CLUTCH WAS INSANE",
				color: "text-red-400"
			},
			{
				user: "GamerGirl9",
				text: "Team Blue is dominating map 3",
				color: "text-pink-400"
			},
			{
				user: "Vortex",
				text: "1v3 defuse incoming?!",
				color: "text-cyan-400"
			}
		]
	},
	{
		id: "live-3",
		title: "🔴 Ambient Electronic Live Jam Session: Modular Synthesizers",
		streamer: "SubHarmonic",
		streamerHandle: "@subharmonic",
		initials: "SH",
		viewers: "3,890",
		category: "Music",
		tags: [
			"ambient",
			"synth",
			"modular"
		],
		thumb: thumb_6_default,
		isLive: true,
		startedTime: "Started 1 hour ago",
		chatMessages: [{
			user: "AudioPhile",
			text: "Those analog filters sound pristine",
			color: "text-teal-400"
		}, {
			user: "Echo_Dave",
			text: "Perfect soundtrack for working right now",
			color: "text-indigo-400"
		}]
	},
	{
		id: "live-4",
		title: "🔴 Global Space Mission Launch Live Coverage & Multi-cam Feed",
		streamer: "AeroSpace Now",
		streamerHandle: "@aerospacenow",
		initials: "AN",
		viewers: "94,100",
		category: "Science & Tech",
		tags: [
			"space",
			"rocket",
			"live"
		],
		thumb: thumb_3_default,
		isLive: true,
		startedTime: "Started 3 hours ago",
		chatMessages: [{
			user: "CosmoFan",
			text: "T-minus 10 minutes to main booster separation!",
			color: "text-yellow-400"
		}, {
			user: "Dr_Orbit",
			text: "Telemetry looking nominal across all vectors",
			color: "text-green-400"
		}]
	}
];
var LIVE_CATEGORIES = [
	"All Live",
	"Coding & Tech",
	"Gaming",
	"Music",
	"Science & Tech"
];
function LivePage() {
	const { user, profile } = useAuth();
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All Live");
	const [activeStream, setActiveStream] = (0, import_react.useState)(LIVE_STREAMS[0]);
	const [chatInput, setChatInput] = (0, import_react.useState)("");
	const [chatMessages, setChatMessages] = (0, import_react.useState)(activeStream.chatMessages);
	const [liked, setLiked] = (0, import_react.useState)(false);
	const filteredStreams = selectedCategory === "All Live" ? LIVE_STREAMS : LIVE_STREAMS.filter((s) => s.category === selectedCategory);
	const handleSendMessage = (e) => {
		e.preventDefault();
		if (!chatInput.trim()) return;
		const authorName = profile?.full_name || profile?.username || user?.email?.split("@")[0] || "You";
		setChatMessages((prev) => [...prev, {
			user: authorName,
			text: chatInput.trim(),
			color: "text-brand font-bold"
		}]);
		setChatInput("");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground antialiased selection:bg-brand selection:text-white pb-24 md:pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 rounded-full bg-red-500/10 px-2.5 py-0.5 text-[11px] font-extrabold uppercase tracking-wider text-red-500",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-red-500 animate-pulse" }), "Live"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/upload",
							search: { type: "long" },
							className: "hidden sm:inline-flex items-center gap-1.5 rounded-full bg-red-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-sm transition hover:bg-red-700 active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "h-3.5 w-3.5" }), "Go Live"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, { showLabelsOnWide: false })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 pt-4 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none",
						children: LIVE_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSelectedCategory(cat),
							className: `rounded-full px-4 py-1.5 text-xs font-medium transition shrink-0 ${selectedCategory === cat ? "bg-brand text-white font-semibold shadow-sm" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"}`,
							children: cat
						}, cat))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-2 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-xl border border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: activeStream.thumb,
										alt: activeStream.title,
										className: "h-full w-full object-cover opacity-80"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-4 left-4 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5 rounded-full bg-red-600 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white shadow-lg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-white animate-ping" }), "Live"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1 text-xs font-semibold text-white backdrop-blur-md",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5 text-red-400" }),
												activeStream.viewers,
												" viewers"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute top-4 right-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-black/60 px-3 py-1 text-xs font-medium text-white/90 backdrop-blur-md",
											children: activeStream.category
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute bottom-4 left-4 right-4 flex items-center justify-between text-white",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-brand text-white font-bold text-xs ring-2 ring-white/50",
												children: activeStream.initials
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-bold text-sm text-white drop-shadow-md",
												children: activeStream.streamer
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-white/80",
												children: activeStream.startedTime
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setLiked((l) => !l),
												className: `grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition active:scale-95 ${liked ? "bg-red-600 text-white" : "bg-black/60 text-white hover:bg-black/80"}`,
												"aria-label": "Like stream",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `h-4 w-4 ${liked ? "fill-white" : ""}` })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													if (navigator.share) navigator.share({
														title: activeStream.title,
														url: window.location.href
													}).catch(() => {});
													else navigator.clipboard.writeText(window.location.href);
												},
												className: "grid h-9 w-9 place-items-center rounded-full bg-black/60 text-white hover:bg-black/80 backdrop-blur-md transition active:scale-95",
												"aria-label": "Share stream",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4" })
											})]
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-lg sm:text-xl font-bold text-foreground",
									children: activeStream.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap items-center gap-2",
									children: activeStream.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-md bg-secondary px-2 py-0.5 text-xs text-muted-foreground font-medium",
										children: ["#", tag]
									}, tag))
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col h-[480px] rounded-2xl border border-border bg-card shadow-sm overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-border/70 px-4 py-3 bg-secondary/30",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "h-4 w-4 text-red-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold uppercase tracking-wider text-foreground",
											children: "Live Chat"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-muted-foreground",
										children: "Top Chat"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-4 space-y-3",
									children: chatMessages.map((msg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs leading-relaxed flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `font-semibold shrink-0 ${msg.color}`,
											children: [msg.user, ":"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground/90 break-words",
											children: msg.text
										})]
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSendMessage,
									className: "border-t border-border/70 p-3 bg-background/50 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										placeholder: "Chat as viewer...",
										value: chatInput,
										onChange: (e) => setChatInput(e.target.value),
										className: "flex-1 rounded-xl border border-border bg-secondary/40 px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-brand"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										"aria-label": "Send message",
										className: "grid h-8 w-8 place-items-center rounded-xl bg-brand text-white transition hover:bg-brand-dark active:scale-95",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3.5 w-3.5" })
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold text-foreground",
								children: "More Live Broadcasts"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [filteredStreams.length, " streaming now"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5",
							children: filteredStreams.map((stream) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => {
									setActiveStream(stream);
									setChatMessages(stream.chatMessages);
									window.scrollTo({
										top: 0,
										behavior: "smooth"
									});
								},
								className: `group cursor-pointer rounded-2xl border p-2 transition-all hover:shadow-md ${activeStream.id === stream.id ? "border-brand bg-brand/5 ring-2 ring-brand/30" : "border-border bg-card hover:border-brand/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-video rounded-xl overflow-hidden bg-black mb-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: stream.thumb,
											alt: stream.title,
											className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105 opacity-85"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute top-2 left-2 inline-flex items-center gap-1 rounded-md bg-red-600 px-2 py-0.5 text-[10px] font-bold uppercase text-white shadow",
											children: "Live"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "absolute bottom-2 right-2 rounded-md bg-black/70 px-2 py-0.5 text-[10px] font-semibold text-white",
											children: [stream.viewers, " viewers"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand text-white font-bold text-xs",
										children: stream.initials
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-xs font-bold text-foreground line-clamp-2 group-hover:text-brand transition-colors",
												children: stream.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-muted-foreground mt-0.5 truncate",
												children: stream.streamer
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground/80",
												children: stream.category
											})
										]
									})]
								})]
							}, stream.id))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
//#endregion
export { LivePage as component };
