import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, l as useAuth, r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useSearch, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Ht as Clock, Kt as CircleCheck, Ot as FileImage, Yt as ChevronRight, et as Megaphone, lt as Layers, mt as Image, o as Video, un as ArrowLeft, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as recordNewVideoUpload, _ as VIDEO_CATEGORIES, m as getUserWallet, o as recordNewImageUpload, y as fetchUploadedVideos } from "./router-vsnEDfJA.mjs";
import { initiateAdsPromotionPayment, initiatePremiumVideoPayment } from "./razorpay-service-Cd_wwC5p.mjs";
import { t as Footer } from "./Footer-DiXczCHA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/upload-BsJYdBDx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UploadStudioPage() {
	const search = useSearch({ from: "/upload" });
	const navigate = useNavigate();
	const { user, profile, dbUser } = useAuth();
	const activeMode = search.mode || null;
	const initialFormat = search.format || "short";
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const refreshWallet = (0, import_react.useCallback)(() => {
		getUserWallet(userId).then(setWallet).catch(console.error);
	}, [userId]);
	(0, import_react.useEffect)(() => {
		refreshWallet();
	}, [refreshWallet]);
	const setMode = (mode, format) => {
		navigate({
			to: "/upload",
			search: mode ? {
				mode,
				...format ? { format } : {}
			} : {}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground antialiased selection:bg-brand selection:text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground active:scale-95",
							title: "Return to Feed",
							"aria-label": "Back to home",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 32 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden rounded-full border border-brand/30 bg-brand/10 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider text-brand sm:inline-flex",
								children: "Creator Studio"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							activeMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMode(null),
								className: "hidden items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-xs font-semibold text-foreground transition hover:bg-secondary sm:inline-flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-3.5 w-3.5" }), "All 4 Upload Options"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/wallet-balance",
								className: "hidden items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold text-emerald-400 sm:inline-flex",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-emerald-400 animate-pulse" }),
									"Wallet: ₹",
									wallet ? wallet.balance.toFixed(2) : "4,280.50"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, { showLabelsOnWide: false }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/dashboard",
								className: "rounded-full border border-border bg-secondary/40 px-3.5 py-1.5 text-xs font-semibold text-foreground transition hover:bg-secondary",
								children: "Dashboard"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10 pb-28 lg:pb-16",
				children: [!activeMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FourOptionsSelectionView, { onSelect: setMode }) : activeMode === "free" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreeVideoUploadView, {
					initialFormat,
					onBack: () => setMode(null),
					onUploaded: refreshWallet
				}) : activeMode === "premium" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumVideoUploadView, {
					initialFormat,
					onBack: () => setMode(null),
					onUploaded: refreshWallet
				}) : activeMode === "ad_promotion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdPromotionUploadView, {
					onBack: () => setMode(null),
					onUploaded: refreshWallet
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploadView, { onBack: () => setMode(null) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
function FourOptionsSelectionView({ onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-secondary/80 via-card to-background p-6 sm:p-10 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-brand/10 blur-3xl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "pointer-events-none absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-amber-500/10 blur-3xl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-3 py-1 text-xs font-bold text-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), "FaceTube Publishing Studio"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 text-2xl font-black tracking-tight sm:text-4xl text-foreground",
							children: "Select Upload Option"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base",
							children: "Choose from the four dedicated publishing pathways below. Publish free videos with ₹0 fee, monetized premium content with ₹6 verified share, launch targeted Ad Promotion, or upload image assets."
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-sky-500/30 bg-gradient-to-b from-sky-500/10 via-card to-card p-6 shadow-card hover:border-sky-500/60 hover:shadow-lg transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30 shadow-inner",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "h-6 w-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-sky-500/40 bg-sky-500/15 px-3 py-1 text-xs font-black uppercase text-sky-400",
									children: "Free · ₹0"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold uppercase tracking-wider text-sky-400",
									children: "Option 1"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl font-black text-foreground group-hover:text-sky-400 transition-colors",
									children: "Free"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground leading-relaxed",
									children: "Standard public video uploads. Zero upload fee (₹0) and no payment required."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/80 bg-background/60 p-3 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-bold text-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5 text-sky-400" }), "Supported Formats:"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 gap-1.5 text-xs font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelect("free", "short"),
										className: "rounded-xl border border-sky-500/30 bg-sky-500/10 px-2.5 py-1.5 text-left text-sky-300 hover:bg-sky-500/20 transition flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Free Short Video" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelect("free", "long"),
										className: "rounded-xl border border-sky-500/30 bg-sky-500/10 px-2.5 py-1.5 text-left text-sky-300 hover:bg-sky-500/20 transition flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Free Long Video" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelect("free", "short"),
							className: "w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-sky-600 px-4 py-3 text-xs font-bold text-white shadow-sm hover:bg-sky-500 transition active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Upload Free (₹0)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-amber-500/40 bg-gradient-to-b from-amber-500/10 via-card to-card p-6 shadow-card hover:border-amber-500/70 hover:shadow-lg transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-inner",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-6 w-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-amber-500/40 bg-amber-500/15 px-3 py-1 text-xs font-black uppercase text-amber-400",
									children: "Premium · ₹6"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold uppercase tracking-wider text-amber-400",
									children: "Option 2"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl font-black text-foreground group-hover:text-amber-400 transition-colors",
									children: "Premium"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground leading-relaxed",
									children: "₹6 verified payment unlocking Referral Commission (₹1) and Global Pool (₹3)."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/80 bg-background/60 p-3 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-bold text-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5 text-amber-400" }), "Supported Formats:"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 gap-1.5 text-xs font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelect("premium", "short"),
										className: "rounded-xl border border-amber-500/30 bg-amber-500/10 px-2.5 py-1.5 text-left text-amber-300 hover:bg-amber-500/20 transition flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Premium Short Video" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelect("premium", "long"),
										className: "rounded-xl border border-amber-500/30 bg-amber-500/10 px-2.5 py-1.5 text-left text-amber-300 hover:bg-amber-500/20 transition flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Premium Long Video" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelect("premium", "short"),
							className: "w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-amber-600 px-4 py-3 text-xs font-bold text-white shadow-sm hover:bg-amber-500 transition active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Upload Premium (₹6)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-emerald-500/30 bg-gradient-to-b from-emerald-500/10 via-card to-card p-6 shadow-card hover:border-emerald-500/60 hover:shadow-lg transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-inner",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "h-6 w-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-emerald-500/40 bg-emerald-500/15 px-3 py-1 text-xs font-black uppercase text-emerald-400",
									children: "Ad Promotion"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold uppercase tracking-wider text-emerald-400",
									children: "Option 3"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl font-black text-foreground group-hover:text-emerald-400 transition-colors",
									children: "Ad Promotion"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground leading-relaxed",
									children: "Targeted algorithmic boost for Short or Long videos. Verified payment campaign."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/80 bg-background/60 p-3 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-bold text-foreground flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Configured Plans:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-emerald-400 font-mono",
										children: "10% Sponsor"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-1.5 text-[11px] font-semibold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-lg bg-emerald-500/10 px-2 py-1 text-emerald-300",
											children: "7 Days = ₹100"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-lg bg-emerald-500/10 px-2 py-1 text-emerald-300",
											children: "15 Days = ₹200"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-lg bg-emerald-500/10 px-2 py-1 text-emerald-300",
											children: "1 Month = ₹300"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-lg bg-emerald-500/10 px-2 py-1 text-emerald-300",
											children: "1 Year = ₹30,000"
										})
									]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelect("ad_promotion"),
							className: "w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-4 py-3 text-xs font-bold text-white shadow-sm hover:bg-emerald-500 transition active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ad Promotion" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-teal-500/30 bg-gradient-to-b from-teal-500/10 via-card to-card p-6 shadow-card hover:border-teal-500/60 hover:shadow-lg transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 shadow-inner",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "h-6 w-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-teal-500/40 bg-teal-500/15 px-3 py-1 text-xs font-black uppercase text-teal-400",
									children: "Image Upload"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold uppercase tracking-wider text-teal-400",
									children: "Option 4"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl font-black text-foreground group-hover:text-teal-400 transition-colors",
									children: "Image Upload"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground leading-relaxed",
									children: "Upload image assets independently: thumbnails, channel graphics, and photo posts."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/80 bg-background/60 p-3 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] font-bold text-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5 text-teal-400" }), "Supported Formats:"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-1.5 text-xs font-mono font-semibold",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-lg bg-teal-500/10 px-2 py-0.5 text-teal-300",
												children: "JPG / JPEG"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-lg bg-teal-500/10 px-2 py-0.5 text-teal-300",
												children: "PNG"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-lg bg-teal-500/10 px-2 py-0.5 text-teal-300",
												children: "WEBP"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground",
										children: "Appears in community stream after every 5 videos."
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelect("image"),
							className: "w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-teal-600 px-4 py-3 text-xs font-bold text-white shadow-sm hover:bg-teal-500 transition active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Upload Image" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					})]
				})
			]
		})]
	});
}
function FreeVideoUploadView({ initialFormat, onBack, onUploaded }) {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const creatorName = profile?.name || dbUser?.name || user?.user_metadata?.full_name || "Alex Rivera";
	const [format, setFormat] = (0, import_react.useState)(initialFormat);
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Coding");
	const [videoFile, setVideoFile] = (0, import_react.useState)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [uploadSuccess, setUploadSuccess] = (0, import_react.useState)(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!title.trim()) {
			toast.error("Please enter a video title.");
			return;
		}
		setUploading(true);
		try {
			await recordNewVideoUpload({
				userId,
				creatorName,
				title: title.trim(),
				description: description.trim(),
				videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
				thumbnailUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=60",
				videoType: "free",
				contentType: format,
				category,
				duration: format === "short" ? "0:45" : "14:20",
				paymentStatus: "not_required",
				paymentAmount: 0
			});
			setUploadSuccess(true);
			toast.success(`🎉 Free ${format === "short" ? "Short" : "Long"} Video uploaded successfully! Zero fee (₹0).`);
			onUploaded?.();
		} catch (err) {
			toast.error("Failed to upload video.");
		} finally {
			setUploading(false);
		}
	};
	if (uploadSuccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl text-center py-12 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 mx-auto place-items-center rounded-full bg-sky-500/20 text-sky-400",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-10 w-10" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-black text-foreground",
				children: "Free Video Published!"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					"Your ",
					format === "short" ? "Short" : "Long",
					" Video \"",
					title,
					"\" is live for ₹0 with no payment."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setTitle("");
						setDescription("");
						setVideoFile(null);
						setUploadSuccess(false);
					},
					className: "rounded-xl bg-sky-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-sky-500 transition",
					children: "Upload Another Free Video"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/free-videos",
					className: "rounded-xl bg-secondary px-6 py-2.5 text-xs font-bold text-foreground hover:bg-secondary/80 transition",
					children: "View Free Videos"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "grid h-9 w-9 place-items-center rounded-full border border-border bg-secondary/60 text-muted-foreground hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-bold uppercase tracking-wider text-sky-400",
					children: "Option 1 · Zero Fee"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-black text-foreground",
					children: "Free Video Upload"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-sky-500/30 bg-sky-500/10 px-3 py-1 text-xs font-bold text-sky-400",
				children: "Fee: ₹0 (No Payment Required)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-4 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold text-foreground uppercase tracking-wide",
						children: ["Select Video Format ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-brand",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("short"),
							className: `rounded-xl border p-3 text-left transition ${format === "short" ? "border-sky-500 bg-sky-500/10 ring-1 ring-sky-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Free Short Video"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Vertical 9:16 format under 60 seconds"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("long"),
							className: `rounded-xl border p-3 text-left transition ${format === "long" ? "border-sky-500 bg-sky-500/10 ring-1 ring-sky-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Free Long Video"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Horizontal 16:9 standard video"
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Video Title ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: "e.g. 10 Coding Shortcuts Every React Dev Must Know",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-sky-500 focus:outline-none",
							required: true
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Video Category ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-sky-500 focus:outline-none",
							children: VIDEO_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: cat,
								children: cat
							}, cat))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 3,
							value: description,
							onChange: (e) => setDescription(e.target.value),
							placeholder: "Provide a detailed description of your video content...",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-sky-500 focus:outline-none"
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pt-4 border-t border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "rounded-xl border border-border bg-secondary/40 px-6 py-2.5 text-xs font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: uploading,
						className: "rounded-xl bg-sky-600 px-8 py-3 text-xs font-bold text-white hover:bg-sky-500 transition shadow-sm disabled:opacity-50",
						children: uploading ? "Publishing Video..." : `Publish Free Video (₹0)`
					})]
				})
			]
		})]
	});
}
function PremiumVideoUploadView({ initialFormat, onBack, onUploaded }) {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const creatorName = profile?.name || dbUser?.name || user?.user_metadata?.full_name || "Alex Rivera";
	const referrerId = profile?.referral_code || dbUser?.referral_code || "FT102857";
	const [format, setFormat] = (0, import_react.useState)(initialFormat);
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Coding");
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [uploadSuccess, setUploadSuccess] = (0, import_react.useState)(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!title.trim()) {
			toast.error("Please enter a video title.");
			return;
		}
		setUploading(true);
		try {
			const vidId = `vid-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
			await initiatePremiumVideoPayment({
				uploaderUserId: userId,
				uploaderName: creatorName,
				userEmail: user?.email || "creator@facetube.app",
				videoId: vidId,
				videoTitle: title.trim(),
				videoType: "premium",
				contentType: format,
				directReferrerId: referrerId,
				onSuccess: async (paymentId) => {
					await recordNewVideoUpload({
						id: vidId,
						userId,
						creatorName,
						title: title.trim(),
						description: description.trim(),
						videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
						thumbnailUrl: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&auto=format&fit=crop&q=60",
						videoType: "premium",
						contentType: format,
						category,
						duration: format === "short" ? "0:58" : "22:15",
						paymentStatus: "paid",
						paymentId,
						paymentAmount: 6
					});
					setUploading(false);
					setUploadSuccess(true);
					toast.success(`🎉 Premium ${format === "short" ? "Short" : "Long"} Video uploaded! ₹6 payment verified.`);
					onUploaded?.();
				},
				onFailure: (err) => {
					setUploading(false);
					toast.error(err || "Payment failed.");
				},
				onCancel: () => {
					setUploading(false);
					toast.info("Payment cancelled.");
				}
			});
		} catch (err) {
			setUploading(false);
			toast.error("Failed to initiate premium payment.");
		}
	};
	if (uploadSuccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl text-center py-12 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 mx-auto place-items-center rounded-full bg-amber-500/20 text-amber-400",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-10 w-10" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-black text-foreground",
				children: "Premium Video Published!"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Payment of ₹6 was verified. Referral commission (₹1) and Global Income Pool (₹3) credited."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setTitle("");
						setDescription("");
						setUploadSuccess(false);
					},
					className: "rounded-xl bg-amber-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-amber-500 transition",
					children: "Upload Another Premium Video"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/premium-videos",
					className: "rounded-xl bg-secondary px-6 py-2.5 text-xs font-bold text-foreground hover:bg-secondary/80 transition",
					children: "View Premium Videos"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "grid h-9 w-9 place-items-center rounded-full border border-border bg-secondary/60 text-muted-foreground hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-bold uppercase tracking-wider text-amber-400",
					children: "Option 2 · Monetized Video"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-black text-foreground",
					children: "Premium Video Upload"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-xs font-bold text-amber-400",
				children: "Fee: ₹6 (Razorpay Verified)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-4 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold text-foreground uppercase tracking-wide",
						children: ["Select Video Format ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-brand",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("short"),
							className: `rounded-xl border p-3 text-left transition ${format === "short" ? "border-amber-500 bg-amber-500/10 ring-1 ring-amber-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Premium Short Video"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Monetized short-form under 60 seconds"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("long"),
							className: `rounded-xl border p-3 text-left transition ${format === "long" ? "border-amber-500 bg-amber-500/10 ring-1 ring-amber-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Premium Long Video"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Monetized long-form standard video"
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Video Title ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: "e.g. Pro Monetization Secrets: High-CPM Niches Explained",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-amber-500 focus:outline-none",
							required: true
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Video Category ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-amber-500 focus:outline-none",
							children: VIDEO_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: cat,
								children: cat
							}, cat))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 3,
							value: description,
							onChange: (e) => setDescription(e.target.value),
							placeholder: "Provide a detailed description of your monetized content...",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-amber-500 focus:outline-none"
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 text-xs space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-bold text-amber-400 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }), " ₹6 Premium Fee Allocation:"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• Direct Referral: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "₹1"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• Global Pool: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "₹3"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• Platform Fee: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "₹1"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• Taxes/GST: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "₹1"
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pt-4 border-t border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "rounded-xl border border-border bg-secondary/40 px-6 py-2.5 text-xs font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: uploading,
						className: "rounded-xl bg-amber-600 px-8 py-3 text-xs font-bold text-white hover:bg-amber-500 transition shadow-sm disabled:opacity-50",
						children: uploading ? "Connecting Gateway..." : `Pay ₹6 & Publish Premium Video`
					})]
				})
			]
		})]
	});
}
function AdPromotionUploadView({ onBack, onUploaded }) {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const creatorName = profile?.name || dbUser?.name || user?.user_metadata?.full_name || "Alex Rivera";
	const referrerId = profile?.referral_code || dbUser?.referral_code || "FT102857";
	const DURATION_PLANS = [
		{
			id: "7_days",
			name: "7_days",
			label: "7 Days",
			days: 7,
			price: 100,
			rateText: "₹14.28/day"
		},
		{
			id: "15_days",
			name: "15_days",
			label: "15 Days",
			days: 15,
			price: 200,
			rateText: "₹13.33/day"
		},
		{
			id: "1_month",
			name: "1_month",
			label: "1 Month",
			days: 30,
			price: 300,
			rateText: "₹10.00/day"
		},
		{
			id: "1_year",
			name: "1_year",
			label: "1 Year",
			days: 365,
			price: 3e4,
			rateText: "₹82.19/day"
		}
	];
	const [format, setFormat] = (0, import_react.useState)("short");
	const [selectedPlanId, setSelectedPlanId] = (0, import_react.useState)("7_days");
	const [availableVideos, setAvailableVideos] = (0, import_react.useState)([]);
	const [selectedVideoId, setSelectedVideoId] = (0, import_react.useState)("");
	const [isProcessing, setIsProcessing] = (0, import_react.useState)(false);
	const [activated, setActivated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		fetchUploadedVideos(userId).then((vids) => {
			setAvailableVideos(vids);
			if (vids.length > 0) setSelectedVideoId(vids[0].id);
		});
	}, [userId]);
	const currentPlan = DURATION_PLANS.find((p) => p.id === selectedPlanId) || DURATION_PLANS[0];
	const handleLaunch = async (e) => {
		e.preventDefault();
		if (!selectedVideoId && availableVideos.length === 0) {
			toast.error("Please upload a video first before promoting.");
			return;
		}
		setIsProcessing(true);
		await initiateAdsPromotionPayment({
			userId,
			userName: creatorName,
			userEmail: user?.email || "creator@facetube.app",
			videoId: selectedVideoId || "vid-custom",
			planName: currentPlan.name,
			durationDays: currentPlan.days,
			price: currentPlan.price,
			directReferrerId: referrerId,
			onSuccess: () => {
				setIsProcessing(false);
				setActivated(true);
				toast.success(`🎉 Ad Promotion active for ${currentPlan.label}! Payment of ₹${currentPlan.price.toLocaleString("en-IN")} verified.`);
				onUploaded?.();
			},
			onFailure: (err) => {
				setIsProcessing(false);
				toast.error(err || "Ad Promotion payment failed.");
			},
			onCancel: () => {
				setIsProcessing(false);
				toast.info("Payment cancelled.");
			}
		});
	};
	if (activated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl text-center py-12 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 mx-auto place-items-center rounded-full bg-emerald-500/20 text-emerald-400",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-10 w-10" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-black text-foreground",
				children: "🎉 Ad Promotion Campaign Active!"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					"Payment of ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["₹", currentPlan.price.toLocaleString("en-IN")] }),
					" was verified. Your video is now featured for ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: currentPlan.label }),
					"."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/ads-promotions",
					className: "rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 transition",
					children: "View Active Promotions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					className: "rounded-xl bg-secondary px-6 py-2.5 text-xs font-bold text-foreground hover:bg-secondary/80 transition",
					children: "Go to Dashboard"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "grid h-9 w-9 place-items-center rounded-full border border-border bg-secondary/60 text-muted-foreground hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-bold uppercase tracking-wider text-emerald-400",
					children: "Option 3 · Audience Growth"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-black text-foreground",
					children: "Ad Promotion"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-400",
				children: "Verified Payment Required"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleLaunch,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-4 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold text-foreground uppercase tracking-wide",
						children: ["Select Video Format to Promote ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-brand",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("short"),
							className: `rounded-xl border p-3 text-left transition ${format === "short" ? "border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Short Video Promotion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Boost viral short-form video in feed"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFormat("long"),
							className: `rounded-xl border p-3 text-left transition ${format === "long" ? "border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/50" : "border-border bg-secondary/40 hover:bg-secondary/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: "Long Video Promotion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground mt-0.5",
								children: "Featured placement for standard long videos"
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold text-foreground uppercase tracking-wide",
						children: ["Select Video From Your Channel ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-brand",
							children: "*"
						})]
					}), availableVideos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
						children: availableVideos.map((vid) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedVideoId(vid.id),
							className: `flex items-center gap-3 rounded-xl border p-3 text-left transition ${selectedVideoId === vid.id ? "border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/40" : "border-border bg-secondary/30 hover:bg-secondary/60"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: vid.thumbnailUrl,
								alt: vid.title,
								className: "h-12 w-20 rounded-lg object-cover shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold text-foreground truncate",
									children: vid.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-muted-foreground mt-1 capitalize font-mono",
									children: [
										vid.videoType,
										" · ",
										vid.contentType
									]
								})]
							})]
						}, vid.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "No videos uploaded yet. A promotional placeholder campaign will be configured."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold text-foreground uppercase tracking-wide",
						children: ["Select Ad Promotion Duration & Pricing ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-brand",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
						children: DURATION_PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedPlanId(plan.id),
							className: `rounded-2xl border p-4 text-left transition ${selectedPlanId === plan.id ? "border-emerald-500 bg-emerald-500/10 ring-1 ring-emerald-500/50 shadow-sm" : "border-border bg-secondary/30 hover:bg-secondary/60"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-muted-foreground",
										children: plan.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-emerald-400" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 text-xl font-black text-foreground",
									children: ["₹", plan.price.toLocaleString("en-IN")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-0.5 text-[11px] text-muted-foreground font-mono",
									children: plan.rateText
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 text-[10px] font-semibold text-emerald-400",
									children: "Direct Referrer earns 10%"
								})
							]
						}, plan.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pt-4 border-t border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "rounded-xl border border-border bg-secondary/40 px-6 py-2.5 text-xs font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: isProcessing,
						className: "rounded-xl bg-emerald-600 px-8 py-3 text-xs font-bold text-white hover:bg-emerald-500 transition shadow-sm disabled:opacity-50",
						children: isProcessing ? "Connecting Gateway..." : `Launch Ad Promotion (₹${currentPlan.price.toLocaleString("en-IN")})`
					})]
				})
			]
		})]
	});
}
function ImageUploadView({ onBack }) {
	const { user, profile, dbUser } = useAuth();
	const userId = profile?.user_id || dbUser?.user_id || user?.email?.split("@")[0] || "FT483921";
	const creatorName = profile?.name || dbUser?.name || user?.user_metadata?.full_name || "Alex Rivera";
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Coding");
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [previewUrl, setPreviewUrl] = (0, import_react.useState)("");
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [uploadedImage, setUploadedImage] = (0, import_react.useState)(null);
	const fileInputRef = (0, import_react.useRef)(null);
	const handleFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(file.type)) {
			toast.error("Unsupported image format. Please select a JPG, JPEG, PNG, or WEBP image.");
			return;
		}
		setImageFile(file);
		const objectUrl = URL.createObjectURL(file);
		setPreviewUrl(objectUrl);
		if (!title) setTitle(file.name.replace(/\.[^/.]+$/, ""));
	};
	const handleDrop = (e) => {
		e.preventDefault();
		const file = e.dataTransfer.files?.[0];
		if (!file) return;
		if (![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(file.type)) {
			toast.error("Unsupported image format. Please drop a JPG, JPEG, PNG, or WEBP image.");
			return;
		}
		setImageFile(file);
		const objectUrl = URL.createObjectURL(file);
		setPreviewUrl(objectUrl);
		if (!title) setTitle(file.name.replace(/\.[^/.]+$/, ""));
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!title.trim()) {
			toast.error("Please enter an image title.");
			return;
		}
		setUploading(true);
		try {
			let format = "jpg";
			if (imageFile) {
				if (imageFile.type === "image/png") format = "png";
				else if (imageFile.type === "image/webp") format = "webp";
				else if (imageFile.name.endsWith(".jpeg")) format = "jpeg";
			}
			const imageUrl = previewUrl || "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80";
			const fileSize = imageFile ? `${(imageFile.size / 1048576).toFixed(2)} MB` : "1.2 MB";
			const created = await recordNewImageUpload({
				userId,
				creatorName,
				title: title.trim(),
				description: description.trim(),
				imageUrl,
				format,
				fileSize,
				category
			});
			setUploadedImage(created);
			toast.success("🎉 Image uploaded successfully! Saved to your media library.");
		} catch (err) {
			toast.error("Failed to upload image.");
		} finally {
			setUploading(false);
		}
	};
	if (uploadedImage) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl text-center py-12 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 mx-auto place-items-center rounded-full bg-teal-500/20 text-teal-400",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-10 w-10" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-black text-foreground",
				children: "Image Uploaded Successfully!"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					"\"",
					uploadedImage.title,
					"\" has been recorded in your FaceTube asset gallery. It will appear in the stream feed after every 5 videos."
				]
			})] }),
			uploadedImage.imageUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-sm overflow-hidden rounded-2xl border border-border shadow-card bg-secondary/30",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: uploadedImage.imageUrl,
					alt: uploadedImage.title,
					className: "h-48 w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold text-foreground truncate",
						children: uploadedImage.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[10px] text-muted-foreground mt-0.5 font-mono uppercase",
						children: [
							uploadedImage.format,
							" · ",
							uploadedImage.fileSize,
							" · ",
							uploadedImage.category
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-3 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setTitle("");
						setDescription("");
						setImageFile(null);
						setPreviewUrl("");
						setUploadedImage(null);
					},
					className: "rounded-xl bg-teal-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-teal-500 transition",
					children: "Upload Another Image"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/images-uploaded",
					className: "rounded-xl bg-secondary px-6 py-2.5 text-xs font-bold text-foreground hover:bg-secondary/80 transition",
					children: "View Image Library"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "grid h-9 w-9 place-items-center rounded-full border border-border bg-secondary/60 text-muted-foreground hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-bold uppercase tracking-wider text-teal-400",
					children: "Option 4 · Asset Studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-black text-foreground",
					children: "Image Upload"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-teal-500/30 bg-teal-500/10 px-3 py-1 text-xs font-bold text-teal-400",
				children: "Formats: JPG, PNG, WEBP"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleSubmit,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onDragOver: (e) => e.preventDefault(),
					onDrop: handleDrop,
					onClick: () => fileInputRef.current?.click(),
					className: "group relative cursor-pointer rounded-3xl border-2 border-dashed border-border bg-card p-8 text-center transition hover:border-teal-500/60 hover:bg-teal-500/5 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileInputRef,
						type: "file",
						accept: ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp",
						onChange: handleFileChange,
						className: "hidden"
					}), previewUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: previewUrl,
							alt: "Selected Image Preview",
							className: "mx-auto max-h-64 rounded-2xl object-contain border border-border shadow-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold text-teal-400",
							children: "Click or drop another file to change image"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileImage, { className: "h-7 w-7" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-bold text-foreground",
							children: "Click to select or drag and drop image here"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "Supports common formats: JPG, JPEG, PNG, WEBP (Up to 25 MB)"
						})] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Image Title ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: "e.g. Masterclass 4K Artwork / Community Photo",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-teal-500 focus:outline-none",
							required: true
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: ["Category ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brand",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-teal-500 focus:outline-none",
							children: VIDEO_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: cat,
								children: cat
							}, cat))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-foreground uppercase tracking-wide mb-1.5",
							children: "Description / Caption"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 3,
							value: description,
							onChange: (e) => setDescription(e.target.value),
							placeholder: "Share thoughts, credits, or context for this image...",
							className: "w-full rounded-xl border border-border bg-secondary/30 px-4 py-2.5 text-sm text-foreground focus:border-teal-500 focus:outline-none"
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pt-4 border-t border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "rounded-xl border border-border bg-secondary/40 px-6 py-2.5 text-xs font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: uploading,
						className: "rounded-xl bg-teal-600 px-8 py-3 text-xs font-bold text-white hover:bg-teal-500 transition shadow-sm disabled:opacity-50",
						children: uploading ? "Saving Image..." : "Upload Image"
					})]
				})
			]
		})]
	});
}
//#endregion
export { UploadStudioPage as component };
