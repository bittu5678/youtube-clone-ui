import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Ft as DollarSign, Nt as Earth, T as Share2, dn as ArrowDownToLine, ln as ArrowRight, p as Tv, r as Wallet } from "../_libs/lucide-react.mjs";
import { s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
import { t as DashboardSummaryCards } from "./DashboardSummaryCards-DipxqPw2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/income-iZMLiKz1.js
var import_jsx_runtime = require_jsx_runtime();
var incomeStreams = [
	{
		title: "Referral Income",
		desc: "10% direct sponsor rewards from creator subscriptions and tips",
		balance: "$1,079.50",
		badge: "10% Direct",
		icon: DollarSign,
		color: "text-emerald-400 bg-emerald-500/10",
		link: "/referral-income"
	},
	{
		title: "Global Income",
		desc: "Worldwide platform revenue pool distribution for Diamond ranks",
		balance: "$2,450.00",
		badge: "Global Pool",
		icon: Earth,
		color: "text-cyan-400 bg-cyan-500/10",
		link: "/global-income"
	},
	{
		title: "AdSense Income",
		desc: "70% video player pre-roll, mid-roll, and display ad revenue",
		balance: "$1,890.20",
		badge: "70% Split",
		icon: Tv,
		color: "text-yellow-400 bg-yellow-500/10",
		link: "/adsense-income"
	},
	{
		title: "Affiliate Income",
		desc: "Product recommendations, gear commissions, and course referrals",
		balance: "$940.80",
		badge: "86 Sales",
		icon: Share2,
		color: "text-indigo-400 bg-indigo-500/10",
		link: "/affiliate-income"
	},
	{
		title: "Wallet Balance",
		desc: "Current aggregated balance ready for immediate transfer or withdrawal",
		balance: "$4,280.50",
		badge: "Available",
		icon: Wallet,
		color: "text-emerald-400 bg-emerald-500/10",
		link: "/wallet-balance"
	},
	{
		title: "Withdrawal Balance",
		desc: "History of completed bank ACH, PayPal, and crypto disbursements",
		balance: "$3,150.00",
		badge: "Processed",
		icon: ArrowDownToLine,
		color: "text-orange-400 bg-orange-500/10",
		link: "/withdrawal-balance"
	}
];
function IncomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl",
						children: "Income Section"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Manage all 6 creator revenue streams, check balances, and withdraw earnings"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/wallet-balance",
					className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand px-4 py-2 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3.5 w-3.5" }), "Withdrawal Balance"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardSummaryCards, { filterCategory: "income" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-extrabold text-foreground",
					children: "Revenue Streams & Payouts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
					children: incomeStreams.map((stream) => {
						const Icon = stream.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: stream.link,
							className: "group block rounded-2xl border border-border bg-card p-5 shadow-card transition-all duration-200 hover:-translate-y-1 hover:border-brand/40 hover:shadow-lift",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `grid h-11 w-11 place-items-center rounded-xl transition-transform group-hover:scale-105 ${stream.color}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full border border-border bg-secondary px-2.5 py-0.5 text-[11px] font-bold text-foreground",
										children: [stream.badge, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3 transition-transform group-hover:translate-x-0.5" })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-extrabold text-foreground group-hover:text-brand transition-colors",
									children: stream.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1 mb-3 leading-relaxed line-clamp-2",
									children: stream.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-t border-border/60 pt-3 text-xs font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Balance / Volume:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground font-black text-sm",
										children: stream.balance
									})]
								})
							]
						}, stream.title);
					})
				})]
			})
		]
	}) });
}
//#endregion
export { IncomePage as component };
