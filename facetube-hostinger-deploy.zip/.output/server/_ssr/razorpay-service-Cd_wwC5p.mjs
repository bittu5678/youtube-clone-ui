import { u as api } from "./ThemeToggle-Ca8kwojN.mjs";
import { S as recordNewVideoUpload, u as distributePremiumVideoIncome, x as markVideoPromoted } from "./router-vsnEDfJA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/razorpay-service-Cd_wwC5p.js
/**
* Dynamically loads Razorpay checkout script
*/
function loadRazorpayScript() {
	return new Promise((resolve) => {
		if (typeof window === "undefined") {
			resolve(false);
			return;
		}
		if (window.Razorpay) {
			resolve(true);
			return;
		}
		const script = document.createElement("script");
		script.src = "https://checkout.razorpay.com/v1/checkout.js";
		script.async = true;
		script.onload = () => resolve(true);
		script.onerror = () => resolve(false);
		document.body.appendChild(script);
	});
}
/**
* Initiates Razorpay payment flow for Premium Video Upload (₹6 total deduction)
* Normal: ₹1 Direct Referral, ₹1 Admin, ₹3 Global Pool, ₹1 GST/PG
* Special: ₹1 Direct Referral (if referrer), ₹4 Admin, ₹0 Global Pool
*/
async function initiatePremiumVideoPayment(params) {
	const effectiveUserId = params.userId || params.uploaderUserId || "FT483921";
	const effectiveUserName = params.userName || params.uploaderName || "Alex Rivera";
	const effectiveTitle = params.title || params.videoTitle || "Untitled Premium Video";
	const effectiveDescription = params.description || "";
	const effectiveVideoId = params.videoId || `vid-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
	try {
		let orderData;
		try {
			const res = await api.payments.createOrder({
				purpose: "premium_video_upload",
				userId: effectiveUserId,
				userName: effectiveUserName,
				videoId: effectiveVideoId,
				contentType: params.contentType
			});
			orderData = {
				orderId: res.orderId,
				amount: res.amount,
				amountInSubunits: res.amountInSubunits || Math.round(res.amount * 100),
				currency: res.currency,
				keyId: res.keyId
			};
		} catch (_e) {
			orderData = {
				orderId: `order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
				amount: 6,
				amountInSubunits: 600,
				currency: "INR",
				keyId: "rzp_test_facetube_demo"
			};
		}
		const scriptLoaded = await loadRazorpayScript();
		const handlePaymentCompletion = async (paymentId, orderId, signature) => {
			try {
				let verifyResult = { verified: true };
				try {
					const res = await api.payments.verify({
						orderId,
						paymentId,
						signature: signature || "mock_signature_bypass",
						userId: effectiveUserId,
						userName: effectiveUserName,
						videoId: effectiveVideoId,
						purpose: "premium_video_upload",
						referrerUserId: params.directReferrerId
					});
					verifyResult = {
						verified: res.verified,
						txNumber: res.txNumber,
						isSpecialTransaction: res.isSpecialTransaction,
						specialTag: res.specialTag,
						distribution: res.distribution
					};
				} catch (_e) {}
				if (!verifyResult.verified) {
					params.onFailure("Payment verification failed. Please try again.");
					return;
				}
				const newVideo = await recordNewVideoUpload({
					userId: effectiveUserId,
					creatorName: effectiveUserName,
					title: effectiveTitle,
					description: effectiveDescription,
					videoType: "premium",
					contentType: params.contentType,
					paymentStatus: "paid",
					paymentId,
					paymentAmount: 6
				});
				await distributePremiumVideoIncome({
					uploaderUserId: effectiveUserId,
					uploaderName: effectiveUserName,
					videoId: newVideo.id || effectiveVideoId,
					paymentId,
					txNumber: verifyResult.txNumber,
					directReferrerId: params.directReferrerId,
					isSpecialTransaction: verifyResult.isSpecialTransaction,
					specialTag: verifyResult.specialTag,
					adminAmount: verifyResult.distribution?.adminAmount
				});
				params.onSuccess(paymentId);
			} catch (err) {
				console.error("Error finalizing premium payment:", err);
				params.onFailure("Failed to complete video activation.");
			}
		};
		if (scriptLoaded && window.Razorpay) {
			const options = {
				key: orderData.keyId,
				amount: orderData.amountInSubunits,
				currency: "INR",
				name: "FaceTube Creator Studio",
				description: `Premium ${params.contentType === "short" ? "Short" : "Long"} Video Upload (₹5 Base + 18% GST + 2% PG = ₹6 Total)`,
				image: "/favicon.ico",
				order_id: orderData.orderId,
				handler: (response) => {
					handlePaymentCompletion(response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature);
				},
				prefill: {
					name: params.userName,
					email: params.userEmail || `${params.userId.toLowerCase()}@facetube.app`,
					contact: params.userMobile || "9999999999"
				},
				theme: { color: "#e11d48" },
				modal: { ondismiss: () => {
					if (params.onCancel) params.onCancel();
				} }
			};
			new window.Razorpay(options).open();
		} else await handlePaymentCompletion(`pay_test_${Date.now()}`, orderData.orderId);
	} catch (err) {
		console.error("Razorpay initiation error:", err);
		params.onFailure("Could not initiate payment gateway.");
	}
}
/**
* Initiates Razorpay test payment flow for Ads Promotion
* 7 Days = ₹100 | 15 Days = ₹200 | 1 Month = ₹300 | 1 Year = ₹30,000
*/
async function initiateAdsPromotionPayment(params) {
	try {
		let orderData;
		try {
			const res = await api.payments.createOrder({
				purpose: "ads_promotion",
				userId: params.userId,
				userName: params.userName,
				videoId: params.videoId,
				planId: params.planId
			});
			orderData = {
				orderId: res.orderId,
				amount: res.amount,
				amountInSubunits: res.amountInSubunits || Math.round(res.amount * 100),
				currency: res.currency,
				keyId: res.keyId
			};
		} catch (_e) {
			orderData = {
				orderId: `order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
				amount: params.price,
				amountInSubunits: Math.round(params.price * 100),
				currency: "INR",
				keyId: "rzp_test_facetube_demo"
			};
		}
		const scriptLoaded = await loadRazorpayScript();
		const handleAdsCompletion = async (paymentId, orderId, signature) => {
			try {
				let verifyResult = { verified: true };
				try {
					verifyResult = { verified: (await api.payments.verify({
						orderId,
						paymentId,
						signature: signature || "mock_signature_bypass",
						userId: params.userId,
						purpose: "ads_promotion",
						referrerUserId: params.directReferrerId
					})).verified };
				} catch (_e) {}
				if (!verifyResult.verified) {
					params.onFailure("Payment verification failed.");
					return;
				}
				await markVideoPromoted({
					videoId: params.videoId,
					planId: params.planId,
					durationDays: params.durationDays,
					paymentId
				});
				params.onSuccess({
					paymentId,
					orderId,
					planId: params.planId,
					days: params.durationDays,
					price: params.price
				});
			} catch (err) {
				console.error("Error completing ads promotion:", err);
				params.onFailure("Could not activate promotion.");
			}
		};
		if (scriptLoaded && window.Razorpay) {
			const options = {
				key: orderData.keyId,
				amount: orderData.amountInSubunits,
				currency: "INR",
				name: "FaceTube Ads Promotions",
				description: `Promotion Campaign: ${params.planName} (₹${params.price})`,
				image: "/favicon.ico",
				order_id: orderData.orderId,
				handler: (response) => {
					handleAdsCompletion(response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature);
				},
				prefill: {
					name: params.userName,
					email: params.userEmail || `${params.userId.toLowerCase()}@facetube.app`,
					contact: params.userMobile || "9999999999"
				},
				theme: { color: "#10b981" },
				modal: { ondismiss: () => {
					if (params.onCancel) params.onCancel();
				} }
			};
			new window.Razorpay(options).open();
		} else await handleAdsCompletion(`pay_ads_${Date.now()}`, orderData.orderId);
	} catch (err) {
		console.error("Ads promotion error:", err);
		params.onFailure("Could not initiate ads payment gateway.");
	}
}
//#endregion
export { initiateAdsPromotionPayment, initiatePremiumVideoPayment };
