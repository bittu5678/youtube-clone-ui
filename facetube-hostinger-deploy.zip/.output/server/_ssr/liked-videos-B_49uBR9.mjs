import { o as __toESM } from "../_runtime.mjs";
import { l as useAuth } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { R as Play, _t as Heart, at as Lock, g as ThumbsUp, h as Trash2, x as Shuffle } from "../_libs/lucide-react.mjs";
import { T as allVideos, s as VideoHubLayout } from "./router-vsnEDfJA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/liked-videos-B_49uBR9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LikedVideosPage() {
	const { profile, user } = useAuth();
	const [likedList, setLikedList] = (0, import_react.useState)(allVideos.slice(2, 9));
	const handleUnlike = (id) => {
		setLikedList((prev) => prev.filter((v) => v.id !== id));
	};
	const username = profile?.username || user?.email?.split("@")[0] || "You";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoHubLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-6 sm:px-6 lg:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 lg:grid-cols-[360px_minmax(0,1fr)] gap-8 items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-20 rounded-3xl border border-border bg-gradient-to-b from-card to-background p-6 shadow-card space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative aspect-video w-full rounded-2xl overflow-hidden bg-gradient-to-br from-brand via-brand-dark to-black shadow-md flex items-center justify-center",
						children: likedList[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: likedList[0].thumb,
							alt: "Liked preview",
							className: "absolute inset-0 h-full w-full object-cover opacity-60"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 grid h-16 w-16 place-items-center rounded-full bg-brand text-white shadow-lift",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "h-8 w-8" })
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "h-12 w-12 text-white/50" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3 w-3" }), "Private Playlist"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-2xl font-extrabold text-foreground",
							children: "Liked Videos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground mt-1 font-medium",
							children: [
								username,
								" · ",
								likedList.length,
								" videos · Saved to your favorites"
							]
						})
					] }),
					likedList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$videoId",
							params: { videoId: likedList[0].id },
							className: "flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-brand px-5 py-2.5 text-xs font-bold text-white shadow-lift transition hover:bg-brand-dark active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-white" }), "Play All"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLikedList([...likedList].reverse()),
							className: "inline-flex items-center justify-center gap-2 rounded-full border border-border bg-secondary/80 px-4 py-2.5 text-xs font-bold text-foreground transition hover:bg-secondary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "h-4 w-4" }), "Shuffle"]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-bold text-foreground",
						children: "Favorites list"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [likedList.length, " items"]
					})]
				}), likedList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-16 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-16 w-16 place-items-center rounded-full bg-secondary text-muted-foreground mx-auto mb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-8 w-8" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-bold text-foreground",
							children: "No liked videos yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1",
							children: "Click the thumbs up button on any video to add it to this collection."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "mt-4 inline-block rounded-full bg-brand px-5 py-2 text-xs font-bold text-white shadow-sm",
							children: "Browse Videos"
						})
					]
				}) : likedList.map((video, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group flex items-center gap-3.5 p-2.5 rounded-2xl border border-transparent hover:border-border hover:bg-card transition",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-5 text-center text-xs font-bold text-muted-foreground",
							children: idx + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$videoId",
							params: { videoId: video.id },
							className: "relative shrink-0 w-36 sm:w-44 aspect-video rounded-xl overflow-hidden bg-black",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: video.thumb,
								alt: video.title,
								className: "h-full w-full object-cover transition group-hover:scale-105"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute bottom-1 right-1 rounded bg-black/80 px-1 py-0.5 text-[9px] font-bold text-white",
								children: video.duration
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/watch/$videoId",
								params: { videoId: video.id },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs sm:text-sm font-bold text-foreground line-clamp-2 group-hover:text-brand transition-colors",
									children: video.title
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground mt-1 truncate",
								children: [
									video.channel,
									" · ",
									video.views
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => handleUnlike(video.id),
							title: "Remove from liked videos",
							className: "shrink-0 p-2 rounded-full text-muted-foreground opacity-70 group-hover:opacity-100 hover:bg-secondary hover:text-red-500 transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, `liked-${video.id}`))]
			})]
		})
	}) });
}
//#endregion
export { LikedVideosPage as component };
