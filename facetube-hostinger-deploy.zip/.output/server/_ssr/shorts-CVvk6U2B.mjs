import { o as __toESM } from "../_runtime.mjs";
import { a as ThemeToggle, l as useAuth, r as Logo } from "./ThemeToggle-Ca8kwojN.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { D as Send, Jt as ChevronUp, K as Music2, O as Search, R as Play, T as Share2, V as Pause, X as MessageSquare, Zt as ChevronDown, _ as ThumbsDown, a as Volume2, g as ThumbsUp, i as VolumeX, n as X, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as BottomNav } from "./BottomNav-D75yrKNZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$9 } from "./router-vsnEDfJA.mjs";
import { t as SHORTS_LIST } from "./shorts-DrPnqhcl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shorts-CVvk6U2B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShortsPage() {
	const searchParams = Route$9.useSearch();
	const { user, profile } = useAuth();
	const initialIndex = searchParams.id ? Math.max(0, SHORTS_LIST.findIndex((s) => s.id === searchParams.id)) : 0;
	const [currentIndex, setCurrentIndex] = (0, import_react.useState)(initialIndex >= 0 ? initialIndex : 0);
	(0, import_react.useEffect)(() => {
		if (searchParams.id) {
			const idx = SHORTS_LIST.findIndex((s) => s.id === searchParams.id);
			if (idx !== -1) setCurrentIndex(idx);
		}
	}, [searchParams.id]);
	const [liked, setLiked] = (0, import_react.useState)({});
	const [disliked, setDisliked] = (0, import_react.useState)({});
	const [subscribed, setSubscribed] = (0, import_react.useState)({});
	const [isMuted, setIsMuted] = (0, import_react.useState)(true);
	const [isPlaying, setIsPlaying] = (0, import_react.useState)(true);
	const [commentsOpen, setCommentsOpen] = (0, import_react.useState)(false);
	const [newComment, setNewComment] = (0, import_react.useState)("");
	const [shortComments, setShortComments] = (0, import_react.useState)({ "s-1": [{
		id: "1",
		user: "Jordan Cole",
		text: "That transition at 0:05 was insane!",
		time: "2h ago"
	}, {
		id: "2",
		user: "Sara Connor",
		text: "Which lens did you use for this?",
		time: "4h ago"
	}] });
	const touchStartY = (0, import_react.useRef)(null);
	const activeShort = SHORTS_LIST[currentIndex] || SHORTS_LIST[0];
	const handleNext = () => {
		setCurrentIndex((prev) => (prev + 1) % SHORTS_LIST.length);
	};
	const handlePrev = () => {
		setCurrentIndex((prev) => (prev - 1 + SHORTS_LIST.length) % SHORTS_LIST.length);
	};
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if (e.key === "ArrowDown" || e.key === "j") {
				e.preventDefault();
				handleNext();
			} else if (e.key === "ArrowUp" || e.key === "k") {
				e.preventDefault();
				handlePrev();
			} else if (e.key === " ") {
				e.preventDefault();
				setIsPlaying((p) => !p);
			} else if (e.key === "m") setIsMuted((m) => !m);
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, []);
	const handleTouchStart = (e) => {
		touchStartY.current = e.touches[0].clientY;
	};
	const handleTouchEnd = (e) => {
		if (touchStartY.current === null) return;
		const deltaY = touchStartY.current - e.changedTouches[0].clientY;
		if (deltaY > 40) handleNext();
		else if (deltaY < -40) handlePrev();
		touchStartY.current = null;
	};
	const toggleLike = (id) => {
		setLiked((prev) => {
			const next = !prev[id];
			if (next) toast.success("Added to Liked Videos");
			return {
				...prev,
				[id]: next
			};
		});
		if (!liked[id] && disliked[id]) setDisliked((prev) => ({
			...prev,
			[id]: false
		}));
	};
	const toggleDislike = (id) => {
		setDisliked((prev) => ({
			...prev,
			[id]: !prev[id]
		}));
		if (!disliked[id] && liked[id]) setLiked((prev) => ({
			...prev,
			[id]: false
		}));
	};
	const toggleSubscribe = (handle) => {
		setSubscribed((prev) => {
			const next = !prev[handle];
			toast.success(next ? `Subscribed to ${handle}!` : `Unsubscribed from ${handle}`);
			return {
				...prev,
				[handle]: next
			};
		});
	};
	const handleAddComment = (e) => {
		e.preventDefault();
		if (!newComment.trim()) return;
		const authorName = profile?.full_name || user?.email?.split("@")[0] || "You";
		const newEntry = {
			id: String(Date.now()),
			user: authorName,
			text: newComment.trim(),
			time: "Just now"
		};
		setShortComments((prev) => ({
			...prev,
			[activeShort.id]: [newEntry, ...prev[activeShort.id] || []]
		}));
		setNewComment("");
		toast.success("Comment posted!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground flex flex-col antialiased selection:bg-brand selection:text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-red-500/10 px-2.5 py-0.5 text-[11px] font-extrabold uppercase tracking-wider text-red-500",
							children: "Shorts"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground",
							"aria-label": "Search FaceTube",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, { showLabelsOnWide: false })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 flex items-center justify-center p-2 sm:p-4 pb-24 md:pb-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-col md:flex-row items-center gap-4 max-w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onTouchStart: handleTouchStart,
						onTouchEnd: handleTouchEnd,
						className: "relative w-[340px] xs:w-[380px] sm:w-[420px] aspect-[9/16] max-h-[calc(100vh-160px)] rounded-3xl overflow-hidden bg-black shadow-2xl border border-border/70 flex flex-col justify-between select-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 z-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: activeShort.thumb,
									alt: activeShort.title,
									className: "h-full w-full object-cover opacity-80"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute inset-0 bg-gradient-to-t ${activeShort.aspectColor} via-black/30 to-black/70` })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 flex items-center justify-between p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full bg-black/60 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3 w-3 text-red-400" }),
											currentIndex + 1,
											" of ",
											SHORTS_LIST.length
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setIsMuted((m) => !m),
										className: "grid h-9 w-9 place-items-center rounded-full bg-black/60 text-white backdrop-blur-md transition hover:bg-black/80 active:scale-95",
										"aria-label": isMuted ? "Unmute sound" : "Mute sound",
										children: isMuted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setIsPlaying((p) => !p),
										className: "grid h-9 w-9 place-items-center rounded-full bg-black/60 text-white backdrop-blur-md transition hover:bg-black/80 active:scale-95",
										"aria-label": isPlaying ? "Pause" : "Play",
										children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative z-10 flex-1 cursor-pointer flex items-center justify-center",
								onClick: () => setIsPlaying((p) => !p),
								children: !isPlaying && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-16 w-16 place-items-center rounded-full bg-black/70 text-white shadow-2xl backdrop-blur-md animate-in fade-in zoom-in",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-8 w-8 translate-x-0.5 fill-white" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 p-4 pb-5 space-y-3 bg-gradient-to-t from-black/95 via-black/70 to-transparent",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-brand text-white font-bold text-xs ring-2 ring-white/50",
												children: activeShort.initials
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold text-white drop-shadow-sm",
												children: activeShort.creator
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-white/80",
												children: activeShort.creatorHandle
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => toggleSubscribe(activeShort.creatorHandle),
											className: `rounded-full px-4 py-1.5 text-xs font-bold transition-all shadow-md active:scale-95 ${subscribed[activeShort.creatorHandle] ? "bg-white/20 text-white backdrop-blur-md" : "bg-red-600 text-white hover:bg-red-700"}`,
											children: subscribed[activeShort.creatorHandle] ? "Subscribed" : "Subscribe"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-white line-clamp-2 leading-snug drop-shadow-sm",
										children: activeShort.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs text-white/85",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "h-3.5 w-3.5 shrink-0 animate-bounce text-red-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: activeShort.soundTrack
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-0 inset-x-0 h-1 bg-white/25 z-20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full bg-red-600 w-2/3 animate-pulse" })
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex md:flex-col items-center justify-center gap-3 sm:gap-4 z-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleLike(activeShort.id),
								className: "flex flex-col items-center gap-1 group active:scale-90 transition",
								"aria-label": "Like this short",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `grid h-11 w-11 place-items-center rounded-full backdrop-blur-md transition ${liked[activeShort.id] ? "bg-red-600 text-white shadow-lg shadow-red-600/30" : "bg-secondary/80 text-foreground hover:bg-secondary"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold text-foreground",
									children: liked[activeShort.id] ? "Liked" : activeShort.likes
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleDislike(activeShort.id),
								className: "flex flex-col items-center gap-1 group active:scale-90 transition",
								"aria-label": "Dislike this short",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `grid h-11 w-11 place-items-center rounded-full backdrop-blur-md transition ${disliked[activeShort.id] ? "bg-foreground text-background" : "bg-secondary/80 text-foreground hover:bg-secondary"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsDown, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold text-foreground",
									children: "Dislike"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setCommentsOpen((c) => !c),
								className: "flex flex-col items-center gap-1 group active:scale-90 transition",
								"aria-label": "View comments",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-11 w-11 place-items-center rounded-full bg-secondary/80 text-foreground hover:bg-secondary backdrop-blur-md transition",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold text-foreground",
									children: (shortComments[activeShort.id]?.length || 0) + parseInt(activeShort.comments, 10) || activeShort.comments
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									if (navigator.share) navigator.share({
										title: activeShort.title,
										url: window.location.href
									}).catch(() => {});
									else {
										navigator.clipboard.writeText(window.location.href);
										toast.success("Short link copied to clipboard!");
									}
								},
								className: "flex flex-col items-center gap-1 group active:scale-90 transition",
								"aria-label": "Share short",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-11 w-11 place-items-center rounded-full bg-secondary/80 text-foreground hover:bg-secondary backdrop-blur-md transition",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold text-foreground",
									children: activeShort.shares
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden md:flex flex-col gap-2 pt-2 border-t border-border/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: handlePrev,
									className: "grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground hover:bg-brand hover:text-white transition active:scale-95 shadow-sm",
									"aria-label": "Previous short",
									title: "Previous short (Up Arrow)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: handleNext,
									className: "grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground hover:bg-brand hover:text-white transition active:scale-95 shadow-sm",
									"aria-label": "Next short",
									title: "Next short (Down Arrow)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-5 w-5" })
								})]
							})
						]
					})]
				}), commentsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4 backdrop-blur-sm animate-in fade-in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full max-w-md rounded-t-3xl sm:rounded-3xl border border-border bg-card p-5 shadow-2xl animate-in slide-in-from-bottom",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b border-border/60 pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-bold text-foreground",
									children: "Comments"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCommentsOpen(false),
									className: "rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "my-4 max-h-60 overflow-y-auto space-y-3 pr-1",
								children: [(shortComments[activeShort.id] || []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-secondary/50 p-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-foreground",
											children: c.user
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground",
											children: c.time
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-foreground/90",
										children: c.text
									})]
								}, c.id)), !shortComments[activeShort.id]?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "py-6 text-center text-xs text-muted-foreground",
									children: "Be the first to comment on this short!"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleAddComment,
								className: "flex gap-2 border-t border-border/60 pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Add a comment...",
									value: newComment,
									onChange: (e) => setNewComment(e.target.value),
									className: "flex-1 rounded-full border border-border bg-secondary/60 px-4 py-2 text-xs text-foreground outline-none focus:border-brand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "grid h-9 w-9 place-items-center rounded-full bg-brand text-white transition hover:bg-brand-dark",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" })
								})]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
//#endregion
export { ShortsPage as component };
